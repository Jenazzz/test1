package dot.Rect.SMPCore.Util;

import java.util.Locale;

public final class Amounts {
    private Amounts() {}

    /**
     * Parses numbers like:
     * - 1000
     * - 1k, 1K
     * - 1m
     * - 1b
     * Also supports 1_000_000 and "1 000" (spaces removed).
     */
    public static long parse(String raw) {
        if (raw == null) throw new NumberFormatException("null");
        String s = raw.trim().toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "");
        if (s.isEmpty()) throw new NumberFormatException("empty");

        long mul = 1;
        char last = s.charAt(s.length() - 1);
        if (last == 'k' || last == 'm' || last == 'b') {
            s = s.substring(0, s.length() - 1);
            if (s.isEmpty()) throw new NumberFormatException("no number");
            mul = switch (last) {
                case 'k' -> 1_000L;
                case 'm' -> 1_000_000L;
                case 'b' -> 1_000_000_000L;
                default -> 1L;
            };
        }
        long base = Long.parseLong(s);
        return Math.multiplyExact(base, mul);
    }
}

