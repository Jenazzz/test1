package dot.Rect.SMPCore;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Modules.Commands;
import dot.Rect.SMPCore.Modules.Homes;
import dot.Rect.SMPCore.Modules.Admin.PlayerIndex;
import dot.Rect.SMPCore.Modules.Admin.VanillaBroadcastSuppressModule;
import dot.Rect.SMPCore.Modules.Hub.HubCosmeticsModule;
import dot.Rect.SMPCore.Modules.Hub.HubPvpArenaModule;
import dot.Rect.SMPCore.Modules.Hub.HubWorldModule;
import dot.Rect.SMPCore.Modules.Welcome.WelcomeModule;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.plugin.java.JavaPlugin;

public final class CoreMain extends JavaPlugin {
    private Commands commands;
    private HubPvpArenaModule hubPvpArena;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        var sessionConfirmation = new SessionConfirmation(this);
        var homes = new Homes(this);
        var playerIndex = new PlayerIndex(this);
        var hubCosmetics = new HubCosmeticsModule(this);
        this.commands = new Commands(this, homes, sessionConfirmation, playerIndex, hubCosmetics);
        var welcome = new WelcomeModule(this);
        var hubWorld = new HubWorldModule(this);
        this.hubPvpArena = new HubPvpArenaModule(this, hubCosmetics);
        var vanillaBroadcastSuppress = new VanillaBroadcastSuppressModule(this);

        homes.load();
        sessionConfirmation.load();
        playerIndex.load();
        commands.register();
        welcome.load();
        hubWorld.load();
        hubCosmetics.load();
        hubPvpArena.load();
        vanillaBroadcastSuppress.load();

        Text.info(getLogger(), "Enabled sosidrilla SMP core.");

    }

    @Override
    public void onDisable() {
        if (hubPvpArena != null) hubPvpArena.shutdown();
        // Best-effort flush
        if (commands != null) commands.shutdown();
    }
}
