package dot.Rect.SMPCore.Modules.Sell;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Modules.Value.Economy;
import dot.Rect.SMPCore.Modules.Value.ValueItems;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class SellModule implements Listener, CommandExecutor {
    private static final String TITLE = "Продажа предметов";
    static final String MULTI_TITLE = "Множители";

    private final JavaPlugin plugin;
    private final Economy economy;
    private final ValueItems values;
    private final SessionConfirmation confirmation;
    private final NamespacedKey loreKey;

    private final File file;
    private final YamlConfiguration store;

    public SellModule(JavaPlugin plugin, Economy economy, ValueItems values, SessionConfirmation confirmation) {
        this.plugin = plugin;
        this.economy = economy;
        this.values = values;
        this.confirmation = confirmation;
        this.loreKey = new NamespacedKey(plugin, "sell_lore");
        this.file = new File(plugin.getDataFolder(), "sell-progress.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }
        open(p);
        return true;
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(p, 36, TITLE); // 4x9
        p.openInventory(inv);
        Text.msg(p, "&8[&bSell&8] &7Закинь предметы и закрой — начислим монеты.");
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        // After Bukkit applies the move, refresh lore in sell inventory
        Bukkit.getScheduler().runTask(plugin, () -> refreshSellLore(p, e.getView().getTopInventory()));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> refreshSellLore(p, e.getView().getTopInventory()));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getPlayer() instanceof Player p)) return;

        var inv = e.getInventory();
        long total = 0;

        EnumMap<Category, Long> earnedByCat = new EnumMap<>(Category.class);
        EnumMap<Category, Long> baseByCat = new EnumMap<>(Category.class);
        for (Category c : Category.values()) {
            earnedByCat.put(c, 0L);
            baseByCat.put(c, 0L);
        }

        List<ItemStack> returnBack = new ArrayList<>();

        for (ItemStack item : inv.getContents()) {
            if (item == null || item.getType().isAir()) continue;
            Material mat = item.getType();
            long price = values.getPrice(mat);
            if (price <= 0) {
                returnBack.add(item);
                continue;
            }

            Category cat = Category.of(mat);
            double mult = getMultiplier(p.getUniqueId(), cat);
            long base = price * (long) item.getAmount();
            long earned = Math.max(0, Math.round(base * mult));

            baseByCat.put(cat, baseByCat.get(cat) + base);
            earnedByCat.put(cat, earnedByCat.get(cat) + earned);
            total += earned;
        }

        inv.clear();

        // Return unsellable items
        for (ItemStack it : returnBack) {
            var leftovers = p.getInventory().addItem(it);
            if (!leftovers.isEmpty()) {
                leftovers.values().forEach(st -> p.getWorld().dropItemNaturally(p.getLocation(), st));
            }
        }

        if (total <= 0) {
            Text.msg(p, "&7Нечего продавать.");
            return;
        }

        economy.deposit(p.getUniqueId(), total);

        // Progress: add BASE sold per category (not multiplied)
        for (Category c : Category.values()) {
            long base = baseByCat.get(c);
            if (base > 0) addSoldBase(p.getUniqueId(), c, base);
        }
        saveQuietly();

        Text.msg(p, "&aПродано на: &f" + total + " &aмонет.");
    }

    private void refreshSellLore(Player p, Inventory inv) {
        if (p == null || inv == null) return;
        UUID uuid = p.getUniqueId();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType().isAir()) continue;
            Material mat = item.getType();
            long price = values.getPrice(mat);
            if (price <= 0) continue;

            Category cat = Category.of(mat);
            double mult = getMultiplier(uuid, cat);
            // Keep lore stable per-item so stacks don't break.
            long perOne = Math.max(0, Math.round(price * mult));

            var meta = item.getItemMeta();
            if (meta == null) continue;

            // mark that this lore line is ours (so we can safely reapply/replace)
            meta.getPersistentDataContainer().set(loreKey, PersistentDataType.INTEGER, 1);

            List<String> lore = meta.getLore();
            if (lore == null) lore = new ArrayList<>();
            else lore = new ArrayList<>(lore);

            String line = Text.c("&6$: &f" + perOne + " &8| &7" + catDisplay(cat) + " &8| &f" + String.format(Locale.ROOT, "%.1f", mult) + "x");
            // remove older versions of our line
            lore.removeIf(s -> s != null && Text.c(s).contains("$:"));
            lore.add(line);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
    }

    private static String catDisplay(Category c) {
        return switch (c) {
            case ORES -> "Руда";
            case GEAR -> "Броня/Оружие";
            case BLOCKS -> "Блоки";
            case FOOD -> "Еда/Растения";
        };
    }

    private double getMultiplier(UUID uuid, Category cat) {
        long sold = store.getLong("players." + uuid + ".sold." + cat.key, 0);
        int steps = calcStepsFromSold(sold);
        double base = store.getDouble("settings.multiplier.base", 1.0);
        double step = store.getDouble("settings.multiplier.step", 0.1);
        double max = store.getDouble("settings.multiplier.max", 5.0);
        double m = base + (steps * step);
        return Math.min(max, Math.max(1.0, m));
    }

    private void addSoldBase(UUID uuid, Category cat, long amountBaseCoins) {
        long sold = store.getLong("players." + uuid + ".sold." + cat.key, 0);
        sold += Math.max(0, amountBaseCoins);
        store.set("players." + uuid + ".sold." + cat.key, sold);
    }

    private void saveQuietly() {
        // bootstrap defaults once
        if (!store.contains("settings.multiplier.base")) {
            store.set("settings.multiplier.base", 1.0);
            store.set("settings.multiplier.step", 0.1);
            store.set("settings.multiplier.max", 5.0);
        }

        try {
            store.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Failed to save sell-progress.yml: " + ex.getMessage());
        }
    }

    private enum Category {
        ORES("ores"),
        GEAR("gear"),
        BLOCKS("blocks"),
        FOOD("food");

        private final String key;

        Category(String key) {
            this.key = key;
        }

        static Category of(Material m) {
            String k = m.name().toLowerCase(Locale.ROOT);

            // food & plants
            if (k.contains("seed") || k.contains("sapling") || k.contains("wheat") || k.contains("carrot") || k.contains("potato") ||
                    k.contains("beetroot") || k.contains("melon") || k.contains("pumpkin") || k.contains("sugar_cane") ||
                    k.contains("cocoa") || k.contains("bamboo") || k.contains("kelp") || k.contains("mushroom") || m.isEdible()) {
                return FOOD;
            }

            // gear
            if (k.endsWith("_sword") || k.endsWith("_axe") || k.endsWith("_pickaxe") || k.endsWith("_shovel") || k.endsWith("_hoe") ||
                    k.endsWith("_helmet") || k.endsWith("_chestplate") || k.endsWith("_leggings") || k.endsWith("_boots") ||
                    k.contains("bow") || k.contains("crossbow") || k.contains("trident") || k.contains("mace") || k.contains("shield")) {
                return GEAR;
            }

            // ores/materials
            if (k.endsWith("_ore") || k.startsWith("deepslate_") && k.endsWith("_ore") ||
                    k.startsWith("raw_") || k.endsWith("_ingot") || k.contains("diamond") || k.contains("emerald") ||
                    k.contains("netherite") || k.contains("redstone") || k.contains("lapis") || k.contains("coal") || k.contains("copper")) {
                return ORES;
            }

            return BLOCKS;
        }
    }

    static int calcStepsFromSold(long sold) {
        // Steps correspond to reaching thresholds:
        // 10k -> step1 (1.1x), 25k -> step2 (1.2x), 50k -> step3 (1.3x),
        // then doubling: 100k -> 1.4x, 200k -> 1.5x, 400k -> 1.6x ...
        int steps = 0;
        if (sold >= 10_000) steps++;
        if (sold >= 25_000) steps++;
        if (sold >= 50_000) steps++;
        long t = 100_000;
        while (sold >= t && steps < 40) { // 5.0x cap => max 40 steps from 1.0 by 0.1
            steps++;
            if (t > Long.MAX_VALUE / 2) break;
            t *= 2;
        }
        return steps;
    }

    static long nextThreshold(long sold) {
        if (sold < 10_000) return 10_000;
        if (sold < 25_000) return 25_000;
        if (sold < 50_000) return 50_000;
        long t = 100_000;
        while (sold >= t) {
            if (t > Long.MAX_VALUE / 2) return t;
            t *= 2;
        }
        return t;
    }
}

