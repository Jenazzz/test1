package dot.Rect.SMPCore.Modules.Welcome;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class WelcomeModule implements Listener {
    private final JavaPlugin plugin;

    public WelcomeModule(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        showIfMatch(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        showIfMatch(e.getPlayer());
    }

    private void showIfMatch(Player p) {
        String w = p.getWorld().getName();
        if (!w.equalsIgnoreCase("hub1") && !w.equalsIgnoreCase("survival1")) return;

        String title = w.equalsIgnoreCase("hub1") ? "Хаб" : "Выживание";
        p.showTitle(Title.title(
                Component.text("SOSIDRILLA SMP", NamedTextColor.AQUA),
                Component.text("Добро пожаловать • " + title, NamedTextColor.WHITE),
                Title.Times.times(java.time.Duration.ofMillis(0), java.time.Duration.ofMillis(1800), java.time.Duration.ofMillis(300))
        ));

        var loc = p.getLocation().add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc, 80, 0.6, 0.8, 0.6, 0.02);
        p.getWorld().spawnParticle(Particle.PORTAL, loc, 80, 0.6, 0.8, 0.6, 0.02);
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.9f, 0.8f);
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.6f, 1.4f);
    }
}

