package dot.Rect.SMPCore.Modules.Hub;

import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubSaunaRegistry;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * В указанном мире (по умолчанию hub1): отмена урона и поддержание полного HP + голода.
 */
public final class HubWorldModule implements Listener {
    private final JavaPlugin plugin;

    public HubWorldModule(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        if (!enabled()) return;
        Bukkit.getPluginManager().registerEvents(this, plugin);
        long every = Math.max(10L, plugin.getConfig().getLong("hub.immortal.tick-interval", 40L));
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!enabled()) return;
            World w = hubWorld();
            if (w == null) return;
            for (Player p : w.getPlayers()) {
                applyFullVitality(p);
            }
        }, 40L, every);
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("hub.immortal.enabled", true);
    }

    private String hubWorldName() {
        String w = plugin.getConfig().getString("hub.immortal.world");
        if (w == null || w.isBlank()) {
            w = plugin.getConfig().getString("spawn.world", "hub1");
        }
        return w;
    }

    private World hubWorld() {
        return Bukkit.getWorld(hubWorldName());
    }

    private boolean isHubWorld(World world) {
        return world != null && world.getName().equalsIgnoreCase(hubWorldName());
    }

    private int voidRescueY() {
        return plugin.getConfig().getInt("hub.immortal.void-rescue-y", 20);
    }

    private void applyFullVitality(Player p) {
        if (p == null || !p.isOnline()) return;
        if (HubSaunaRegistry.isInSaunaEffectZone(p.getLocation())) return;
        var attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) {
            p.setHealth(attr.getValue());
        } else {
            p.setHealth(20.0);
        }
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setExhaustion(0f);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!enabled()) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (!isHubWorld(p.getWorld())) return;
        Location loc = p.getLocation();
        if (HubPvpBounds.contains(plugin, loc)) {
            return;
        }
        if (HubSaunaRegistry.isInSaunaEffectZone(loc)) {
            return;
        }
        e.setCancelled(true);
        applyFullVitality(p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (!enabled()) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (!isHubWorld(p.getWorld())) return;
        e.setCancelled(true);
        applyFullVitality(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!enabled()) return;
        Player p = e.getPlayer();
        if (!isHubWorld(p.getWorld())) return;
        Bukkit.getScheduler().runTask(plugin, () -> applyFullVitality(p));
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        if (!enabled()) return;
        if (!isHubWorld(e.getPlayer().getWorld())) return;
        Bukkit.getScheduler().runTask(plugin, () -> applyFullVitality(e.getPlayer()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!enabled()) return;
        Player p = e.getPlayer();
        if (!isHubWorld(p.getWorld())) return;
        if (e.getTo() == null) return;
        int floorY = voidRescueY();
        double toY = e.getTo().getY();
        if (toY >= floorY) return;
        // Только пересечение порога — иначе каждый тик под Y снова телепорт и спам в чат
        if (e.getFrom().getY() < floorY) return;
        World w = hubWorld();
        if (w == null) return;
        p.teleport(w.getSpawnLocation());
        Text.msg(p, "&eОх.. упал мой котик. Мяу!");
    }
}
