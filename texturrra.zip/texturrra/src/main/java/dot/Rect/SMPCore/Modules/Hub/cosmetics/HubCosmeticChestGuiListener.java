package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;

public final class HubCosmeticChestGuiListener implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public HubCosmeticChestGuiListener(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isChestToken(hand)) return;
        if (!e.getAction().name().contains("RIGHT_CLICK")) return;

        e.setCancelled(true);
        openGui(p);
    }

    private void openGui(Player p) {
        String title = s.guiTitleRaw();
        Inventory inv = Bukkit.createInventory(null, 27, title);
        items.fillCosmeticGui(inv);
        p.openInventory(inv);
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        if (!s.enabled()) return;
        if (!s.guiTitleRaw().equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!s.isHub(p)) return;
        e.setCancelled(true);
        int top = e.getView().getTopInventory().getSize();
        if (e.getRawSlot() >= top) return;

        ItemStack cur = e.getCurrentItem();
        if (cur == null || cur.getType().isAir()) return;
        if (!items.isAnyCosmetic(cur)) return;

        String id = items.getCosmeticId(cur);
        if (id == null) return;

        if (items.playerHasCosmetic(p, id)) {
            items.removeAllCosmeticId(p, id);
            return;
        }
        HashMap<Integer, ItemStack> left = p.getInventory().addItem(cur.clone());
        if (!left.isEmpty()) {
            Text.msg(p, "&cНет места в инвентаре.");
            return;
        }
    }
}
