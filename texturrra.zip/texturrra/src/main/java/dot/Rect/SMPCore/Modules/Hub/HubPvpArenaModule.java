package dot.Rect.SMPCore.Modules.Hub;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.GameRules;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.attribute.Attribute;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Мини-арена в хабе: урон обнуляется (только толчки), при входе снимается косметика и выдаётся палка
 * с отталкиванием; при выходе палка забирается, сундук косметики возвращается.
 */
public final class HubPvpArenaModule implements Listener {
    private final JavaPlugin plugin;
    private final HubCosmeticsModule hubCosmetics;
    private final NamespacedKey knockStickKey;
    private final Set<UUID> inArena = ConcurrentHashMap.newKeySet();
    private BukkitTask arenaSyncTask;

    public HubPvpArenaModule(JavaPlugin plugin, HubCosmeticsModule hubCosmetics) {
        this.plugin = plugin;
        this.hubCosmetics = hubCosmetics;
        this.knockStickKey = new NamespacedKey(plugin, "hub_pvp_knock_stick");
    }

    public void load() {
        if (!HubPvpBounds.enabled(plugin)) return;
        applyHubWorldPvp();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        long period = Math.max(5L, plugin.getConfig().getLong("hub.pvp-arena.sync-ticks", 10L));
        arenaSyncTask = Bukkit.getScheduler().runTaskTimer(plugin, this::syncPlayersWithArena, period, period);
        plugin.getLogger().info("[hub] PvP-арена включена, мир=" + HubPvpBounds.hubWorldName(plugin)
                + ", синхронизация каждые " + period + " тик.");
    }

    private void applyHubWorldPvp() {
        if (!plugin.getConfig().getBoolean("hub.pvp-arena.force-hub-world-pvp", true)) return;
        World w = Bukkit.getWorld(HubPvpBounds.hubWorldName(plugin));
        if (w != null) {
            w.setGameRule(GameRules.PVP, true);
        }
    }

    /** На случай если PlayerMoveEvent не сработал (телепорт, транспорт и т.д.). */
    private void syncPlayersWithArena() {
        if (!HubPvpBounds.enabled(plugin)) return;
        applyHubWorldPvp();
        World w = Bukkit.getWorld(HubPvpBounds.hubWorldName(plugin));
        if (w == null) return;
        for (Player p : w.getPlayers()) {
            boolean inside = HubPvpBounds.contains(plugin, p.getLocation());
            boolean tracked = inArena.contains(p.getUniqueId());
            if (inside && !tracked) {
                onEnter(p);
            } else if (!inside && tracked) {
                onExit(p);
            }
        }
    }

    public void shutdown() {
        if (arenaSyncTask != null) {
            arenaSyncTask.cancel();
            arenaSyncTask = null;
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!inArena.contains(p.getUniqueId())) continue;
            removeKnockSticks(p);
            hubCosmetics.pvpArenaExitRestoreChest(p);
        }
        inArena.clear();
    }

    private boolean isKnockStick(ItemStack it) {
        if (it == null || it.getType() != Material.STICK) return false;
        ItemMeta m = it.getItemMeta();
        return m != null && m.getPersistentDataContainer().has(knockStickKey, PersistentDataType.BYTE);
    }

    private ItemStack createKnockStick() {
        ItemStack st = new ItemStack(Material.STICK);
        ItemMeta m = st.getItemMeta();
        if (m != null) {
            m.setDisplayName(Text.c("&6&lАрена &7· &fОтталкивание"));
            m.addEnchant(Enchantment.KNOCKBACK, 1, true);
            m.setUnbreakable(true);
            m.getPersistentDataContainer().set(knockStickKey, PersistentDataType.BYTE, (byte) 1);
            st.setItemMeta(m);
        }
        return st;
    }

    private void removeKnockSticks(Player p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (isKnockStick(inv.getItem(i))) {
                inv.setItem(i, null);
            }
        }
        if (isKnockStick(inv.getItemInOffHand())) {
            inv.setItemInOffHand(null);
        }
    }

    private void giveKnockStick(Player p) {
        removeKnockSticks(p);
        PlayerInventory inv = p.getInventory();
        ItemStack stick = createKnockStick();
        int empty = inv.firstEmpty();
        if (empty >= 0 && empty <= 8) {
            inv.setItem(empty, stick);
            return;
        }
        for (int s = 0; s <= 8; s++) {
            ItemStack cur = inv.getItem(s);
            if (cur == null || cur.getType().isAir()) {
                inv.setItem(s, stick);
                return;
            }
        }
        for (ItemStack left : inv.addItem(stick).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    private void onEnter(Player p) {
        if (!p.isOnline()) return;
        if (!inArena.add(p.getUniqueId())) return;
        hubCosmetics.pvpArenaEnter(p);
        giveKnockStick(p);
    }

    private void onExit(Player p) {
        if (!inArena.remove(p.getUniqueId())) return;
        removeKnockSticks(p);
        hubCosmetics.pvpArenaExitRestoreChest(p);
    }

    private static boolean sameWorld(Location a, Location b) {
        if (a == null || b == null || a.getWorld() == null || b.getWorld() == null) return false;
        return a.getWorld().equals(b.getWorld());
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        Player p = e.getPlayer();
        Location to = e.getTo();
        if (to == null) return;
        if (!sameWorld(e.getFrom(), to)) return;
        boolean was = HubPvpBounds.contains(plugin, e.getFrom());
        boolean now = HubPvpBounds.contains(plugin, to);
        if (was == now) return;
        if (now) onEnter(p);
        else onExit(p);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        Player p = e.getPlayer();
        Location to = e.getTo();
        Location from = e.getFrom();
        if (to == null) return;
        boolean was = HubPvpBounds.contains(plugin, from);
        boolean now = HubPvpBounds.contains(plugin, to);
        if (was == now) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            if (now) onEnter(p);
            else onExit(p);
        });
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        if (!inArena.remove(p.getUniqueId())) return;
        removeKnockSticks(p);
        hubCosmetics.pvpArenaExitRestoreChest(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (!inArena.remove(p.getUniqueId())) return;
        removeKnockSticks(p);
        hubCosmetics.pvpArenaExitRestoreChest(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = e.getPlayer();
            if (!p.isOnline()) return;
            if (HubPvpBounds.contains(plugin, p.getLocation())) {
                onEnter(p);
            }
        }, 5L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player p = e.getPlayer();
            if (!p.isOnline()) return;
            if (HubPvpBounds.contains(plugin, p.getLocation())) {
                if (!inArena.contains(p.getUniqueId())) onEnter(p);
                else giveKnockStick(p);
            }
        });
    }

    /** Урон в зоне не меняет HP; отталкивание от палки подстраховываем вручную (в т.ч. при выключенном PvP). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamageZero(EntityDamageEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!HubPvpBounds.contains(plugin, victim.getLocation())) return;
        e.setDamage(0);
    }

    /**
     * После обнуления урона — полное HP и отталкивание палкой (если событие дошло; при выключенном PvP в мире
     * удары между игроками могут не вызывать событие — тогда включите {@code pvp} для мира хаба).
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageArenaFinish(EntityDamageEvent e) {
        if (!HubPvpBounds.enabled(plugin)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!HubPvpBounds.contains(plugin, victim.getLocation())) return;
        var attr = victim.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) {
            victim.setHealth(attr.getValue());
        }
        if (!(e instanceof EntityDamageByEntityEvent ed)) return;
        Player attacker = resolveDamagingPlayer(ed.getDamager());
        if (attacker == null || attacker == victim) return;
        if (!HubPvpBounds.contains(plugin, attacker.getLocation())) return;
        ItemStack hand = attacker.getInventory().getItemInMainHand();
        if (!isKnockStick(hand)) return;
        double dx = attacker.getLocation().getX() - victim.getLocation().getX();
        double dz = attacker.getLocation().getZ() - victim.getLocation().getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1e-4) {
            float yaw = attacker.getLocation().getYaw();
            double rad = Math.toRadians(yaw);
            dx = -Math.sin(rad);
            dz = Math.cos(rad);
        } else {
            dx /= len;
            dz /= len;
        }
        victim.knockback(0.65, dx, dz);
    }

    private static Player resolveDamagingPlayer(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }
}
