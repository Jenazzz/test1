package dot.Rect.SMPCore.API;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Offline-mode "session confirmation" stub.
 * Current behavior: issues a short code and marks player as confirmed when /confirm <code> matches.
 * Later you can plug Discord/Telegram verification that calls {@link #markConfirmed(UUID)}.
 */
public final class SessionConfirmation {
    private static final SecureRandom RNG = new SecureRandom();
    private static final HexFormat HEX = HexFormat.of();

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration store;

    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public SessionConfirmation(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "confirmed.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        // ensure file exists on disk eventually
        saveQuietly();
    }

    /** Если false — проверка отключена, все считаются подтверждёнными (без кода на входе и в командах). */
    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("session-confirmation.enabled", false);
    }

    public boolean isConfirmed(UUID uuid) {
        if (!isEnabled()) return true;
        return store.getBoolean("confirmed." + uuid, false);
    }

    public void markConfirmed(UUID uuid) {
        store.set("confirmed." + uuid, true);
        saveQuietly();
        pending.remove(uuid);
    }

    public String issueCode(Player player) {
        var bytes = new byte[4]; // 8 hex chars
        RNG.nextBytes(bytes);
        var code = HEX.formatHex(bytes);
        pending.put(player.getUniqueId(), new Pending(code, Instant.now().getEpochSecond()));
        return code;
    }

    public boolean tryConfirm(Player player, String code) {
        if (code == null) return false;
        var p = pending.get(player.getUniqueId());
        if (p == null) return false;

        if (!p.code.equalsIgnoreCase(code.trim())) return false;

        markConfirmed(player.getUniqueId());
        Text.msg(player, "&aПодтверждение успешно. Приятной игры!");
        return true;
    }

    public Pending getPending(UUID uuid) {
        return pending.get(uuid);
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save confirmed.yml: " + e.getMessage());
        }
    }

    public record Pending(String code, long issuedAtEpochSeconds) {}
}

