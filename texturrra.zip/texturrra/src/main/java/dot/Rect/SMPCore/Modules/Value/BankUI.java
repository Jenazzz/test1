package dot.Rect.SMPCore.Modules.Value;

import dot.Rect.SMPCore.Util.Text;
import dot.Rect.SMPCore.Util.Amounts;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.block.Sign;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.block.data.BlockData;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BankUI implements Listener {
    private static final String TITLE = "Банк";

    private final JavaPlugin plugin;
    private final Economy economy;
    private final NamespacedKey keyAction;
    private final NamespacedKey keyAmount;
    private final NamespacedKey keyCustom;
    private final Map<UUID, String> pendingMode = new ConcurrentHashMap<>();
    private final Map<UUID, Location> pendingSignLoc = new ConcurrentHashMap<>();
    private final Map<UUID, BlockData> pendingSignOld = new ConcurrentHashMap<>();

    public BankUI(JavaPlugin plugin, Economy economy) {
        this.plugin = plugin;
        this.economy = economy;
        this.keyAction = new NamespacedKey(plugin, "bank_action");
        this.keyAmount = new NamespacedKey(plugin, "bank_amount");
        this.keyCustom = new NamespacedKey(plugin, "bank_custom");
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(p, 27, TITLE);

        long wallet = economy.getBalance(p.getUniqueId());
        long bank = economy.getBank(p.getUniqueId());

        inv.setItem(11, info(Material.GOLD_INGOT, "&eКошелёк", List.of(
                "&7Баланс: &f" + wallet,
                "&7Команды: &f/money &7/ &f/pay"
        )));
        // Some clients/resourcepacks render ENDER_CHEST weird, keep it safe.
        inv.setItem(15, info(Material.CHEST, "&bБанк", List.of(
                "&7На счету: &f" + bank,
                "&7Положи/сними через кнопки ниже"
        )));

        // Interest info
        inv.setItem(13, info(Material.DIAMOND, "&bПроценты на банк", List.of(
                "&7Каждый день в &f12:00&7 начисляется процент.",
                "",
                "&a0 - 50k&7: &f5%",
                "&a50k - 300k&7: &f3%",
                "&a300k+&7: &f1%"
        )));

        // Deposit
        inv.setItem(19, action(Material.LIME_STAINED_GLASS_PANE, "&aВнести всё", "deposit_all", -1));
        inv.setItem(20, action(Material.LIME_STAINED_GLASS_PANE, "&aВнести половину", "deposit_half", -1));
        inv.setItem(21, custom(Material.LIME_STAINED_GLASS_PANE, "&aВнести своё", "deposit_custom"));

        // Withdraw
        inv.setItem(23, action(Material.RED_STAINED_GLASS_PANE, "&cВывести всё", "withdraw_all", -1));
        inv.setItem(24, action(Material.RED_STAINED_GLASS_PANE, "&cВывести половину", "withdraw_half", -1));
        inv.setItem(25, custom(Material.RED_STAINED_GLASS_PANE, "&cВывести своё", "withdraw_custom"));

        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (TITLE.equals(e.getView().getTitle())) {
            e.setCancelled(true);

            var item = e.getCurrentItem();
            if (item == null || item.getType().isAir()) return;
            var meta = item.getItemMeta();
            if (meta == null) return;

            var pdc = meta.getPersistentDataContainer();
            var action = pdc.get(keyAction, PersistentDataType.STRING);
            Long amount = pdc.get(keyAmount, PersistentDataType.LONG);
            var custom = pdc.get(keyCustom, PersistentDataType.STRING);

            if (custom != null && !custom.isBlank()) {
                pendingMode.put(p.getUniqueId(), custom);
                openAmountSign(p);
                return;
            }

            String actionStr = action;
            if (actionStr == null) return;
            if (amount == null) amount = -1L;

            switch (actionStr) {
                case "deposit_all" -> handleDeposit(p, economy.getBalance(p.getUniqueId()));
                case "deposit_half" -> handleDeposit(p, halfUp(economy.getBalance(p.getUniqueId())));
                case "withdraw_all" -> handleWithdraw(p, economy.getBank(p.getUniqueId()));
                case "withdraw_half" -> handleWithdraw(p, halfUp(economy.getBank(p.getUniqueId())));
                default -> {
                    // legacy fixed amounts (kept just in case)
                    if (amount <= 0) return;
                    if (actionStr.equals("deposit")) handleDeposit(p, amount);
                    if (actionStr.equals("withdraw")) handleWithdraw(p, amount);
                }
            }
            return;
        }
    }

    @EventHandler
    public void onSignChange(SignChangeEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        UUID uuid = p.getUniqueId();
        Location loc = pendingSignLoc.get(uuid);
        if (loc == null) return;
        if (!sameBlock(loc, e.getBlock().getLocation())) return;

        String mode = pendingMode.get(uuid);
        if (mode == null) {
            cleanupSign(uuid);
            return;
        }

        String raw = pickFirstNonBlank(e.getLines());
        long amount;
        try {
            amount = Amounts.parse(raw);
        } catch (Exception ex) {
            Text.msg(p, "&cПримеры: &f100 &7/ &f1k &7/ &f1m &7/ &f1b");
            cleanupSign(uuid);
            Bukkit.getScheduler().runTask(plugin, () -> open(p));
            return;
        }

        if (amount <= 0) {
            Text.msg(p, "&cСумма должна быть > 0.");
            cleanupSign(uuid);
            Bukkit.getScheduler().runTask(plugin, () -> open(p));
            return;
        }

        cleanupSign(uuid);

        if (mode.equals("deposit_custom")) {
            handleDeposit(p, amount);
        } else if (mode.equals("withdraw_custom")) {
            handleWithdraw(p, amount);
        }

        Bukkit.getScheduler().runTask(plugin, () -> open(p));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cleanupSign(e.getPlayer().getUniqueId());
    }

    private void openAmountSign(Player p) {
        UUID uuid = p.getUniqueId();
        cleanupSign(uuid);

        var w = p.getWorld();
        int x = p.getLocation().getBlockX();
        int z = p.getLocation().getBlockZ();
        int y = w.getMaxHeight() - 1; // safe-ish invisible place in loaded chunk

        var loc = new Location(w, x, y, z);
        var block = w.getBlockAt(loc);

        BlockData old = block.getBlockData();
        pendingSignOld.put(uuid, old);
        pendingSignLoc.put(uuid, loc);

        block.setType(Material.OAK_SIGN, false);
        var state = block.getState();
        if (state instanceof Sign sign) {
            sign.setLine(0, "");
            sign.setLine(1, "Введите сумму");
            sign.setLine(2, "100 | 1k | 1m");
            sign.setLine(3, "");
            sign.update(false, false);
            try {
                p.openSign(sign);
            } catch (Throwable t) {
                Text.msg(p, "&cТабличка недоступна на этом ядре. (Нужен Paper/Purpur)");
                cleanupSign(uuid);
                open(p);
            }
        } else {
            cleanupSign(uuid);
            Text.msg(p, "&cНе удалось открыть ввод суммы.");
            open(p);
        }
    }

    private void handleDeposit(Player p, long amount) {
        if (amount <= 0) {
            Text.msg(p, "&cНечего вносить.");
            return;
        }
        if (!economy.withdraw(p.getUniqueId(), amount)) {
            Text.msg(p, "&cНедостаточно средств в кошельке.");
            return;
        }
        economy.bankDeposit(p.getUniqueId(), amount);
        Text.msg(p, "&aВ банк: &f" + amount);
    }

    private void handleWithdraw(Player p, long amount) {
        if (amount <= 0) {
            Text.msg(p, "&cНечего выводить.");
            return;
        }
        if (!economy.bankWithdraw(p.getUniqueId(), amount)) {
            Text.msg(p, "&cНедостаточно средств в банке.");
            return;
        }
        economy.deposit(p.getUniqueId(), amount);
        Text.msg(p, "&aИз банка: &f" + amount);
    }

    private ItemStack info(Material mat, String name, List<String> lore) {
        var it = new ItemStack(mat);
        var meta = it.getItemMeta();
        meta.setDisplayName(Text.c(name));
        meta.setLore(lore.stream().map(Text::c).toList());
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack action(Material mat, String name, String action, long amount) {
        var it = new ItemStack(mat);
        var meta = it.getItemMeta();
        meta.setDisplayName(Text.c(name));
        meta.getPersistentDataContainer().set(keyAction, PersistentDataType.STRING, action.toLowerCase(Locale.ROOT));
        meta.getPersistentDataContainer().set(keyAmount, PersistentDataType.LONG, amount);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack custom(Material mat, String name, String mode) {
        var it = new ItemStack(mat);
        var meta = it.getItemMeta();
        meta.setDisplayName(Text.c(name));
        meta.setLore(List.of(
                Text.c("&7Откроется ввод суммы"),
                Text.c("&8(табличка)")
        ));
        meta.getPersistentDataContainer().set(keyCustom, PersistentDataType.STRING, mode);
        it.setItemMeta(meta);
        return it;
    }

    private void cleanupSign(UUID uuid) {
        Location loc = pendingSignLoc.remove(uuid);
        BlockData old = pendingSignOld.remove(uuid);
        pendingMode.remove(uuid);
        if (loc == null || old == null) return;
        try {
            var block = loc.getWorld().getBlockAt(loc);
            block.setBlockData(old, false);
        } catch (Throwable ignored) {
        }
    }

    private static boolean sameBlock(Location a, Location b) {
        return a.getWorld() == b.getWorld()
                && a.getBlockX() == b.getBlockX()
                && a.getBlockY() == b.getBlockY()
                && a.getBlockZ() == b.getBlockZ();
    }

    private static String pickFirstNonBlank(String[] lines) {
        if (lines == null) return "";
        for (String s : lines) {
            if (s != null) {
                String t = s.trim();
                if (!t.isEmpty()) return t;
            }
        }
        return "";
    }

    private static long halfUp(long v) {
        if (v <= 0) return 0;
        return (v + 1) / 2;
    }
}

