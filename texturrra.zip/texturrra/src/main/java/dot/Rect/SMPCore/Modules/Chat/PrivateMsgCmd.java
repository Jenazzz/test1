package dot.Rect.SMPCore.Modules.Chat;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class PrivateMsgCmd implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }

        if (args.length < 2) {
            Text.msg(p, "&cИспользование: &f/m <ник> <сообщение...>");
            return true;
        }

        Player to = Bukkit.getPlayerExact(args[0]);
        if (to == null) {
            Text.msg(p, "&cИгрок не найден: &f" + args[0]);
            return true;
        }
        if (to.getUniqueId().equals(p.getUniqueId())) {
            Text.msg(p, "&cСамому себе нельзя.");
            return true;
        }

        String msg = join(args, 1);
        if (msg.isBlank()) {
            Text.msg(p, "&cСообщение пустое.");
            return true;
        }

        // Pretty, consistent formatting (no click events)
        Text.msg(p, "&8[&dЛС&8] &7Ты &8→ &f" + to.getName() + "&7: &f" + msg);
        Text.msg(to, "&8[&dЛС&8] &f" + p.getName() + " &8→ &7Тебе&7: &f" + msg);
        return true;
    }

    private static String join(String[] a, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < a.length; i++) {
            if (i > from) sb.append(' ');
            sb.append(a[i]);
        }
        return sb.toString().trim();
    }
}

