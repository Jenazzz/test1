package dot.Rect.SMPCore.Modules.Scoreboard;

import dot.Rect.SMPCore.Modules.Playtime.PlaytimeModule;
import dot.Rect.SMPCore.Modules.Stats.KillsDeathsModule;
import dot.Rect.SMPCore.Modules.Value.Economy;
import dot.Rect.SMPCore.Modules.Value.PlayerKeyCooldowns;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ScoreboardModule {
    /**
     * Bitmap glyph from resource pack: {@code assets/minecraft/textures/custom/ui/sb_with_logo.png}
     * (see {@code assets/minecraft/font/default.json}).
     */
    private static final String SIDEBAR_TITLE = "\uA42C";

    private static final String ICON_STAR = "\uA432";
    private static final String ICON_MONEY = "\uA424";
    private static final String ICON_KEY = "\uA422";
    private static final String ICON_KILLS = "\uA423";
    private static final String ICON_DEATHS = "\uA421";
    private static final String ICON_CLAN = "\uA41F";
    private static final String ICON_PLAYTIME = "\uA427";
    private static final String ICON_PING = "\uA426";
    /** crystal.png — гемы */
    private static final String ICON_GEM = "\uA420";

    /**
     * Пустые строки сверху. У сайдбара лимит 15 строк (1 + 9 контент + 5 низ = 15).
     */
    private static final int TOP_BLANK_LINES = 1;
    private static final String ROW_INDENT = "    ";

    private static final String STUB_CLAN = "0";

    /** Сколько слотов под строки сайдбара (уникальные entry + team). */
    private static final int SLOT_COUNT = 16;

    private final JavaPlugin plugin;
    private final Economy economy;
    private final PlaytimeModule playtime;
    private final PlayerKeyCooldowns keyCooldowns;
    private final KillsDeathsModule killsDeaths;

    private int taskId = -1;

    /** Чтобы не дергать клиент без нужды — префиксы только при смене текста. */
    private final Map<UUID, String[]> lastPrefixes = new ConcurrentHashMap<>();
    /** Сколько строк было в прошлый раз — сбрасываем лишние scores один раз при сжатии. */
    private final Map<UUID, Integer> lastLineCount = new ConcurrentHashMap<>();

    public ScoreboardModule(JavaPlugin plugin, Economy economy, PlaytimeModule playtime,
                            PlayerKeyCooldowns keyCooldowns, KillsDeathsModule killsDeaths) {
        this.plugin = plugin;
        this.economy = economy;
        this.playtime = playtime;
        this.keyCooldowns = keyCooldowns;
        this.killsDeaths = killsDeaths;
    }

    public void load() {
        if (taskId != -1) return;
        // Чаще, чем раз в секунду, но без полного reset всех строк — меньше визуальных «пролётов».
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, this::tick, 5L, 5L);
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            update(p);
        }
    }

    private void update(Player p) {
        UUID uuid = p.getUniqueId();

        Scoreboard sb = p.getScoreboard();
        if (sb == null || sb == Bukkit.getScoreboardManager().getMainScoreboard()) {
            sb = Bukkit.getScoreboardManager().getNewScoreboard();
            p.setScoreboard(sb);
            lastPrefixes.remove(uuid);
            lastLineCount.remove(uuid);
        }

        Objective obj = sb.getObjective("sosidrilla");
        if (obj == null) {
            obj = sb.registerNewObjective("sosidrilla", "dummy", SIDEBAR_TITLE);
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        } else {
            obj.setDisplayName(SIDEBAR_TITLE);
        }
        applyBlankSidebarNumbers(obj);

        long bal = economy.getBalance(uuid);
        long bank = economy.getBank(uuid);
        long gems = economy.getGems(uuid);
        String pt = playtime.format(uuid);
        String moneyCompact = compactMoney(bal);
        String bankCompact = compactMoney(bank);
        String keyLine = keyCooldowns.formatScoreboardSegment(uuid);
        int online = Bukkit.getOnlinePlayers().size();
        int maxPl = Bukkit.getMaxPlayers();
        int ping = p.getPing();
        long kills = killsDeaths.getKills(uuid);
        long deaths = killsDeaths.getDeaths(uuid);

        List<String> lines = new ArrayList<>();
        for (int b = 0; b < TOP_BLANK_LINES; b++) {
            lines.add("&7 ");
        }

        lines.add(ROW_INDENT + "&e" + ICON_STAR + " &f" + p.getName());
        lines.add(ROW_INDENT + "&6" + ICON_MONEY + " &6$&f " + moneyCompact + " &7|| &f" + bankCompact);
        lines.add(ROW_INDENT + "&b" + ICON_GEM + " &7Gems: &f" + gems);
        lines.add(ROW_INDENT + "&c" + ICON_KILLS + " &7Kills &f" + kills);
        lines.add(ROW_INDENT + "&4" + ICON_DEATHS + " &7Deaths &f" + deaths);
        lines.add(ROW_INDENT + "&d" + ICON_CLAN + " &7Clan &f" + STUB_CLAN);
        lines.add(ROW_INDENT + "&f" + ICON_KEY + " &7" + keyLine);
        lines.add(ROW_INDENT + "&b" + ICON_PLAYTIME + " &f" + pt);
        lines.add(ROW_INDENT + "&a" + ICON_PING + " &7Ping &f" + ping + "ms");

        appendBottomSection(lines, online, maxPl);

        int n = lines.size();
        int prev = lastLineCount.getOrDefault(uuid, 0);
        if (prev > n) {
            for (int i = n; i < prev && i < SLOT_COUNT; i++) {
                sb.resetScores(key(i));
            }
        }
        lastLineCount.put(uuid, n);

        String[] cached = lastPrefixes.get(uuid);
        if (cached == null || cached.length != n) {
            cached = new String[n];
            lastPrefixes.put(uuid, cached);
        }

        int score = n;
        for (int i = 0; i < n; i++) {
            String entry = key(i);
            String text = Text.c(lines.get(i));
            String trimmed = trim(text);

            obj.getScore(entry).setScore(score--);

            var team = sb.getTeam("l" + i);
            if (team == null) team = sb.registerNewTeam("l" + i);
            if (!team.hasEntry(entry)) team.addEntry(entry);

            if (!Objects.equals(trimmed, cached[i])) {
                team.setPrefix(trimmed);
                team.setSuffix("");
                cached[i] = trimmed;
            }
        }

        for (int i = n; i < SLOT_COUNT; i++) {
            var team = sb.getTeam("l" + i);
            if (team != null) {
                for (String en : new HashSet<>(team.getEntries())) {
                    team.removeEntry(en);
                }
            }
        }
    }

    /**
     * Низ: 1) пусто, 2) бренд S-D SMP, 3) онлайн/макс, 4–5) пусто.
     */
    private static void appendBottomSection(List<String> lines, int online, int maxPl) {
        lines.add("&7 ");
        lines.add(ROW_INDENT + "&5&l» &d&lS-&5&lD &f&lS&d&lM&5&lP &5&l«");
        lines.add(ROW_INDENT + "&7" + online + "&f/&7" + maxPl);
        lines.add("&7 ");
        lines.add("&7 ");
    }

    /** 900 → 900, 1500 → 1k, 408534 → 408k, 2_000_000 → 2m */
    static String compactMoney(long n) {
        if (n < 0) n = 0;
        if (n < 1000L) {
            return Long.toString(n);
        }
        if (n < 1_000_000L) {
            return (n / 1000L) + "k";
        }
        return (n / 1_000_000L) + "m";
    }

    private static String key(int i) {
        ChatColor[] cs = ChatColor.values();
        if (i >= 0 && i < cs.length) return cs[i].toString() + ChatColor.RESET;
        return ChatColor.COLOR_CHAR + "0" + i;
    }

    private static String trim(String s) {
        if (s == null) return "";
        return s.length() <= 64 ? s : s.substring(0, 64);
    }

    private static void applyBlankSidebarNumbers(Objective objective) {
        objective.numberFormat(NumberFormat.blank());
    }
}
