package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Незеритовый обломок — стеклянная коробка 5×5×5 под ногами (пол на слое −1 от ног), 15 с потом откат блоков.
 * Слепота, тошнота и урон хаба — только внутри этой коробки.
 */
public final class MaleSaunaCosmetic implements Listener {
    private static final Material[] GLASS = {
            Material.WHITE_STAINED_GLASS, Material.ORANGE_STAINED_GLASS, Material.MAGENTA_STAINED_GLASS,
            Material.LIGHT_BLUE_STAINED_GLASS, Material.YELLOW_STAINED_GLASS, Material.LIME_STAINED_GLASS,
            Material.PINK_STAINED_GLASS, Material.GRAY_STAINED_GLASS, Material.LIGHT_GRAY_STAINED_GLASS,
            Material.CYAN_STAINED_GLASS, Material.PURPLE_STAINED_GLASS, Material.BLUE_STAINED_GLASS,
            Material.BROWN_STAINED_GLASS, Material.GREEN_STAINED_GLASS, Material.RED_STAINED_GLASS,
            Material.BLACK_STAINED_GLASS
    };

    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public MaleSaunaCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isCosmetic(hand, HubCosmeticIds.MALE_SAUNA)) return;
        if (!e.getAction().name().contains("RIGHT_CLICK")) return;
        if (e.getAction().name().contains("BLOCK") && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        e.setCancelled(true);
        if (s.onCooldown(p, 2000)) return;
        if (HubSaunaRegistry.hasActiveSession()) {
            Text.msg(p, "&cПарная уже раскалена — подожди, пока остынет.");
            return;
        }
        tryPlaceSauna(p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!b.getWorld().getName().equalsIgnoreCase(s.hubWorldName())) return;
        if (HubSaunaRegistry.protectsAnySaunaBlock(b)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        HubSaunaRegistry.endAllForOwner(e.getPlayer().getUniqueId());
    }

    private void tryPlaceSauna(Player p) {
        World w = p.getWorld();
        Location ploc = p.getLocation();
        int px = ploc.getBlockX();
        int pz = ploc.getBlockZ();
        // Слой пола — блоки прямо под ногами (на один ниже позиции стоп)
        int baseY = (int) Math.floor(ploc.getY()) - 1;
        int baseX = px - 2;
        int baseZ = pz - 2;

        if (baseY < w.getMinHeight() || baseY + 4 >= w.getMaxHeight()) {
            Text.msg(p, "&cБатя говорил надо баню ровно ставить!");
            return;
        }
        if (w.getBlockAt(px, baseY, pz).getType().isAir()) {
            Text.msg(p, "&cБатя говорил надо баню ровно ставить!");
            return;
        }

        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                Block b = w.getBlockAt(baseX + dx, baseY, baseZ + dz);
                if (b.getType() == Material.BEDROCK || b.getType() == Material.BARRIER) {
                    Text.msg(p, "&cБатя говорил надо баню ровно ставить!");
                    return;
                }
            }
        }

        List<BlockPos> toChange = buildRoomPositions(baseX, baseY, baseZ);
        List<BlockSnap> snaps = new ArrayList<>(toChange.size());
        for (BlockPos pos : toChange) {
            Block bl = w.getBlockAt(pos.x, pos.y, pos.z);
            snaps.add(new BlockSnap(w, pos.x, pos.y, pos.z, bl.getBlockData()));
        }

        int color = 0;
        for (BlockPos pos : toChange) {
            Block bl = w.getBlockAt(pos.x, pos.y, pos.z);
            bl.setType(GLASS[color % GLASS.length], false);
            color++;
        }

        // Эффекты и «PvP хаба» только внутри коробки 5×5×5 (те же границы, что и стекло)
        int effMinX = baseX;
        int effMaxX = baseX + 4;
        int effMinZ = baseZ;
        int effMaxZ = baseZ + 4;
        int effMinY = baseY;
        int effMaxY = baseY + 4;

        SaunaSession session = new SaunaSession(s, p.getUniqueId(), snaps, w, effMinX, effMaxX, effMinZ, effMaxZ, effMinY, effMaxY);
        HubSaunaRegistry.register(session);
        session.start();

        Location soundAt = new Location(w, baseX + 2.5, baseY + 2.5, baseZ + 2.5);
        w.playSound(soundAt, Sound.BLOCK_GLASS_PLACE, 1f, 0.7f);
        Text.msg(p, "&6Мужская баня открыта!");
    }

    private static List<BlockPos> buildRoomPositions(int baseX, int baseY, int baseZ) {
        List<BlockPos> list = new ArrayList<>();
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                list.add(new BlockPos(baseX + dx, baseY, baseZ + dz));
            }
        }
        int ceilY = baseY + 4;
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                list.add(new BlockPos(baseX + dx, ceilY, baseZ + dz));
            }
        }
        for (int layer = 1; layer <= 3; layer++) {
            int y = baseY + layer;
            for (int dx = 0; dx < 5; dx++) {
                for (int dz = 0; dz < 5; dz++) {
                    boolean inner = dx >= 1 && dx <= 3 && dz >= 1 && dz <= 3;
                    if (!inner) {
                        list.add(new BlockPos(baseX + dx, y, baseZ + dz));
                    }
                }
            }
        }
        return list;
    }

    private record BlockPos(int x, int y, int z) {}

    private record BlockSnap(World world, int x, int y, int z, BlockData data) {}

    private static final class SaunaSession implements ActiveSaunaSession {
        private final HubCosmeticsSupport support;
        private final UUID owner;
        private final List<BlockSnap> snaps;
        private final World world;
        private final int effMinX;
        private final int effMaxX;
        private final int effMinZ;
        private final int effMaxZ;
        private final int effMinY;
        private final int effMaxY;
        private final Set<String> protectKeys = new HashSet<>();
        private BukkitTask tickTask;
        private volatile boolean ended;

        SaunaSession(HubCosmeticsSupport support, UUID owner, List<BlockSnap> snaps, World world,
                     int effMinX, int effMaxX, int effMinZ, int effMaxZ, int effMinY, int effMaxY) {
            this.support = support;
            this.owner = owner;
            this.snaps = snaps;
            this.world = world;
            this.effMinX = effMinX;
            this.effMaxX = effMaxX;
            this.effMinZ = effMinZ;
            this.effMaxZ = effMaxZ;
            this.effMinY = effMinY;
            this.effMaxY = effMaxY;
            for (BlockSnap sn : snaps) {
                protectKeys.add(key(sn.x, sn.y, sn.z));
            }
        }

        private static String key(int x, int y, int z) {
            return x + "," + y + "," + z;
        }

        void start() {
            tickTask = new BukkitRunnable() {
                int sec = 0;

                @Override
                public void run() {
                    if (ended) {
                        cancel();
                        return;
                    }
                    if (sec >= 15) {
                        endNow();
                        cancel();
                        return;
                    }
                    for (Player pl : Bukkit.getOnlinePlayers()) {
                        if (!containsEffectZone(pl.getLocation())) continue;
                        if (!support.isHub(pl)) continue;
                        pl.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 45, 0, false, false, true));
                        pl.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 45, 0, false, false, true));
                    }
                    sec++;
                }
            }.runTaskTimer(support.plugin(), 0L, 20L);
        }

        @Override
        public UUID ownerUuid() {
            return owner;
        }

        @Override
        public boolean containsEffectZone(Location loc) {
            if (loc == null || loc.getWorld() == null || !loc.getWorld().equals(world)) return false;
            int x = loc.getBlockX();
            int z = loc.getBlockZ();
            int y = loc.getBlockY();
            return x >= effMinX && x <= effMaxX && z >= effMinZ && z <= effMaxZ && y >= effMinY && y <= effMaxY;
        }

        @Override
        public boolean protectsBlock(Block block) {
            if (block == null || !block.getWorld().equals(world)) return false;
            return protectKeys.contains(key(block.getX(), block.getY(), block.getZ()));
        }

        @Override
        public void forceEnd() {
            endNow();
        }

        private synchronized void endNow() {
            if (ended) return;
            ended = true;
            if (tickTask != null) {
                tickTask.cancel();
                tickTask = null;
            }
            HubSaunaRegistry.unregister(this);
            Bukkit.getScheduler().runTask(support.plugin(), this::restoreBlocks);
        }

        private void restoreBlocks() {
            for (BlockSnap sn : snaps) {
                if (sn.world.isChunkLoaded(sn.x >> 4, sn.z >> 4)) {
                    sn.world.getBlockAt(sn.x, sn.y, sn.z).setBlockData(sn.data, false);
                }
            }
        }
    }
}
