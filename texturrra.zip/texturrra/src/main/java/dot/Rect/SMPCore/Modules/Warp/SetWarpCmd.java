package dot.Rect.SMPCore.Modules.Warp;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SetWarpCmd implements CommandExecutor {
    private final SessionConfirmation confirmation;
    private final WarpModule warps;

    public SetWarpCmd(SessionConfirmation confirmation, WarpModule warps) {
        this.confirmation = confirmation;
        this.warps = warps;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!p.hasPermission("smpcore.warp.set") && !p.isOp()) {
            Text.msg(p, "&cНет прав: &fsmpcore.warp.set");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }
        if (args.length != 1) {
            Text.msg(p, "&cИспользование: &f/setwarp <name>");
            return true;
        }
        if (!warps.setWarp(p, args[0])) {
            Text.msg(p, "&cИмя варпа: &fa-z 0-9 _ - &7(до 16 символов)");
            return true;
        }
        Text.msg(p, "&aВарп сохранён: &f" + args[0] + " &8(/warp " + args[0] + ")");
        return true;
    }
}

