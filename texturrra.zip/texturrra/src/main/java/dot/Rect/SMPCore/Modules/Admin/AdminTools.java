package dot.Rect.SMPCore.Modules.Admin;

import dot.Rect.SMPCore.Util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AdminTools implements Listener {
    private final JavaPlugin plugin;
    private final Set<UUID> god = ConcurrentHashMap.newKeySet();
    private static final DecimalFormat DF1 = new DecimalFormat("0.0");

    public AdminTools(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public CommandExecutor gm() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            if (args.length != 1) {
                Text.msg(p, "&cИспользование: &f/gm <0|1|2|3>");
                return true;
            }
            GameMode gm = switch (args[0]) {
                case "0" -> GameMode.SURVIVAL;
                case "1" -> GameMode.CREATIVE;
                case "2" -> GameMode.ADVENTURE;
                case "3" -> GameMode.SPECTATOR;
                default -> null;
            };
            if (gm == null) {
                Text.msg(p, "&c/gm: &f0 1 2 3");
                return true;
            }
            p.setGameMode(gm);
            p.sendActionBar(Component.text("GM: " + gm.name(), NamedTextColor.AQUA));
            return true;
        };
    }

    public CommandExecutor fly() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            boolean on = !p.getAllowFlight();
            p.setAllowFlight(on);
            if (!on && p.isFlying()) p.setFlying(false);
            p.sendActionBar(Component.text("Fly: " + (on ? "ON" : "OFF"), on ? NamedTextColor.GREEN : NamedTextColor.RED));
            return true;
        };
    }

    public CommandExecutor god() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            UUID u = p.getUniqueId();
            boolean on;
            if (god.contains(u)) {
                god.remove(u);
                on = false;
            } else {
                god.add(u);
                on = true;
            }
            p.sendActionBar(Component.text("God: " + (on ? "ON" : "OFF"), on ? NamedTextColor.GREEN : NamedTextColor.RED));
            return true;
        };
    }

    public CommandExecutor speed() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            if (args.length != 1) {
                Text.msg(p, "&cИспользование: &f/speed <1-10>");
                return true;
            }
            float v = parseSpeed(args[0]);
            if (v < 0) {
                Text.msg(p, "&cСкорость: &f1-10");
                return true;
            }
            p.setWalkSpeed(v);
            p.setFlySpeed(v);
            p.sendActionBar(Component.text("Speed: " + args[0], NamedTextColor.AQUA));
            return true;
        };
    }

    public CommandExecutor flyspeed() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            if (args.length != 1) {
                Text.msg(p, "&cИспользование: &f/" + label + " <1-10>");
                return true;
            }
            float v = parseSpeed(args[0]);
            if (v < 0) {
                Text.msg(p, "&cСкорость: &f1-10");
                return true;
            }
            p.setFlySpeed(v);
            p.sendActionBar(Component.text("FlySpeed: " + args[0], NamedTextColor.AQUA));
            return true;
        };
    }

    public CommandExecutor day() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            p.getWorld().setTime(1000);
            p.sendActionBar(Component.text("☀ Day", NamedTextColor.YELLOW));
            return true;
        };
    }

    public CommandExecutor night() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;
            p.getWorld().setTime(13000);
            p.sendActionBar(Component.text("🌙 Night", NamedTextColor.BLUE));
            return true;
        };
    }

    public CommandExecutor clear() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;

            Player target = p;
            if (args.length >= 1) {
                Player t = Bukkit.getPlayerExact(args[0]);
                if (t == null) {
                    Text.msg(p, "&cИгрок не найден: &f" + args[0]);
                    return true;
                }
                if (!p.isOp() && !p.hasPermission("smpcore.clear.others")) {
                    Text.msg(p, "&cНет прав.");
                    return true;
                }
                target = t;
            }

            int removed = clearInv(target.getInventory());

            if (target.getUniqueId().equals(p.getUniqueId())) {
                Text.msg(p, "&aИнвентарь очищен. &8(-" + removed + " предметов)");
            } else {
                Text.msg(p, "&aОчищено у &f" + target.getName() + "&a. &8(-" + removed + " предметов)");
                Text.msg(target, "&cТвой инвентарь очистили. &8(-" + removed + " предметов)");
            }
            return true;
        };
    }

    public CommandExecutor tps() {
        return (sender, command, label, args) -> {
            Player p = asPlayer(sender);
            if (p == null) return true;

            double[] tps = Bukkit.getServer().getTPS(); // 1m, 5m, 15m
            double mspt = Bukkit.getServer().getAverageTickTime();

            String t1 = fmtTps(tps, 0);
            String t5 = fmtTps(tps, 1);
            String t15 = fmtTps(tps, 2);
            String m = fmtMspt(mspt);

            Text.msg(p, "&5&lSOSIDRILLA SMP &8| &dTPS");
            Text.msg(p, "&7 1m: " + t1 + " &8| &7 5m: " + t5 + " &8| &7 15m: " + t15);
            Text.msg(p, "&7 MSPT: " + m);
            return true;
        };
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (god.contains(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        god.remove(e.getPlayer().getUniqueId());
    }

    private Player asPlayer(CommandSender sender) {
        if (sender instanceof Player p) return p;
        Text.msg(sender, "&cТолько для игроков.");
        return null;
    }

    private float parseSpeed(String s) {
        try {
            int n = Integer.parseInt(s.trim());
            if (n < 1 || n > 10) return -1;
            // Bukkit walk/fly speed expects 0..1
            return n / 10f;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private static int clearInv(PlayerInventory inv) {
        int removed = 0;
        for (ItemStack it : inv.getContents()) if (it != null && !it.getType().isAir()) removed += it.getAmount();
        for (ItemStack it : inv.getArmorContents()) if (it != null && !it.getType().isAir()) removed += it.getAmount();
        ItemStack off = inv.getItemInOffHand();
        if (off != null && !off.getType().isAir()) removed += off.getAmount();

        inv.clear();
        inv.setArmorContents(null);
        inv.setItemInOffHand(null);
        return removed;
    }

    private static String fmtTps(double[] tps, int idx) {
        double v = (tps != null && tps.length > idx) ? tps[idx] : 20.0;
        if (Double.isNaN(v) || Double.isInfinite(v)) v = 20.0;
        v = Math.min(20.0, Math.max(0.0, v));
        String c = v >= 19.5 ? "&a" : (v >= 18.0 ? "&e" : "&c");
        return c + DF1.format(v) + "&7/20";
    }

    private static String fmtMspt(double mspt) {
        if (Double.isNaN(mspt) || Double.isInfinite(mspt)) mspt = 0.0;
        mspt = Math.max(0.0, mspt);
        String c = mspt <= 45.0 ? "&a" : (mspt <= 55.0 ? "&e" : "&c");
        return c + DF1.format(mspt) + "&7ms";
    }
}

