package dot.Rect.SMPCore.Util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

public final class ItemIO {
    private ItemIO() {}

    public static String toBase64(ItemStack[] contents) {
        try {
            var out = new ByteArrayOutputStream();
            try (var oos = new BukkitObjectOutputStream(out)) {
                oos.writeInt(contents.length);
                for (ItemStack item : contents) {
                    oos.writeObject(item);
                }
            }
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize inventory", e);
        }
    }

    public static ItemStack[] fromBase64(String data) {
        if (data == null || data.isBlank()) return new ItemStack[0];
        try {
            byte[] raw = Base64.getDecoder().decode(data);
            try (var ois = new BukkitObjectInputStream(new ByteArrayInputStream(raw))) {
                int len = ois.readInt();
                ItemStack[] items = new ItemStack[len];
                for (int i = 0; i < len; i++) {
                    items[i] = (ItemStack) ois.readObject();
                }
                return items;
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to deserialize inventory", e);
        }
    }
}

