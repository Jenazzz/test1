package dot.Rect.SMPCore.Modules.Value;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * File-based economy (YAML). Minimal, safe, and good enough for start.
 *
 * balances:
 *   <uuid>: <long>
 * bank:
 *   <uuid>: <long>
 */
public final class Economy {
    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration store;

    public Economy(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "economy.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
    }

    public long getBalance(UUID uuid) {
        return Math.max(0, store.getLong("balances." + uuid, 0));
    }

    public long getBank(UUID uuid) {
        return Math.max(0, store.getLong("bank." + uuid, 0));
    }

    public void deposit(UUID uuid, long amount) {
        if (amount <= 0) return;
        store.set("balances." + uuid, getBalance(uuid) + amount);
        saveQuietly();
    }

    public boolean withdraw(UUID uuid, long amount) {
        if (amount <= 0) return false;
        var bal = getBalance(uuid);
        if (bal < amount) return false;
        store.set("balances." + uuid, bal - amount);
        saveQuietly();
        return true;
    }

    public void bankDeposit(UUID uuid, long amount) {
        if (amount <= 0) return;
        store.set("bank." + uuid, getBank(uuid) + amount);
        saveQuietly();
    }

    public boolean bankWithdraw(UUID uuid, long amount) {
        if (amount <= 0) return false;
        var bal = getBank(uuid);
        if (bal < amount) return false;
        store.set("bank." + uuid, bal - amount);
        saveQuietly();
        return true;
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (IOException e) {
            Text.info(plugin.getLogger(), "Failed to save economy.yml: " + e.getMessage());
        }
    }
}

