package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

public final class JokerWebCosmetic implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public JokerWebCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isCosmetic(hand, HubCosmeticIds.JOKER_WEB)) return;

        if (e.getAction().name().startsWith("LEFT_CLICK")) {
            s.breakJokerForPlayer(p);
            Text.msg(p, "&7Связь снята.");
            return;
        }

        if (!e.getAction().name().contains("RIGHT_CLICK")) return;
        if (e.getAction().name().contains("BLOCK") && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        e.setCancelled(true);
        if (s.onCooldown(p, 500)) return;
        Snowball ball = p.launchProjectile(Snowball.class);
        ball.setVelocity(p.getLocation().getDirection().multiply(1.35));
        ball.getPersistentDataContainer().set(s.keyJoker(), PersistentDataType.STRING, p.getUniqueId().toString());
        p.playSound(p.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 0.6f, 0.9f);
    }

    @EventHandler
    public void onProjHit(ProjectileHitEvent e) {
        if (!s.enabled()) return;
        if (!(e.getEntity() instanceof Snowball ball)) return;
        String ownerStr = ball.getPersistentDataContainer().get(s.keyJoker(), PersistentDataType.STRING);
        if (ownerStr == null) return;
        Player owner;
        try {
            owner = Bukkit.getPlayer(UUID.fromString(ownerStr));
        } catch (IllegalArgumentException ex) {
            return;
        }
        if (owner == null || !s.isHub(owner)) return;
        if (!(e.getHitEntity() instanceof Player victim) || victim.equals(owner)) return;
        s.startJokerLeash(owner, victim);
        ball.remove();
    }
}
