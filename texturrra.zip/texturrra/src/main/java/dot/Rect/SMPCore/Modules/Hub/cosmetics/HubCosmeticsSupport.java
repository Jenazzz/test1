package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Общие ключи PDC, кулдауны, ловушка джокера, проверки хаба / манекенов.
 */
public final class HubCosmeticsSupport {
    private final JavaPlugin plugin;
    private final org.bukkit.NamespacedKey keyId;
    private final org.bukkit.NamespacedKey keyChest;
    private final org.bukkit.NamespacedKey keyJoker;
    private final org.bukkit.NamespacedKey keySmpcNpc;
    private final org.bukkit.NamespacedKey keyCosmeticMount;

    private final Map<UUID, Long> cooldown = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitRunnable> jokerTasks = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> jokerVictimByOwner = new ConcurrentHashMap<>();

    public HubCosmeticsSupport(JavaPlugin plugin) {
        this.plugin = plugin;
        this.keyId = new org.bukkit.NamespacedKey(plugin, "hub_cosmetic_id");
        this.keyChest = new org.bukkit.NamespacedKey(plugin, "hub_cosmetic_chest");
        this.keyJoker = new org.bukkit.NamespacedKey(plugin, "hub_joker_owner");
        this.keySmpcNpc = new org.bukkit.NamespacedKey(plugin, "smpcore_npc");
        this.keyCosmeticMount = new org.bukkit.NamespacedKey(plugin, "hub_cosmetic_mount_owner");
    }

    /** Помечает сущность как часть косметики (свинолет и т.п.) — владелец для очистки. */
    public void tagHubCosmeticMount(Entity e, UUID owner) {
        if (e == null || owner == null) return;
        e.getPersistentDataContainer().set(keyCosmeticMount, PersistentDataType.STRING, owner.toString());
    }

    public JavaPlugin plugin() {
        return plugin;
    }

    public org.bukkit.NamespacedKey keyId() {
        return keyId;
    }

    public org.bukkit.NamespacedKey keyChest() {
        return keyChest;
    }

    public org.bukkit.NamespacedKey keyJoker() {
        return keyJoker;
    }

    public org.bukkit.NamespacedKey keySmpcNpc() {
        return keySmpcNpc;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("hub.cosmetics.enabled", true);
    }

    public String hubWorldName() {
        return plugin.getConfig().getString("hub.immortal.world",
                plugin.getConfig().getString("spawn.world", "hub1"));
    }

    public int hotbarSlot() {
        int s = plugin.getConfig().getInt("hub.cosmetics.hotbar-slot", 4);
        return Math.max(0, Math.min(8, s));
    }

    public String guiTitleRaw() {
        return plugin.getConfig().getString("hub.cosmetics.gui-title", "Косметика");
    }

    public boolean isHub(Player p) {
        return p != null && p.getWorld().getName().equalsIgnoreCase(hubWorldName());
    }

    public boolean isSmpcNpcEntity(Entity e) {
        if (e == null) return false;
        try {
            return e.getPersistentDataContainer().has(keySmpcNpc, PersistentDataType.BYTE);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public boolean isJokerInvolved(Player p) {
        if (p == null) return false;
        UUID u = p.getUniqueId();
        if (jokerVictimByOwner.containsKey(u)) return true;
        for (Map.Entry<UUID, UUID> en : jokerVictimByOwner.entrySet()) {
            if (u.equals(en.getValue())) return true;
        }
        return false;
    }

    public boolean onCooldown(Player p, long ms) {
        long now = System.currentTimeMillis();
        long last = cooldown.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < ms) return true;
        cooldown.put(p.getUniqueId(), now);
        return false;
    }

    public void stopJoker(UUID owner) {
        BukkitRunnable t = jokerTasks.remove(owner);
        if (t != null) t.cancel();
        jokerVictimByOwner.remove(owner);
    }

    public void breakJokerForPlayer(Player p) {
        UUID u = p.getUniqueId();
        stopJoker(u);
        UUID ownerToStop = null;
        for (Map.Entry<UUID, UUID> en : jokerVictimByOwner.entrySet()) {
            if (u.equals(en.getValue())) {
                ownerToStop = en.getKey();
                break;
            }
        }
        if (ownerToStop != null) {
            stopJoker(ownerToStop);
        }
    }

    public void startJokerLeash(Player owner, Player victim) {
        stopJoker(owner.getUniqueId());
        jokerVictimByOwner.put(owner.getUniqueId(), victim.getUniqueId());
        BukkitRunnable task = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!owner.isOnline() || !victim.isOnline() || !isHub(owner) || !isHub(victim) || ticks++ > 200) {
                    cancel();
                    jokerTasks.remove(owner.getUniqueId());
                    jokerVictimByOwner.remove(owner.getUniqueId());
                    return;
                }
                Vector d = owner.getLocation().toVector().subtract(victim.getLocation().toVector());
                double dist = d.length();
                if (dist < 0.01) return;
                d.normalize();
                if (dist > 5.2) {
                    victim.setVelocity(victim.getVelocity().add(d.multiply(0.28)));
                } else if (dist < 3.8) {
                    victim.setVelocity(victim.getVelocity().add(d.clone().multiply(-0.12)));
                } else {
                    victim.setVelocity(victim.getVelocity().add(d.multiply(0.08)));
                }
                victim.getWorld().spawnParticle(Particle.WITCH, victim.getLocation().add(0, 1, 0), 2, 0.25, 0.25, 0.25, 0);
            }
        };
        jokerTasks.put(owner.getUniqueId(), task);
        task.runTaskTimer(plugin, 0L, 1L);
    }
}
