package dot.Rect.SMPCore.Modules.Ec;

import dot.Rect.SMPCore.Modules.Admin.PlayerIndex;
import dot.Rect.SMPCore.Util.ItemIO;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class EcModule implements Listener, org.bukkit.command.CommandExecutor {
    /** Заголовок GUI (клик по блоку ЭС и /ec). Должен совпадать с проверками в других модулях. */
    public static final String INVENTORY_TITLE = "Эндер-сундук";
    private static final int SIZE = 54; // 6x9

    private final JavaPlugin plugin;
    private final PlayerIndex playerIndex;
    private final File file;
    private final YamlConfiguration store;
    private final Map<UUID, UUID> openedAs = new ConcurrentHashMap<>();

    public EcModule(JavaPlugin plugin, PlayerIndex playerIndex) {
        this.plugin = plugin;
        this.playerIndex = playerIndex;
        this.file = new File(plugin.getDataFolder(), "ec.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() != Material.ENDER_CHEST) return;

        // Replace vanilla ender chest with our custom 6x9
        e.setCancelled(true);
        open(e.getPlayer(), e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }

        UUID target = p.getUniqueId();
        if (args.length == 1) {
            UUID uuid = playerIndex.resolveUuidByName(args[0]);
            if (uuid == null) {
                Text.msg(p, "&cИгрок не найден: &f" + args[0]);
                return true;
            }
            // simple permission gate for others
            if (!p.hasPermission("smpcore.ec.others") && !p.isOp()) {
                Text.msg(p, "&cНет прав: &fsmpcore.ec.others");
                return true;
            }
            target = uuid;
        } else if (args.length > 1) {
            Text.msg(p, "&cИспользование: &f/ec [player]");
            return true;
        }

        open(p, target);
        return true;
    }

    public void open(Player viewer, UUID owner) {
        Inventory inv = Bukkit.createInventory(viewer, SIZE, INVENTORY_TITLE);
        ItemStack[] items = load(owner);
        for (int i = 0; i < Math.min(items.length, SIZE); i++) {
            inv.setItem(i, items[i]);
        }
        openedAs.put(viewer.getUniqueId(), owner);
        viewer.openInventory(inv);
        if (!viewer.getUniqueId().equals(owner)) {
            Text.msg(viewer, "&7Открыт ЭС игрока: &f" + store.getString("names." + owner, owner.toString()));
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!INVENTORY_TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        UUID owner = openedAs.remove(p.getUniqueId());
        if (owner == null) owner = p.getUniqueId();
        save(owner, e.getInventory().getContents());
    }

    private ItemStack[] load(UUID owner) {
        store.set("names." + owner, store.getString("names." + owner, owner.toString()));
        String b64 = store.getString("players." + owner + ".data", "");
        ItemStack[] items = ItemIO.fromBase64(b64);
        if (items.length == 0) return new org.bukkit.inventory.ItemStack[SIZE];
        if (items.length != SIZE) {
            // normalize size
            org.bukkit.inventory.ItemStack[] out = new org.bukkit.inventory.ItemStack[SIZE];
            System.arraycopy(items, 0, out, 0, Math.min(items.length, SIZE));
            return out;
        }
        return items;
    }

    private void save(UUID owner, org.bukkit.inventory.ItemStack[] contents) {
        if (contents == null) contents = new org.bukkit.inventory.ItemStack[SIZE];
        if (contents.length != SIZE) {
            org.bukkit.inventory.ItemStack[] out = new org.bukkit.inventory.ItemStack[SIZE];
            System.arraycopy(contents, 0, out, 0, Math.min(contents.length, SIZE));
            contents = out;
        }
        store.set("players." + owner + ".data", ItemIO.toBase64(contents));
        saveQuietly();
    }

    private void saveQuietly() {
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            store.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Failed to save ec.yml: " + ex.getMessage());
        }
    }
}

