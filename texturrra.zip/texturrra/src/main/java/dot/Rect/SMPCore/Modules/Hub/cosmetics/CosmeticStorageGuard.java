package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Modules.Ec.EcModule;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.InventoryView;

/**
 * Косметику нельзя класть в ванильный эндер-сундук, в кастомный ЭС ({@link EcModule}, блок и /ec) и в торговлю с жителем.
 */
public final class CosmeticStorageGuard implements Listener {
    private final CosmeticItems items;

    public CosmeticStorageGuard(CosmeticItems items) {
        this.items = items;
    }

    private boolean blocked(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return false;
        return items.isChestToken(stack) || items.isAnyCosmetic(stack);
    }

    private boolean isGuardedStorage(InventoryView view, Inventory top) {
        if (EcModule.INVENTORY_TITLE.equals(view.getTitle())) {
            return true;
        }
        InventoryType t = top.getType();
        return t == InventoryType.ENDER_CHEST || t == InventoryType.MERCHANT;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryView view = e.getView();
        Inventory top = view.getTopInventory();
        if (!isGuardedStorage(view, top)) return;

        Inventory clicked = e.getClickedInventory();
        ItemStack cursor = e.getCursor();

        if (blocked(cursor) && clicked == top) {
            e.setCancelled(true);
            Text.msg(p, "&cКосметику нельзя класть сюда.");
            return;
        }

        if (clicked == p.getInventory()) {
            if (e.getClick() == ClickType.SHIFT_LEFT || e.getClick() == ClickType.SHIFT_RIGHT) {
                if (blocked(e.getCurrentItem())) {
                    e.setCancelled(true);
                    Text.msg(p, "&cКосметику нельзя класть сюда.");
                    return;
                }
            }
            if (e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
                if (blocked(e.getCurrentItem())) {
                    e.setCancelled(true);
                    Text.msg(p, "&cКосметику нельзя класть сюда.");
                }
            }
        }

        if (e.getClick() == ClickType.NUMBER_KEY && clicked == top) {
            ItemStack hotbar = p.getInventory().getItem(e.getHotbarButton());
            if (blocked(hotbar)) {
                e.setCancelled(true);
                Text.msg(p, "&cКосметику нельзя класть сюда.");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryView view = e.getView();
        Inventory top = view.getTopInventory();
        if (!isGuardedStorage(view, top)) return;
        if (!blocked(e.getOldCursor())) return;

        int topSize = top.getSize();
        for (int raw : e.getRawSlots()) {
            if (raw < topSize) {
                e.setCancelled(true);
                Text.msg(p, "&cКосметику нельзя класть сюда.");
                return;
            }
        }
    }
}
