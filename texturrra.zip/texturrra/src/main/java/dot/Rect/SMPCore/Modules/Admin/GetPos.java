package dot.Rect.SMPCore.Modules.Admin;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class GetPos implements CommandExecutor {
    private final PlayerIndex index;

    public GetPos(PlayerIndex index) {
        this.index = index;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("smpcore.admin.getpos")) {
            Text.msg(sender, "&cНет прав.");
            return true;
        }

        Player target = null;
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cИспользование: /getpos <player>");
                return true;
            }
            target = p;
        } else if (args.length == 1) {
            target = Bukkit.getPlayerExact(args[0]);
        } else {
            Text.msg(sender, "&cИспользование: /getpos [player]");
            return true;
        }

        var loc = target != null ? target.getLocation() : null;
        if (loc == null && args.length == 1) {
            var uuid = index.resolveUuidByName(args[0]);
            loc = index.getLastLocation(uuid);
            if (loc == null) {
                Text.msg(sender, "&cНет сохранённой позиции для: &f" + args[0]);
                return true;
            }
        }
        var name = target != null ? target.getName() : args[0];
        Text.msg(sender,
                "&bPOS &f" + name + " &7=> &f" +
                        loc.getWorld().getName() + " " +
                        Math.floor(loc.getX()) + " " + Math.floor(loc.getY()) + " " + Math.floor(loc.getZ()) +
                        " &7(yaw=" + Math.round(loc.getYaw()) + ", pitch=" + Math.round(loc.getPitch()) + ")"
        );
        return true;
    }
}

