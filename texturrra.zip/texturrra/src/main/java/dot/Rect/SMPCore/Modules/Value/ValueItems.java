package dot.Rect.SMPCore.Modules.Value;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

/**
 * Placeholder for valuable items logic (for /sell, stats, drops, etc).
 * Now: config-driven prices for ALL items (values.yml). Generated on first run.
 */
public final class ValueItems {
    private final JavaPlugin plugin;
    private final java.io.File file;
    private final YamlConfiguration store;

    public ValueItems(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new java.io.File(plugin.getDataFolder(), "values.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        if (!store.contains("prices")) {
            generateAll();
        }
        saveQuietly();
    }

    public long getPrice(Material material) {
        if (material == null) return 0;
        return store.getLong("prices." + material.name().toLowerCase(Locale.ROOT), 0);
    }

    public boolean isValuable(Material material) {
        return getPrice(material) > 0;
    }

    private void generateAll() {
        // 1) Base pricing by simple heuristics (covers ALL items)
        for (Material m : Material.values()) {
            if (!m.isItem()) continue;
            String k = m.name().toLowerCase(Locale.ROOT);
            long v = heuristicBasePrice(k, m);
            store.set("prices." + k, v);
        }

        // 2) Explicit overrides for balance / "логично" crafting chains / rare items
        // Basics
        set("cobblestone", 2);
        set("stone", 2);
        set("dirt", 1);
        set("sand", 1);
        set("gravel", 1);

        // Planks
        set("oak_planks", 2);
        set("spruce_planks", 2);
        set("birch_planks", 2);
        set("jungle_planks", 2);
        set("acacia_planks", 2);
        set("dark_oak_planks", 2);
        set("mangrove_planks", 2);
        set("cherry_planks", 2);
        set("bamboo_planks", 2);
        set("crimson_planks", 3);
        set("warped_planks", 3);

        // Fence / building (пример “доски и забор”)
        set("oak_fence", 5);
        set("spruce_fence", 5);
        set("birch_fence", 5);
        set("jungle_fence", 5);
        set("acacia_fence", 5);
        set("dark_oak_fence", 5);
        set("mangrove_fence", 5);
        set("cherry_fence", 5);
        set("bamboo_fence", 5);
        set("crimson_fence", 6);
        set("warped_fence", 6);

        // Ores / materials
        set("coal", 3);
        set("coal_ore", 4);
        set("deepslate_coal_ore", 4);

        set("copper_ore", 4);
        set("deepslate_copper_ore", 4);
        set("raw_copper", 4);

        set("iron_ore", 5);
        set("deepslate_iron_ore", 5);
        set("raw_iron", 5);
        set("iron_ingot", 7);

        set("gold_ore", 7);
        set("deepslate_gold_ore", 7);
        set("raw_gold", 7);
        set("gold_ingot", 10);

        set("lapis_lazuli", 4);
        set("lapis_ore", 5);
        set("deepslate_lapis_ore", 5);

        set("redstone", 3);
        set("redstone_ore", 4);
        set("deepslate_redstone_ore", 4);

        set("diamond", 45);
        set("diamond_ore", 40);
        set("deepslate_diamond_ore", 40);

        set("emerald", 35);
        set("emerald_ore", 30);
        set("deepslate_emerald_ore", 30);

        // Netherite chain (логично как ты просил)
        set("netherite_scrap", 120);
        set("ancient_debris", 160);
        // Слиток = 4 * scrap
        set("netherite_ingot", 480);

        // Rare / unique
        set("elytra", 5000);
        set("dragon_egg", 10000);
        set("nether_star", 2500);
        set("beacon", 4000);
    }

    private long heuristicBasePrice(String key, Material material) {
        // Always have a price (>=1), but keep it "reasonable".
        // This is a starting point; values.yml is intended to be edited.
        if (key.endsWith("_spawn_egg")) return 150;
        if (key.contains("music_disc")) return 250;
        if (key.contains("banner_pattern")) return 120;
        if (key.contains("template")) return 200;
        if (key.contains("trim") && key.contains("smithing")) return 220;

        if (key.endsWith("_log") || key.endsWith("_wood") || key.endsWith("_stem") || key.endsWith("_hyphae")) return 3;
        if (key.endsWith("_planks")) return 2;
        if (key.endsWith("_fence") || key.endsWith("_fence_gate")) return 5;
        if (key.endsWith("_door")) return 6;
        if (key.endsWith("_trapdoor")) return 5;
        if (key.endsWith("_slab")) return 2;
        if (key.endsWith("_stairs")) return 4;

        if (key.endsWith("_ore")) return 5;
        if (key.startsWith("deepslate_") && key.endsWith("_ore")) return 5;
        if (key.startsWith("raw_")) return 5;
        if (key.endsWith("_ingot")) return 8;

        if (key.contains("netherite")) return 200;
        if (key.contains("diamond")) return 40;
        if (key.contains("emerald")) return 30;

        if (key.contains("enchanted_book")) return 200;
        if (key.endsWith("_book")) return 20;

        if (material.isEdible()) return 2;

        return 1;
    }

    private void set(String key, long price) {
        store.set("prices." + key, price);
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to save values.yml: " + e.getMessage());
        }
    }
}

