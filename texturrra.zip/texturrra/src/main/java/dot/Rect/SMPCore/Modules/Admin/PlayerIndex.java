package dot.Rect.SMPCore.Modules.Admin;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.UUID;

/**
 * Small file index to resolve offline players by name and store last known location.
 * Stored in players.yml in plugin data folder.
 */
public final class PlayerIndex implements Listener {
    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration store;

    public PlayerIndex(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public UUID resolveUuidByName(String name) {
        if (name == null) return null;
        name = name.trim();
        if (name.isEmpty()) return null;

        var key = name.toLowerCase(Locale.ROOT);
        var raw = store.getString("by-name." + key);
        if (raw != null) {
            try {
                return UUID.fromString(raw);
            } catch (IllegalArgumentException ignored) {
            }
        }

        // fallback: Bukkit offline player lookup (may be unreliable on offline-mode if player never joined)
        var off = Bukkit.getOfflinePlayer(name);
        return off != null ? off.getUniqueId() : null;
    }

    public Location getLastLocation(UUID uuid) {
        if (uuid == null) return null;
        var base = "last-location." + uuid;
        if (!store.contains(base + ".world")) return null;

        var worldName = store.getString(base + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = store.getDouble(base + ".x");
        double y = store.getDouble(base + ".y");
        double z = store.getDouble(base + ".z");
        float yaw = (float) store.getDouble(base + ".yaw");
        float pitch = (float) store.getDouble(base + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public void update(Player player) {
        var uuid = player.getUniqueId();
        var nameKey = player.getName().toLowerCase(Locale.ROOT);
        store.set("by-name." + nameKey, uuid.toString());
        store.set("last-name." + uuid, player.getName());
        saveLastLocation(player);
        saveQuietly();
    }

    public void saveLastLocation(Player player) {
        var uuid = player.getUniqueId();
        var loc = player.getLocation();
        var base = "last-location." + uuid;
        store.set(base + ".world", loc.getWorld().getName());
        store.set(base + ".x", loc.getX());
        store.set(base + ".y", loc.getY());
        store.set(base + ".z", loc.getZ());
        store.set(base + ".yaw", loc.getYaw());
        store.set(base + ".pitch", loc.getPitch());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        update(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        saveLastLocation(e.getPlayer());
        saveQuietly();
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (IOException e) {
            Text.info(plugin.getLogger(), "Failed to save players.yml: " + e.getMessage());
        }
    }
}

