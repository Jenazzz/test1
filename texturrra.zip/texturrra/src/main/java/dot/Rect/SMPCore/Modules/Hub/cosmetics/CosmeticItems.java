package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.entity.Player;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public final class CosmeticItems {
    private final HubCosmeticsSupport s;

    public CosmeticItems(HubCosmeticsSupport s) {
        this.s = s;
    }

    public void fillCosmeticGui(Inventory inv) {
        inv.setItem(10, leatherBoots("&a&lСлизневые ботинки", HubCosmeticIds.SLIME_BOOTS,
                List.of("&7Прыгай выше всех друг. Отращивай крылья.."),
                Color.fromRGB(100, 220, 90)));
        inv.setItem(11, tagged(Material.TRIPWIRE_HOOK, "&f&lПаутина гомункулуса", HubCosmeticIds.HOMUNCULUS_HOOK,
                List.of("&7Что-то очень склизкое и липкое..", "&7так еще и белое..")));
        inv.setItem(12, tagged(Material.WITHER_ROSE, "&8&lЧёрная дыра", HubCosmeticIds.BLACK_HOLE,
                List.of("&7Запахло жаренным.")));
        inv.setItem(13, tagged(Material.COBWEB, "&e&lЛовушка Джокера", HubCosmeticIds.JOKER_WEB,
                List.of("&7ПКМ: бросок", "&7ЛКМ: снять связку")));
        inv.setItem(14, tagged(Material.NETHERITE_BOOTS, "&2&lБотинки халка", HubCosmeticIds.HULK_BOOTS,
                List.of("&7Откуда эти щупольца?!")));
        inv.setItem(15, tagged(Material.NETHERITE_SCRAP, "&6&lМужская баня", HubCosmeticIds.MALE_SAUNA,
                List.of("&7А не сильно жарко для такой комнатки?")));
        inv.setItem(16, tagged(Material.SADDLE, "&d&lСвинолет", HubCosmeticIds.SWINOPLANE,
                List.of("&7Все таки отрастил крылья брат..")));
    }

    public ItemStack chestToken() {
        ItemStack it = new ItemStack(Material.CHEST);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(Text.c("&d&lКосметический сундук"));
        m.setLore(List.of(
                Text.c("&7Только в хабе. ПКМ — открыть меню."),
                Text.c("&7Повторный клик по предмету в меню — снять (вкл/выкл).")));
        m.getPersistentDataContainer().set(s.keyChest(), PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public boolean isChestToken(ItemStack it) {
        if (it == null || it.getType() != Material.CHEST) return false;
        var m = it.getItemMeta();
        return m != null && m.getPersistentDataContainer().has(s.keyChest(), PersistentDataType.BYTE);
    }

    public boolean isCosmetic(ItemStack it, String id) {
        if (it == null || !it.hasItemMeta()) return false;
        String v = it.getItemMeta().getPersistentDataContainer().get(s.keyId(), PersistentDataType.STRING);
        return id.equals(v);
    }

    public boolean isAnyCosmetic(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(s.keyId(), PersistentDataType.STRING);
    }

    /** Id косметики из PDC или {@code null}. */
    public String getCosmeticId(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(s.keyId(), PersistentDataType.STRING);
    }

    public boolean playerHasCosmetic(Player p, String id) {
        if (id == null) return false;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (id.equals(getCosmeticId(inv.getItem(i)))) return true;
        }
        return false;
    }

    /** Удаляет все стаки с этим id (все слоты инвентаря игрока). */
    public void removeAllCosmeticId(Player p, String id) {
        if (id == null) return;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (id.equals(getCosmeticId(inv.getItem(i)))) {
                inv.setItem(i, null);
            }
        }
    }

    /** Сундук косметики и все предметы с {@code hub_cosmetic_id} (инвентарь + броня). */
    public void stripAllHubCosmetics(Player p) {
        if (p == null) return;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (isChestToken(it) || isAnyCosmetic(it)) {
                inv.setItem(i, null);
            }
        }
        if (isChestToken(inv.getHelmet()) || isAnyCosmetic(inv.getHelmet())) inv.setHelmet(null);
        if (isChestToken(inv.getChestplate()) || isAnyCosmetic(inv.getChestplate())) inv.setChestplate(null);
        if (isChestToken(inv.getLeggings()) || isAnyCosmetic(inv.getLeggings())) inv.setLeggings(null);
        if (isChestToken(inv.getBoots()) || isAnyCosmetic(inv.getBoots())) inv.setBoots(null);
    }

    /** Удаляет все косметические сундуки из инвентаря (все слоты, включая хотбар). */
    public void removeAllChestTokens(Player p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (isChestToken(st)) {
                inv.setItem(i, null);
            }
        }
    }

    private ItemStack tagged(Material mat, String name, String id, List<String> loreRaw) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        if (m == null) return it;
        m.setDisplayName(Text.c(name));
        if (loreRaw != null && !loreRaw.isEmpty()) {
            m.setLore(loreRaw.stream().map(Text::c).toList());
        }
        m.getPersistentDataContainer().set(s.keyId(), PersistentDataType.STRING, id);
        if (mat == Material.NETHERITE_BOOTS) {
            m.setUnbreakable(true);
        }
        it.setItemMeta(m);
        return it;
    }

    private ItemStack leatherBoots(String name, String id, List<String> loreRaw, Color color) {
        ItemStack it = tagged(Material.LEATHER_BOOTS, name, id, loreRaw);
        ItemMeta m = it.getItemMeta();
        if (m instanceof LeatherArmorMeta lam) {
            lam.setColor(color);
            it.setItemMeta(lam);
        }
        return it;
    }
}
