package dot.Rect.SMPCore.Modules.Chat;

import dot.Rect.SMPCore.Util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;

public final class BroadcastCmd implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player p) {
            if (!p.isOp() && !p.hasPermission("smpcore.broadcast")) {
                Text.msg(p, "&cНет прав.");
                return true;
            }
        }

        if (args.length < 1) {
            Text.msg(sender, "&cИспользование: &f/" + label + " <сообщение...>");
            return true;
        }

        String msg = join(args, 0);
        if (msg.isBlank()) return true;

        String fromName = (sender instanceof Player p) ? p.getName() : "Console";
        // Make "От <name>" look smaller by NOT using bold and using gray.
        Component titleLine = LEGACY.deserialize(Text.c("&f" + msg));
        Component subLine = LEGACY.deserialize(Text.c("&8От &7" + fromName));
        var title = Title.title(
                titleLine,
                subLine,
                Title.Times.times(Duration.ofMillis(250), Duration.ofSeconds(3), Duration.ofMillis(500))
        );

        for (Player pl : Bukkit.getOnlinePlayers()) {
            try {
                pl.showTitle(title);
            } catch (Throwable ignored) {
            }
        }
        return true;
    }

    private static String join(String[] a, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < a.length; i++) {
            if (i > from) sb.append(' ');
            sb.append(a[i]);
        }
        return sb.toString().trim();
    }
}

