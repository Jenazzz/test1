package dot.Rect.SMPCore.Modules.TPA;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.TeleportService;
import dot.Rect.SMPCore.Util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TpaModule {
    private static final long EXPIRE_MS = 60_000;

    private final JavaPlugin plugin;
    private final SessionConfirmation confirmation;
    private final TeleportService tp;

    // target -> latest request
    private final Map<UUID, Request> requests = new ConcurrentHashMap<>();

    public TpaModule(JavaPlugin plugin, SessionConfirmation confirmation, TeleportService tp) {
        this.plugin = plugin;
        this.confirmation = confirmation;
        this.tp = tp;
    }

    public CommandExecutor tpa() {
        return (sender, command, label, args) -> {
            if (!(sender instanceof Player p)) return onlyPlayers(sender);
            if (!confirmation.isConfirmed(p.getUniqueId())) return needConfirm(p);
            if (args.length != 1) { Text.msg(p, "&cИспользование: &f/tpa <player>"); return true; }
            var target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { Text.msg(p, "&cИгрок не найден: &f" + args[0]); return true; }
            if (target.getUniqueId().equals(p.getUniqueId())) { Text.msg(p, "&cНельзя к себе."); return true; }

            var req = new Request(p.getUniqueId(), p.getName(), Type.TPA, System.currentTimeMillis());
            requests.put(target.getUniqueId(), req);

            Text.msg(p, "&8[&bTPA&8] &7Запрос отправлен игроку &f" + target.getName());
            sendRequestUi(target, req);
            return true;
        };
    }

    public CommandExecutor tpahere() {
        return (sender, command, label, args) -> {
            if (!(sender instanceof Player p)) return onlyPlayers(sender);
            if (!confirmation.isConfirmed(p.getUniqueId())) return needConfirm(p);
            if (args.length != 1) { Text.msg(p, "&cИспользование: &f/tpahere <player>"); return true; }
            var target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { Text.msg(p, "&cИгрок не найден: &f" + args[0]); return true; }
            if (target.getUniqueId().equals(p.getUniqueId())) { Text.msg(p, "&cНельзя к себе."); return true; }

            var req = new Request(p.getUniqueId(), p.getName(), Type.TPAHERE, System.currentTimeMillis());
            requests.put(target.getUniqueId(), req);

            Text.msg(p, "&8[&bTPA&8] &7Запрос отправлен игроку &f" + target.getName());
            sendRequestUi(target, req);
            return true;
        };
    }

    public CommandExecutor tpaccept() {
        return (sender, command, label, args) -> {
            if (!(sender instanceof Player target)) return onlyPlayers(sender);
            if (!confirmation.isConfirmed(target.getUniqueId())) return needConfirm(target);

            var req = requests.get(target.getUniqueId());
            if (req == null || req.isExpired()) {
                Text.msg(target, "&8[&bTPA&8] &7Нет активных запросов.");
                return true;
            }
            if (args.length == 1 && !req.fromName.equalsIgnoreCase(args[0])) {
                Text.msg(target, "&8[&bTPA&8] &7Последний запрос был от &f" + req.fromName);
                return true;
            }

            var from = Bukkit.getPlayer(req.from);
            if (from == null) {
                Text.msg(target, "&8[&bTPA&8] &cИгрок оффлайн.");
                requests.remove(target.getUniqueId());
                return true;
            }

            requests.remove(target.getUniqueId());
            Text.msg(target, "&8[&a✓&8] &7Принято.");
            Text.msg(from, "&8[&a✓&8] &7Запрос принят.");

            if (req.type == Type.TPA) {
                tp.teleportWithCountdown(from, target.getLocation(), "SOSIDRILLA SMP", "");
            } else {
                tp.teleportWithCountdown(target, from.getLocation(), "SOSIDRILLA SMP", "");
            }
            return true;
        };
    }

    public CommandExecutor tpdeny() {
        return (sender, command, label, args) -> {
            if (!(sender instanceof Player target)) return onlyPlayers(sender);
            if (!confirmation.isConfirmed(target.getUniqueId())) return needConfirm(target);

            var req = requests.get(target.getUniqueId());
            if (req == null || req.isExpired()) {
                Text.msg(target, "&8[&bTPA&8] &7Нет активных запросов.");
                return true;
            }
            if (args.length == 1 && !req.fromName.equalsIgnoreCase(args[0])) {
                Text.msg(target, "&8[&bTPA&8] &7Последний запрос был от &f" + req.fromName);
                return true;
            }

            requests.remove(target.getUniqueId());
            Text.msg(target, "&8[&c✗&8] &7Отклонено.");
            var from = Bukkit.getPlayer(req.from);
            if (from != null) Text.msg(from, "&8[&c✗&8] &7Запрос отклонён.");
            return true;
        };
    }

    private void sendRequestUi(Player target, Request req) {
        boolean here = req.type == Type.TPAHERE;
        var header = here
                ? Component.text("Вас просят телепортироваться к игроку", NamedTextColor.GRAY)
                : Component.text("К вам отправили запрос на телепортацию", NamedTextColor.GRAY);

        var who = Component.text("Игрок | ", NamedTextColor.DARK_GRAY)
                .append(Component.text(req.fromName, NamedTextColor.WHITE));

        var accept = Component.text("[Принять]", NamedTextColor.GREEN)
                .clickEvent(ClickEvent.runCommand("/tpaccept " + req.fromName));
        var deny = Component.text("[Отклонить]", NamedTextColor.RED)
                .clickEvent(ClickEvent.runCommand("/tpdeny " + req.fromName));

        target.sendMessage(Component.text(" ").append(header));
        target.sendMessage(Component.text(" ").append(who));
        target.sendMessage(Component.text(" ").append(accept).append(Component.text(" ")).append(deny));
        target.sendMessage(Component.text(" ").append(Component.text("(истечёт через 60 секунд)", NamedTextColor.DARK_GRAY)));
    }

    private boolean onlyPlayers(CommandSender sender) {
        Text.msg(sender, "&cТолько для игроков.");
        return true;
    }

    private boolean needConfirm(Player p) {
        Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
        return true;
    }

    private enum Type { TPA, TPAHERE }

    private record Request(UUID from, String fromName, Type type, long createdAtMs) {
        boolean isExpired() { return System.currentTimeMillis() - createdAtMs > EXPIRE_MS; }
    }
}

