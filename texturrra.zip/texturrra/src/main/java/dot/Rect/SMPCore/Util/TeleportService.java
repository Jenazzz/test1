package dot.Rect.SMPCore.Util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TeleportService {
    private final JavaPlugin plugin;
    private final Map<UUID, Integer> tasks = new ConcurrentHashMap<>();

    public TeleportService(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void teleportWithCountdown(Player player, Location to, String title, String subtitle) {
        cancel(player);

        // 3..2..1.. tp
        final int[] seconds = {3};
        int taskId = plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            if (!player.isOnline()) {
                cancel(player);
                return;
            }

            int s = seconds[0];
            if (s <= 0) {
                player.clearTitle();
                player.teleportAsync(to).thenRun(() -> {
                    player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                    player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, player.getLocation().add(0, 1, 0), 120, 0.8, 1.0, 0.8, 0.02);
                    player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0, 1, 0), 120, 0.8, 1.0, 0.8, 0.02);
                    player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 1.35f);
                });
                cancel(player);
                return;
            }

            player.showTitle(Title.title(
                    Component.text(title, NamedTextColor.AQUA),
                    Component.text(" " + s + " ", NamedTextColor.WHITE),
                    // show a bit longer (+2 seconds overall feel)
                    Title.Times.times(java.time.Duration.ofMillis(0), java.time.Duration.ofMillis(2900), java.time.Duration.ofMillis(200))
            ));
            player.sendActionBar(Component.text("Телепорт через " + s + "…", NamedTextColor.YELLOW));
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.4f);
            player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, player.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.01);
            seconds[0] = s - 1;
        }, 0L, 20L);

        tasks.put(player.getUniqueId(), taskId);
    }

    public void cancel(Player player) {
        Integer id = tasks.remove(player.getUniqueId());
        if (id != null) plugin.getServer().getScheduler().cancelTask(id);
    }
}

