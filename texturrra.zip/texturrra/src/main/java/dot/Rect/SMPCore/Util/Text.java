package dot.Rect.SMPCore.Util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.logging.Logger;

public final class Text {
    private Text() {}

    public static String c(String legacyAmpersand) {
        if (legacyAmpersand == null) return "";
        return ChatColor.translateAlternateColorCodes('&', legacyAmpersand);
    }

    public static void msg(CommandSender sender, String message) {
        sender.sendMessage(c(message));
    }

    public static void info(Logger logger, String message) {
        logger.info(message);
    }
}

