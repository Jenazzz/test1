package dot.Rect.SMPCore.Modules.Hub.cosmetics;

/** Строковые id в PDC {@code hub_cosmetic_id}. */
public final class HubCosmeticIds {
    private HubCosmeticIds() {}

    public static final String SLIME_BOOTS = "slime_boots";
    public static final String HOMUNCULUS_HOOK = "homunculus_hook";
    public static final String BLACK_HOLE = "black_hole";
    public static final String JOKER_WEB = "joker_web";
    public static final String HULK_BOOTS = "hulk_boots";
    public static final String MALE_SAUNA = "male_sauna";
    public static final String SWINOPLANE = "swinoplane";
}
