package dot.Rect.SMPCore.Modules.Playtime;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlaytimeModule implements Listener {
    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration store;
    private final Map<UUID, Long> joinAtMs = new ConcurrentHashMap<>();
    private int autosaveTaskId = -1;

    public PlaytimeModule(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playtime.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        // In case of /reload or plugin reload with players online
        for (Player p : Bukkit.getOnlinePlayers()) {
            joinAtMs.putIfAbsent(p.getUniqueId(), System.currentTimeMillis());
        }
        // Autosave so Ctrl+C / crash loses at most ~1 minute
        if (autosaveTaskId == -1) {
            autosaveTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, this::flushAll, 20L * 60L, 20L * 60L);
        }
    }

    public long getTotalSeconds(UUID uuid) {
        long base = store.getLong("players." + uuid + ".seconds", 0L);
        Long join = joinAtMs.get(uuid);
        if (join != null) {
            long add = Math.max(0L, (System.currentTimeMillis() - join) / 1000L);
            return base + add;
        }
        return base;
    }

    public String format(UUID uuid) {
        return formatSeconds(getTotalSeconds(uuid));
    }

    public static String formatSeconds(long seconds) {
        if (seconds < 0) seconds = 0;
        var d = Duration.ofSeconds(seconds);
        long days = d.toDays();
        d = d.minusDays(days);
        long hours = d.toHours();
        d = d.minusHours(hours);
        long mins = d.toMinutes();

        if (days > 0) return days + "д " + hours + "ч";
        if (hours > 0) return hours + "ч " + mins + "м";
        return mins + "м";
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        joinAtMs.put(p.getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        flush(p.getUniqueId());
    }

    public void flush(UUID uuid) {
        Long join = joinAtMs.remove(uuid);
        if (join == null) return;
        long add = Math.max(0L, (System.currentTimeMillis() - join) / 1000L);
        long base = store.getLong("players." + uuid + ".seconds", 0L);
        store.set("players." + uuid + ".seconds", base + add);
        saveQuietly();
    }

    public void flushAll() {
        for (var e : joinAtMs.entrySet()) {
            UUID uuid = e.getKey();
            Long join = e.getValue();
            if (join == null) continue;
            long add = Math.max(0L, (System.currentTimeMillis() - join) / 1000L);
            long base = store.getLong("players." + uuid + ".seconds", 0L);
            store.set("players." + uuid + ".seconds", base + add);
            // reset join point so we don't double count
            joinAtMs.put(uuid, System.currentTimeMillis());
        }
        saveQuietly();
    }

    private void saveQuietly() {
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            store.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Failed to save playtime.yml: " + ex.getMessage());
        }
    }
}

