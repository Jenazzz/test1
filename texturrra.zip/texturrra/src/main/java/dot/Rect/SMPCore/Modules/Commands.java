package dot.Rect.SMPCore.Modules;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Modules.Admin.GetHomes;
import dot.Rect.SMPCore.Modules.Admin.GetPos;
import dot.Rect.SMPCore.Modules.Admin.PlayerIndex;
import dot.Rect.SMPCore.Modules.Admin.AdminTools;
import dot.Rect.SMPCore.Modules.Admin.CommandFilterModule;
import dot.Rect.SMPCore.Modules.Chat.PrivateMsgCmd;
import dot.Rect.SMPCore.Modules.Chat.BroadcastCmd;
import dot.Rect.SMPCore.Modules.NPC.NPCModule;
import dot.Rect.SMPCore.Modules.Ec.EcModule;
import dot.Rect.SMPCore.Modules.Playtime.PlaytimeModule;
import dot.Rect.SMPCore.Modules.Scoreboard.ScoreboardModule;
import dot.Rect.SMPCore.Modules.Sell.SellModule;
import dot.Rect.SMPCore.Modules.Sell.MultiModule;
import dot.Rect.SMPCore.Modules.TPA.TpaModule;
import dot.Rect.SMPCore.Modules.Warp.SetWarpCmd;
import dot.Rect.SMPCore.Modules.Warp.WarpModule;
import dot.Rect.SMPCore.Modules.Warp.DelWarpCmd;
import dot.Rect.SMPCore.Modules.Hub.HubCosmeticsModule;
import dot.Rect.SMPCore.Modules.Trade.TradeModule;
import dot.Rect.SMPCore.Modules.Value.Economy;
import dot.Rect.SMPCore.Modules.Value.BankUI;
import dot.Rect.SMPCore.Modules.Value.ValueItems;
import dot.Rect.SMPCore.Modules.Value.BankInterestModule;
import dot.Rect.SMPCore.Modules.Value.ValueLoreModule;
import dot.Rect.SMPCore.Util.Amounts;
import dot.Rect.SMPCore.Util.Text;
import dot.Rect.SMPCore.Util.TeleportService;
import org.bukkit.Bukkit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class Commands {
    private final JavaPlugin plugin;
    private final Homes homes;
    private final SessionConfirmation confirmation;
    private final Economy economy;
    private final NPCModule npcModule;
    private final EcModule ec;
    private final WarpModule warps;
    private final TradeModule trade;
    private final PlayerIndex playerIndex;
    private final AdminTools adminTools;
    private final CommandFilterModule commandFilter;
    private final ValueItems valueItems;
    private final ValueLoreModule valueLore;
    private final SellModule sellModule;
    private final MultiModule multiModule;
    private final TeleportService tp;
    private final BankUI bankUI;
    private final BankInterestModule bankInterest;
    private final TpaModule tpa;
    private final PlaytimeModule playtime;
    private final ScoreboardModule scoreboard;

    public Commands(JavaPlugin plugin, Homes homes, SessionConfirmation confirmation, PlayerIndex playerIndex,
                    HubCosmeticsModule hubCosmetics) {
        this.plugin = plugin;
        this.homes = homes;
        this.confirmation = confirmation;
        this.playerIndex = playerIndex;
        this.economy = new Economy(plugin);
        this.tp = new TeleportService(plugin);
        this.npcModule = new NPCModule(plugin, tp);
        this.ec = new EcModule(plugin, playerIndex);
        this.warps = new WarpModule(plugin, confirmation, tp);
        this.trade = new TradeModule(plugin, confirmation, tp, hubCosmetics::blockedFromExternalStorage);
        this.valueItems = new ValueItems(plugin);
        this.valueLore = new ValueLoreModule(plugin, valueItems);
        this.sellModule = new SellModule(plugin, economy, valueItems, confirmation);
        this.multiModule = new MultiModule(plugin, confirmation);
        this.bankUI = new BankUI(plugin, economy);
        this.bankInterest = new BankInterestModule(plugin, economy);
        this.tpa = new TpaModule(plugin, confirmation, tp);
        this.playtime = new PlaytimeModule(plugin);
        this.scoreboard = new ScoreboardModule(plugin, economy, playtime);
        this.adminTools = new AdminTools(plugin);
        this.commandFilter = new CommandFilterModule(plugin);
    }

    public void register() {
        bind("sethome", new SetHomeCmd());
        bind("home", new HomeCmd());
        bind("delhome", new DelHomeCmd());
        bind("confirm", new ConfirmCmd());
        bind("spawn", new SpawnCmd("survival1"));
        bind("hub", new SpawnCmd("hub1"));
        bind("info", new InfoCmd());
        bind("information", new InfoCmd());
        bind("help", new HelpCmd());
        bind("stats", new StatsCmd());
        bind("crates", new NotReadyCmd("&e/crates &7— скоро."));
        bind("shop", new NotReadyCmd("&e/shop &7— скоро."));
        bind("sell", sellModule);
        bind("multi", multiModule);
        bind("tpa", tpa.tpa());
        bind("tpahere", tpa.tpahere());
        bind("tpaccept", tpa.tpaccept());
        bind("tpdeny", tpa.tpdeny());
        bind("playtime", new PlaytimeCmd());
        bind("pt", new PlaytimeCmd());
        bind("trade", trade);
        bind("ah", new NotReadyCmd("&e/ah &7— скоро."));
        bind("warp", warps);
        bind("setwarp", new SetWarpCmd(confirmation, warps));
        bind("delwarp", new DelWarpCmd(confirmation, warps));
        bind("arena", new NotReadyCmd("&e/arena &7— скоро."));
        bind("duel", new NotReadyCmd("&e/duel &7— скоро."));
        bind("creates", new NotReadyCmd("&e/creates &7— скоро.")); // placeholder
        bind("kit", new NotReadyCmd("&e/kit &7— скоро (будет в Core/Kit модуле)."));
        bind("gm", adminTools.gm());
        bind("fly", adminTools.fly());
        bind("god", adminTools.god());
        bind("speed", adminTools.speed());
        bind("flyspeed", adminTools.flyspeed());
        bind("fspeed", adminTools.flyspeed());
        bind("day", adminTools.day());
        bind("night", adminTools.night());
        bind("clear", adminTools.clear());
        bind("tps", adminTools.tps());
        bind("msg", new PrivateMsgCmd());
        bind("m", new PrivateMsgCmd());
        bind("bc", new BroadcastCmd());
        bind("broadcast", new BroadcastCmd());

        // Admin
        bind("gethomes", new GetHomes(plugin, homes, playerIndex));
        bind("getpos", new GetPos(playerIndex));

        // Economy
        economy.load();
        valueItems.load();
        valueLore.load();
        sellModule.load();
        multiModule.load();
        bankUI.load();
        bankInterest.load();
        playtime.load();
        scoreboard.load();
        bind("money", new MoneyCmd());
        bind("bal", new MoneyCmd());
        bind("balance", new MoneyCmd());
        bind("pay", new PayCmd());
        bind("bank", new BankCmd());

        // PlaceholderAPI hook (optional)
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                var expansion = new dot.Rect.SMPCore.Modules.Placeholders.SmpcoreExpansion(economy, playtime, plugin.getDataFolder());
                expansion.register();
                plugin.getLogger().info("Hooked PlaceholderAPI: %smpcore_*%");
            } catch (Throwable t) {
                plugin.getLogger().warning("Failed to hook PlaceholderAPI: " + t.getMessage());
            }
        }

        // NPC
        npcModule.load();
        bind("npc", npcModule);
        adminTools.load();
        commandFilter.load();

        // EC
        ec.load();
        bind("ec", ec);
        bind("enderchest", ec);

        // Warps
        warps.load();

        // Trade
        trade.load();
    }

    public void shutdown() {
        try {
            playtime.flushAll();
        } catch (Throwable ignored) {
        }
    }

    private void bind(String name, CommandExecutor exec) {
        var cmd = plugin.getCommand(name);
        if (cmd == null) {
            plugin.getLogger().warning("Command not found in paper-plugin.yml: " + name);
            return;
        }
        cmd.setExecutor(exec);
        if (exec instanceof TabCompleter tc) cmd.setTabCompleter(tc);
    }

    private boolean requirePlayer(CommandSender sender) {
        if (sender instanceof Player) return true;
        Text.msg(sender, "&cТолько для игроков.");
        return false;
    }

    private boolean requireConfirmed(Player player) {
        if (confirmation.isConfirmed(player.getUniqueId())) return true;

        var pending = confirmation.getPending(player.getUniqueId());
        if (pending == null) {
            var code = confirmation.issueCode(player);
            Text.msg(player, "&eПодтверди сессию командой: &f/confirm " + code);
            Text.msg(player, "&7(позже подключим Discord/Telegram подтверждение)");
        } else {
            Text.msg(player, "&eПодтверди сессию: &f/confirm " + pending.code());
        }
        return false;
    }

    private final class SetHomeCmd implements CommandExecutor, TabCompleter {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!requirePlayer(sender)) return true;
            var player = (Player) sender;
            if (!requireConfirmed(player)) return true;

            String rawName = args.length >= 1 ? args[0] : "home";
            var name = Homes.normalizeName(rawName);
            if (name == null) {
                Text.msg(player, "&cИмя дома: &fa-z 0-9 _ - &7(до 16 символов).");
                return true;
            }
            if (!homes.canCreateAnotherHome(player, name)) {
                var limit = homes.getHomeLimit(player);
                Text.msg(player, "&cЛимит домов: &f" + limit + "&c. Удали/перезапиши существующий дом.");
                return true;
            }
            homes.setHome(player, name);
            Text.msg(player, "&aДом сохранён: &f" + name + " &8(/home " + name + ")");
            return true;
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
            return List.of();
        }
    }

    private final class HomeCmd implements CommandExecutor, TabCompleter {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!requirePlayer(sender)) return true;
            var player = (Player) sender;
            if (!requireConfirmed(player)) return true;

            String rawName = args.length >= 1 ? args[0] : "home";
            var name = Homes.normalizeName(rawName);
            var loc = homes.getHome(player.getUniqueId(), name);
            if (loc == null) {
                Text.msg(player, "&cДом не найден: &f" + rawName);
                return true;
            }
            tp.teleportWithCountdown(player, loc, "SOSIDRILLA SMP", "");
            return true;
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
            if (!(sender instanceof Player p)) return List.of();
            if (args.length != 1) return List.of();
            var prefix = args[0].toLowerCase(Locale.ROOT);
            var out = new ArrayList<String>();
            for (var home : homes.listHomes(p.getUniqueId())) {
                if (home.startsWith(prefix)) out.add(home);
            }
            return out;
        }
    }

    private final class DelHomeCmd implements CommandExecutor, TabCompleter {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!requirePlayer(sender)) return true;
            var player = (Player) sender;
            if (!requireConfirmed(player)) return true;

            String rawName = args.length >= 1 ? args[0] : "home";
            var name = Homes.normalizeName(rawName);
            if (name == null) {
                Text.msg(player, "&cИспользование: &f/delhome <name>");
                return true;
            }
            if (!homes.deleteHome(player.getUniqueId(), name)) {
                Text.msg(player, "&cДом не найден: &f" + name);
                return true;
            }
            Text.msg(player, "&aДом удалён: &f" + name);
            return true;
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
            if (!(sender instanceof Player p)) return List.of();
            if (args.length != 1) return List.of();
            var prefix = args[0].toLowerCase(Locale.ROOT);
            var out = new ArrayList<String>();
            for (var home : homes.listHomes(p.getUniqueId())) {
                if (home.startsWith(prefix)) out.add(home);
            }
            return out;
        }
    }

    private final class ConfirmCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!requirePlayer(sender)) return true;
            var player = (Player) sender;

            if (confirmation.isConfirmed(player.getUniqueId())) {
                Text.msg(player, "&aТы уже подтверждён.");
                return true;
            }

            if (args.length != 1) {
                var code = confirmation.issueCode(player);
                Text.msg(player, "&eКод подтверждения: &f" + code);
                Text.msg(player, "&7Используй: &f/confirm <code>");
                return true;
            }

            if (!confirmation.tryConfirm(player, args[0])) {
                Text.msg(player, "&cНеверный код. Напиши &f/confirm &cещё раз, чтобы получить новый.");
            }
            return true;
        }
    }

    private final class SpawnCmd implements CommandExecutor {
        private final String worldName;
        private SpawnCmd(String worldName) { this.worldName = worldName; }
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!requirePlayer(sender)) return true;
            var player = (Player) sender;
            if (!requireConfirmed(player)) return true;

            var world = Bukkit.getWorld(worldName);
            if (world == null) {
                Text.msg(player, "&cМир спавна не найден: &f" + worldName);
                return true;
            }
            tp.teleportWithCountdown(player, world.getSpawnLocation(), "SOSIDRILLA SMP", "");
            return true;
        }
    }

    private final class InfoCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cТолько для игроков.");
                return true;
            }

            // If server config.yml is old (saveDefaultConfig doesn't overwrite), we still show your actual links.
            String site = pick(plugin.getConfig().getString("info.site", ""), "скоро");
            String discord = pick(plugin.getConfig().getString("info.discord", ""), "скоро");

            // COCUCON defaults
            String tiktok = pick(plugin.getConfig().getString("info.tiktok", ""), "https://www.tiktok.com/@sosison4ik22");
            String twitch = pick(plugin.getConfig().getString("info.twitch", ""), "https://www.twitch.tv/sosisonlol");
            String telegram = pick(plugin.getConfig().getString("info.telegram", ""), "https://t.me/sosisonlol");
            String instagram = pick(plugin.getConfig().getString("info.instagram", ""), "https://www.instagram.com/vovacowboy?igsh=aGl4a20ybmZkejZn&utm_source=qr");
            String collabTg = pick(plugin.getConfig().getString("info.collaboration.telegram", ""), "@sosisonofficial");
            String collabMail = pick(plugin.getConfig().getString("info.collaboration.email", ""), "cocuconyt@mail.ru");

            // P DRILLA defaults
            String owner2Name = "P Drilla";
            String owner2Tiktok = pick(plugin.getConfig().getString("info.owner2.tiktok", ""), "https://www.tiktok.com/@p.drilla83?_t=ZN-8ysfAOQh7qQ&_r=1");
            String owner2Twitch = pick(plugin.getConfig().getString("info.owner2.twitch", ""), "https://www.twitch.tv/gamynkylyss");
            String owner2Telegram = pick(plugin.getConfig().getString("info.owner2.telegram", ""), "https://t.me/drilla8");
            String owner2Collab = pick(plugin.getConfig().getString("info.owner2.collaboration", ""), "@AXXABXAXAXAXAX");

            p.sendMessage(Component.text("================", NamedTextColor.DARK_GRAY));
            p.sendMessage(Component.text("SOSIDRILLA SMP", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));
            p.sendMessage(linkLine("Сайт", site));
            p.sendMessage(Component.empty());
            p.sendMessage(Component.text("COCUCON", NamedTextColor.LIGHT_PURPLE).decorate(TextDecoration.BOLD));
            p.sendMessage(linkLine("TikTok", tiktok));
            p.sendMessage(linkLine("Twitch", twitch));
            p.sendMessage(linkLine("Telegram", telegram));
            p.sendMessage(linkLine("Instagram", instagram));
            p.sendMessage(Component.empty());
            p.sendMessage(Component.text("Сотрудничество", NamedTextColor.GRAY).decorate(TextDecoration.BOLD));
            p.sendMessage(linkLine("TG", collabTg));
            p.sendMessage(linkLine("Mail", collabMail));
            p.sendMessage(Component.empty());
            p.sendMessage(Component.text(owner2Name, NamedTextColor.AQUA).decorate(TextDecoration.BOLD));
            p.sendMessage(linkLine("TikTok", owner2Tiktok));
            p.sendMessage(linkLine("Twitch", owner2Twitch));
            p.sendMessage(linkLine("Telegram", owner2Telegram));
            p.sendMessage(linkLine("Сотрудничество", owner2Collab));
            p.sendMessage(Component.empty());
            p.sendMessage(linkLine("Discord", discord));
            p.sendMessage(Component.text("================", NamedTextColor.DARK_GRAY));
            return true;
        }

        private String pick(String fromConfig, String fallback) {
            if (fromConfig == null) return fallback;
            String v = fromConfig.trim();
            if (v.isEmpty()) return fallback;
            if (v.equalsIgnoreCase("скоро")) return fallback;
            return v;
        }

        private Component linkLine(String name, String value) {
            var base = Component.text("• ", NamedTextColor.DARK_GRAY)
                    .append(Component.text(name, NamedTextColor.LIGHT_PURPLE).decorate(TextDecoration.BOLD));

            if (value == null || value.isBlank() || value.equalsIgnoreCase("скоро")) {
                return base.append(Component.text(" (скоро)", NamedTextColor.GRAY));
            }

            // No clicks, no raw URLs. Just show a short handle/name.
            return base.append(Component.text(" " + pretty(value.trim()), NamedTextColor.WHITE));
        }

        private String pretty(String raw) {
            if (raw.startsWith("@")) return raw;
            if (raw.contains("@") && !raw.contains(" ") && !raw.startsWith("http")) return raw; // email / handle
            String s = raw;
            if (s.startsWith("http://")) s = s.substring("http://".length());
            if (s.startsWith("https://")) s = s.substring("https://".length());
            // t.me/<name>
            if (s.startsWith("t.me/")) {
                String name = s.substring("t.me/".length());
                int q = name.indexOf('?');
                if (q >= 0) name = name.substring(0, q);
                return "@" + name;
            }
            // tiktok.com/@name
            int at = s.indexOf("/@");
            if (at >= 0) {
                String name = s.substring(at + 2);
                int slash = name.indexOf('/');
                if (slash >= 0) name = name.substring(0, slash);
                int q = name.indexOf('?');
                if (q >= 0) name = name.substring(0, q);
                return "@" + name;
            }
            // twitch.tv/name
            if (s.startsWith("www.twitch.tv/")) s = s.substring("www.twitch.tv/".length());
            if (s.startsWith("twitch.tv/")) s = s.substring("twitch.tv/".length());
            int slash = s.indexOf('/');
            if (slash >= 0) s = s.substring(0, slash);
            int q = s.indexOf('?');
            if (q >= 0) s = s.substring(0, q);
            // if still looks like domain, just show it
            return s;
        }
    }

    private final class PlaytimeCmd implements CommandExecutor, TabCompleter {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cТолько для игроков.");
                return true;
            }
            if (args.length == 0) {
                Text.msg(p, "&d⏱ &7Время на сервере: &f" + playtime.format(p.getUniqueId()));
                return true;
            }
            if (args.length == 1) {
                String name = args[0];
                UUID uuid = playerIndex.resolveUuidByName(name);
                if (uuid == null) {
                    Text.msg(p, "&cИгрок не найден: &f" + name);
                    return true;
                }
                Text.msg(p, "&d⏱ &7Время &f" + name + "&7: &f" + playtime.format(uuid));
                return true;
            }
            Text.msg(p, "&cИспользование: &f/" + label + " [player]");
            return true;
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
            return List.of();
        }
    }

    private final class HelpCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            Text.msg(sender, "&8&m----------------------------------------");
            Text.msg(sender, "&b&lSOSIDRILLA SMP &8• &7Команды");
            Text.msg(sender, "&f/hub &8→ &7Хаб   &f/spawn &8→ &7Выживание");
            Text.msg(sender, "&f/sethome &7[name] &8• &f/home &7[name] &8• &f/delhome &7[name]");
            Text.msg(sender, "&f/money &8/&f/bal &8/&f/balance &8• &f/pay <ник> <сумма>");
            Text.msg(sender, "&f/bank &8• &f/sell &8• &f/multi &8• &f/pt");
            Text.msg(sender, "&f/confirm <код> &8• &f/info");
            Text.msg(sender, "&8&m----------------------------------------");
            return true;
        }
    }

    private final class StatsCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            Player target = null;
            if (args.length == 0) {
                if (!(sender instanceof Player p)) {
                    Text.msg(sender, "&cИспользование: /stats <player>");
                    return true;
                }
                target = p;
            } else if (args.length == 1) {
                target = Bukkit.getPlayerExact(args[0]);
                if (target == null) {
                    Text.msg(sender, "&cИгрок не найден онлайн: &f" + args[0]);
                    return true;
                }
            } else {
                Text.msg(sender, "&cИспользование: /stats или /stats <player>");
                return true;
            }

            Text.msg(sender, "&bСтатистика &f" + target.getName());
            Text.msg(sender, "&7Здоровье: &f" + Math.round(target.getHealth()) + "&7/&f" + Math.round(target.getMaxHealth()));
            Text.msg(sender, "&7Уровень: &f" + target.getLevel());
            Text.msg(sender, "&7Мир: &f" + target.getWorld().getName());
            return true;
        }
    }

    private static final class NotReadyCmd implements CommandExecutor {
        private final String msg;
        private NotReadyCmd(String msg) { this.msg = msg; }
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            Text.msg(sender, msg);
            return true;
        }
    }

    private final class MoneyCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cТолько для игроков.");
                return true;
            }
            var bal = economy.getBalance(p.getUniqueId());
            Text.msg(p, "&aБаланс: &f" + bal);
            return true;
        }
    }

    private final class PayCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cТолько для игроков.");
                return true;
            }
            if (!requireConfirmed(p)) return true;
            if (args.length != 2) {
                Text.msg(p, "&cИспользование: /pay <player> <amount>");
                return true;
            }
            var target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                Text.msg(p, "&cИгрок не найден онлайн: &f" + args[0]);
                return true;
            }
            long amount;
            try {
                amount = Amounts.parse(args[1]);
            } catch (NumberFormatException e) {
                Text.msg(p, "&cСумма: &f100 &7/ &f1k &7/ &f1m &7/ &f1b");
                return true;
            }
            if (amount <= 0) {
                Text.msg(p, "&cСумма должна быть > 0.");
                return true;
            }
            if (p.getUniqueId().equals(target.getUniqueId())) {
                Text.msg(p, "&cНельзя переводить самому себе.");
                return true;
            }
            if (!economy.withdraw(p.getUniqueId(), amount)) {
                Text.msg(p, "&cНедостаточно средств.");
                return true;
            }
            economy.deposit(target.getUniqueId(), amount);
            Text.msg(p, "&aПеревод: &f" + amount + " &7→ &f" + target.getName());
            Text.msg(target, "&aПолучено: &f" + amount + " &7от &f" + p.getName());
            return true;
        }
    }

    private final class BankCmd implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                Text.msg(sender, "&cТолько для игроков.");
                return true;
            }
            if (!requireConfirmed(p)) return true;

            if (args.length == 0) {
                bankUI.open(p);
                return true;
            }
            Text.msg(p, "&cИспользование: &f/bank");
            return true;
        }
    }
}

