package dot.Rect.SMPCore.Modules.Admin;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.ArrayList;

public final class CommandFilterModule implements Listener {
    private final JavaPlugin plugin;

    public CommandFilterModule(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onSend(PlayerCommandSendEvent e) {
        if (!cfgBool("command-filter.enabled", true)) return;
        Player p = e.getPlayer();
        if (p != null && canBypass(p)) return;

        Rules hide = Rules.from(plugin.getConfig().getStringList("command-filter.hide"));
        boolean hideOwnNamespaced = cfgBool("command-filter.hide-own-namespaced", true);
        String ownNs = plugin.getName().toLowerCase(Locale.ROOT) + ":";
        if (hide.isEmpty() && !hideOwnNamespaced) return;

        // event set contains command names (without leading slash)
        e.getCommands().removeIf(cmd -> {
            String n = normalize(cmd);
            if (hideOwnNamespaced && n.startsWith(ownNs)) return true;
            if (!hide.matches(n)) return false;
            // Never hide our own plugin commands (we may intentionally "replace" vanilla ones like /tps)
            return !isOwnedByThisPlugin(n);
        });
    }

    @EventHandler
    public void onPreprocess(PlayerCommandPreprocessEvent e) {
        if (!cfgBool("command-filter.enabled", true)) return;
        Player p = e.getPlayer();
        if (p != null && canBypass(p)) return;

        String msg = e.getMessage();
        if (msg == null || msg.isBlank()) return;
        if (!msg.startsWith("/")) return;

        String root = msg.substring(1).trim();
        if (root.isEmpty()) return;

        // root command token (may contain namespace like bukkit:plugins)
        String[] parts = root.split("\\s+");
        String cmd = normalize(parts[0]);

        Rules blocked = Rules.from(plugin.getConfig().getStringList("command-filter.block"));
        if (blocked.matches(cmd) && !isOwnedByThisPlugin(cmd)) {
            e.setCancelled(true);
            Text.msg(p, plugin.getConfig().getString("command-filter.message", "&cКуда лезем, сынок. <3"));
        }
    }

    private boolean canBypass(Player p) {
        String perm = plugin.getConfig().getString("command-filter.bypass-permission", "smpcore.commandfilter.bypass");
        return p.isOp() || (perm != null && !perm.isBlank() && p.hasPermission(perm));
    }

    private boolean cfgBool(String path, boolean def) {
        try {
            return plugin.getConfig().getBoolean(path, def);
        } catch (Throwable ignored) {
            return def;
        }
    }

    private boolean isOwnedByThisPlugin(String raw) {
        if (raw == null || raw.isBlank()) return false;
        String n = normalize(raw);

        // Try both full and stripped namespace
        if (isOwnedByThisPlugin0(n)) return true;
        int i = n.indexOf(':');
        if (i > 0 && i + 1 < n.length()) {
            String stripped = n.substring(i + 1);
            return isOwnedByThisPlugin0(stripped);
        }
        return false;
    }

    private boolean isOwnedByThisPlugin0(String name) {
        try {
            PluginCommand pc = Bukkit.getPluginCommand(name);
            if (pc == null) return false;
            return pc.getPlugin() != null && pc.getPlugin().getName().equalsIgnoreCase(plugin.getName());
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static String normalize(String s) {
        if (s == null) return "";
        return s.trim().toLowerCase(Locale.ROOT);
    }

    private static final class Rules {
        private final Set<String> exact;
        private final List<String> prefixes;

        private Rules(Set<String> exact, List<String> prefixes) {
            this.exact = exact;
            this.prefixes = prefixes;
        }

        static Rules from(List<String> raw) {
            Set<String> exact = new HashSet<>();
            List<String> prefixes = new ArrayList<>();
            if (raw != null) {
                for (String s : raw) {
                    String n = normalize(s);
                    if (n.isEmpty()) continue;
                    if (n.endsWith("*")) {
                        String pre = n.substring(0, n.length() - 1);
                        if (!pre.isEmpty()) prefixes.add(pre);
                    } else {
                        exact.add(n);
                    }
                }
            }
            return new Rules(exact, prefixes);
        }

        boolean isEmpty() {
            return exact.isEmpty() && prefixes.isEmpty();
        }

        boolean matches(String cmd) {
            if (cmd == null) return false;
            String n = normalize(cmd);
            if (exact.contains(n)) return true;
            for (String pre : prefixes) {
                if (n.startsWith(pre)) return true;
            }
            return false;
        }
    }
}

