package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

interface ActiveSaunaSession {
    UUID ownerUuid();

    boolean containsEffectZone(Location loc);

    boolean protectsBlock(Block block);

    void forceEnd();
}

/** Активные сессии «Мужской бани» — зона 15×15 с PvP и эффектами. */
public final class HubSaunaRegistry {
    private static final List<ActiveSaunaSession> SESSIONS = new CopyOnWriteArrayList<>();

    private HubSaunaRegistry() {}

    static void register(ActiveSaunaSession session) {
        SESSIONS.add(session);
    }

    static void unregister(ActiveSaunaSession session) {
        SESSIONS.remove(session);
    }

    public static boolean hasActiveSession() {
        return !SESSIONS.isEmpty();
    }

    /** Игрок внутри коробки активной бани 5×5×5 (для урона / без полного хила). */
    public static boolean isInSaunaEffectZone(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        for (ActiveSaunaSession s : SESSIONS) {
            if (s.containsEffectZone(loc)) return true;
        }
        return false;
    }

    public static void endAllForOwner(UUID ownerUuid) {
        for (ActiveSaunaSession s : List.copyOf(SESSIONS)) {
            if (ownerUuid.equals(s.ownerUuid())) {
                s.forceEnd();
            }
        }
    }

    public static boolean protectsAnySaunaBlock(Block block) {
        if (block == null) return false;
        for (ActiveSaunaSession s : SESSIONS) {
            if (s.protectsBlock(block)) return true;
        }
        return false;
    }
}
