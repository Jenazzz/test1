package dot.Rect.SMPCore.API;

/**
 * Placeholder for Discord integration.
 * Planned: create link codes, accept confirmations from a bot, and call SessionConfirmation.markConfirmed(uuid).
 */
public final class DISCORD {
    private DISCORD() {}
}

