package dot.Rect.SMPCore.Modules;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class Homes {
    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration store;

    public Homes(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "homes.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
    }

    public Set<String> listHomes(UUID uuid) {
        var section = store.getConfigurationSection("homes." + uuid);
        if (section == null) return Set.of();
        return section.getKeys(false);
    }

    public boolean canCreateAnotherHome(Player player, String newHomeName) {
        var uuid = player.getUniqueId();
        var current = listHomes(uuid);
        // Overwrite does not count as creating new
        if (current.contains(newHomeName)) return true;

        int limit = getHomeLimit(player);
        if (limit < 0) return false;
        if (limit == Integer.MAX_VALUE) return true;
        return current.size() < limit;
    }

    public int getHomeLimit(Player player) {
        if (player.hasPermission("smpcore.homes.unlimited")) return Integer.MAX_VALUE;

        int best = plugin.getConfig().getInt("homes.default-limit", 1);

        // Permission pattern: smpcore.homes.limit.<n>
        // Example: smpcore.homes.limit.3 gives 3 homes.
        for (int i = 1; i <= 200; i++) {
            if (player.hasPermission("smpcore.homes.limit." + i)) best = Math.max(best, i);
        }
        return best;
    }

    public boolean setHome(Player player, String name) {
        if (name == null || name.isBlank()) name = "home";
        name = normalizeName(name);
        if (name == null) return false;

        var base = "homes." + player.getUniqueId() + "." + name;
        var loc = player.getLocation();
        store.set(base + ".world", loc.getWorld().getName());
        store.set(base + ".x", loc.getX());
        store.set(base + ".y", loc.getY());
        store.set(base + ".z", loc.getZ());
        store.set(base + ".yaw", loc.getYaw());
        store.set(base + ".pitch", loc.getPitch());
        saveQuietly();
        return true;
    }

    public boolean deleteHome(UUID uuid, String name) {
        if (name == null || name.isBlank()) name = "home";
        name = normalizeName(name);
        if (name == null) return false;
        var base = "homes." + uuid + "." + name;
        if (!store.contains(base)) return false;
        store.set(base, null);
        // cleanup empty section
        var section = store.getConfigurationSection("homes." + uuid);
        if (section != null && section.getKeys(false).isEmpty()) {
            store.set("homes." + uuid, null);
        }
        saveQuietly();
        return true;
    }

    public Location getHome(UUID uuid, String name) {
        name = normalizeName(name);
        if (name == null) return null;

        var base = "homes." + uuid + "." + name;
        if (!store.contains(base + ".world")) return null;

        var worldName = store.getString(base + ".world");
        var world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        var x = store.getDouble(base + ".x");
        var y = store.getDouble(base + ".y");
        var z = store.getDouble(base + ".z");
        var yaw = (float) store.getDouble(base + ".yaw");
        var pitch = (float) store.getDouble(base + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public static String normalizeName(String name) {
        if (name == null) return null;
        name = name.trim().toLowerCase(Locale.ROOT);
        if (name.isEmpty()) return null;
        if (name.length() > 16) return null;
        if (!name.matches("[a-z0-9_\\-]+")) return null;
        return name;
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (IOException e) {
            Text.info(plugin.getLogger(), "Failed to save homes.yml: " + e.getMessage());
        }
    }
}

