package dot.Rect.SMPCore.Modules.Warp;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class DelWarpCmd implements CommandExecutor {
    private final SessionConfirmation confirmation;
    private final WarpModule warps;

    public DelWarpCmd(SessionConfirmation confirmation, WarpModule warps) {
        this.confirmation = confirmation;
        this.warps = warps;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!p.hasPermission("smpcore.warp.del") && !p.isOp()) {
            Text.msg(p, "&cНет прав: &fsmpcore.warp.del");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }
        if (args.length != 1) {
            Text.msg(p, "&cИспользование: &f/delwarp <name>");
            return true;
        }
        if (!warps.delWarp(args[0])) {
            Text.msg(p, "&cВарп не найден: &f" + args[0]);
            return true;
        }
        Text.msg(p, "&aВарп удалён: &f" + args[0]);
        return true;
    }
}

