package dot.Rect.SMPCore.API;

/**
 * Placeholder for Telegram integration.
 * Planned: accept confirmations from a bot, and call SessionConfirmation.markConfirmed(uuid).
 */
public final class TELEGRAM {
    private TELEGRAM() {}
}

