package dot.Rect.SMPCore.Modules.Placeholders;

import dot.Rect.SMPCore.Modules.Playtime.PlaytimeModule;
import dot.Rect.SMPCore.Modules.Value.Economy;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public final class SmpcoreExpansion extends PlaceholderExpansion {
    private final Economy economy;
    private final PlaytimeModule playtime;
    private final File dataFolder;

    public SmpcoreExpansion(Economy economy, PlaytimeModule playtime) {
        this.economy = economy;
        this.playtime = playtime;
        this.dataFolder = null;
    }

    public SmpcoreExpansion(Economy economy, PlaytimeModule playtime, File dataFolder) {
        this.economy = economy;
        this.playtime = playtime;
        this.dataFolder = dataFolder;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "smpcore";
    }

    @Override
    public @NotNull String getAuthor() {
        return "sosidrilla";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0";
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        return switch (params.toLowerCase()) {
            case "balance" -> String.valueOf(economy.getBalance(player.getUniqueId()));
            case "bank" -> String.valueOf(economy.getBank(player.getUniqueId()));
            case "playtime" -> playtime.format(player.getUniqueId());
            case "interest_timeleft" -> interestTimeLeft();
            case "interest_percent" -> formatPct(percentFor(economy.getBank(player.getUniqueId())));
            case "interest_gain" -> String.valueOf(calcGain(economy.getBank(player.getUniqueId())));
            default -> null;
        };
    }

    private String interestTimeLeft() {
        try {
            LocalTime target = LocalTime.parse(getCfg("bank-interest.time", "12:00"));
            LocalDate today = LocalDate.now();
            LocalDateTime now = LocalDateTime.now();

            LocalDateTime next = LocalDateTime.of(today, target);
            // if already passed today, next is tomorrow
            if (!now.isBefore(next)) {
                next = LocalDateTime.of(today.plusDays(1), target);
            }
            Duration d = Duration.between(now, next);
            return formatDuration(d);
        } catch (Exception e) {
            return "скоро";
        }
    }

    private long calcGain(long bank) {
        double pct = percentFor(bank);
        return Math.max(0, Math.round(bank * (pct / 100.0)));
    }

    private double percentFor(long bank) {
        // read from config.yml (fallback to defaults)
        try {
            var tiers = getCfgList("bank-interest.tiers");
            for (var t : tiers) {
                long min = toLong(t.get("min"), 0);
                long max = toLong(t.get("max"), -1);
                double pct = toDouble(t.get("percent"), 1.0);
                if (bank < min) continue;
                if (max != -1 && bank >= max) continue;
                return pct;
            }
        } catch (Exception ignored) {
        }
        if (bank < 50_000) return 5.0;
        if (bank < 300_000) return 3.0;
        return 1.0;
    }

    private String getCfg(String path, String def) {
        // PlaceholderAPI doesn't expose plugin instance here, so read plugin config.yml if provided
        if (dataFolder == null) return def;
        File f = new File(dataFolder, "config.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        return y.getString(path, def);
    }

    private java.util.List<java.util.Map<?, ?>> getCfgList(String path) {
        if (dataFolder == null) return java.util.List.of();
        File f = new File(dataFolder, "config.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        return y.getMapList(path);
    }

    private static String formatDuration(Duration d) {
        long sec = Math.max(0, d.getSeconds());
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        if (h > 0) return h + "ч " + m + "м";
        return m + "м";
    }

    private static String formatPct(double pct) {
        if (pct == (long) pct) return ((long) pct) + "%";
        return String.format(java.util.Locale.ROOT, "%.1f%%", pct);
    }

    private static long toLong(Object o, long def) {
        if (o instanceof Number n) return n.longValue();
        if (o instanceof String s) {
            try { return Long.parseLong(s.trim()); } catch (Exception ignored) {}
        }
        return def;
    }

    private static double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) {
            try { return Double.parseDouble(s.trim()); } catch (Exception ignored) {}
        }
        return def;
    }
}

