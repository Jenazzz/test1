package dot.Rect.SMPCore.Modules.Sell;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Locale;
import java.util.UUID;

public final class MultiModule implements Listener, CommandExecutor {
    private static final String UI_KEY = "smpcore_multi_key";
    private final JavaPlugin plugin;
    private final SessionConfirmation confirmation;
    private final File file;
    private final YamlConfiguration store;

    public MultiModule(JavaPlugin plugin, SessionConfirmation confirmation) {
        this.plugin = plugin;
        this.confirmation = confirmation;
        this.file = new File(plugin.getDataFolder(), "sell-progress.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }
        open(p);
        return true;
    }

    private void open(Player p) {
        // Reload to reflect latest sell-progress.yml updates
        store.options().copyDefaults(true);
        try {
            store.load(file);
        } catch (Exception ignored) {
        }
        Inventory inv = Bukkit.createInventory(p, 27, SellModule.MULTI_TITLE);

        put(inv, 10, p.getUniqueId(), "ores", Material.DIAMOND_ORE, "&bРуды");
        put(inv, 12, p.getUniqueId(), "gear", Material.DIAMOND_SWORD, "&dБроня/Оружие");
        put(inv, 14, p.getUniqueId(), "blocks", Material.BRICKS, "&eБлоки");
        put(inv, 16, p.getUniqueId(), "food", Material.GOLDEN_CARROT, "&aЕда/Растения");

        inv.setItem(22, infoItem(p.getUniqueId()));
        p.openInventory(inv);
    }

    private ItemStack infoItem(UUID uuid) {
        var item = new ItemStack(Material.NETHER_STAR);
        var meta = item.getItemMeta();
        meta.setDisplayName(Text.c("&f&lМножители"));
        meta.setLore(java.util.List.of(
                Text.c("&7Порог: &f10k &7→ &f25k &7→ &f50k &7→ &f100k…"),
                Text.c("&7Каждый порог даёт: &f+0.1x"),
                Text.c("&7Максимум: &f5.0x")
        ));
        item.setItemMeta(meta);
        return item;
    }

    private void put(Inventory inv, int slot, UUID uuid, String key, Material icon, String title) {
        long sold = store.getLong("players." + uuid + ".sold." + key, 0);
        int steps = SellModule.calcStepsFromSold(sold);
        double mult = Math.min(5.0, 1.0 + steps * 0.1);
        long next = SellModule.nextThreshold(sold);
        long prev = prevThreshold(sold);
        double progress = next <= prev ? 1.0 : (sold - prev) / (double) (next - prev);
        progress = Math.max(0, Math.min(1, progress));

        var item = new ItemStack(icon);
        var meta = item.getItemMeta();
        meta.setDisplayName(Text.c(title));
        meta.getPersistentDataContainer().set(new org.bukkit.NamespacedKey(plugin, UI_KEY), PersistentDataType.STRING, key);
        meta.setLore(java.util.List.of(
                Text.c("&7Множитель: &f" + String.format(Locale.US, "%.1f", mult) + "x &8(до 5.0x)"),
                Text.c("&7Продано: &f" + sold),
                Text.c("&7След. порог: &f" + next),
                Text.c("&7Прогресс: &f" + bar(progress) + " &7" + Math.round(progress * 100) + "%")
        ));
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    private long prevThreshold(long sold) {
        if (sold < 10_000) return 0;
        if (sold < 25_000) return 10_000;
        if (sold < 50_000) return 25_000;
        long prev = 50_000;
        long t = 100_000;
        while (sold >= t) {
            prev = t;
            if (t > Long.MAX_VALUE / 2) break;
            t *= 2;
        }
        return prev;
    }

    private String bar(double p) {
        int bars = 20;
        int filled = (int) Math.round(p * bars);
        StringBuilder sb = new StringBuilder();
        sb.append("&8[");
        for (int i = 0; i < bars; i++) {
            sb.append(i < filled ? "&a|" : "&7|");
        }
        sb.append("&8]");
        return Text.c(sb.toString());
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getView() == null) return;
        if (!SellModule.MULTI_TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
    }
}

