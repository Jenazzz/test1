package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class HomunculusHookCosmetic implements Listener {
    public static final double HOOK_MAX_RANGE = 60.0;

    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public HomunculusHookCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isCosmetic(hand, HubCosmeticIds.HOMUNCULUS_HOOK)) return;
        if (!e.getAction().name().contains("RIGHT_CLICK")) return;
        if (e.getAction().name().contains("BLOCK") && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        e.setCancelled(true);
        if (s.onCooldown(p, 800)) return;
        homunculusPull(p);
    }

    private void homunculusPull(Player p) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, dir, HOOK_MAX_RANGE, FluidCollisionMode.NEVER, true);
        if (r == null || r.getHitBlock() == null) {
            Text.msg(p, "&cНет блока в пределах " + (int) HOOK_MAX_RANGE + " блоков.");
            return;
        }
        Block b = r.getHitBlock();
        Location hitPoint = r.getHitPosition().toLocation(p.getWorld());
        Location target = b.getRelative(r.getHitBlockFace()).getLocation().add(0.5, 0.02, 0.5);
        double distEye = eye.distance(hitPoint);
        // Полёт паутины в ~1.5 раза быстрее: меньше тиков на ту же дистанцию
        int webTicks = Math.max(4, Math.min(14, (int) Math.ceil(distEye * 1.2 / 1.5)));

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !s.isHub(p)) {
                    cancel();
                    return;
                }
                if (t++ >= webTicks) {
                    cancel();
                    startPullAfterWeb(p, target);
                    return;
                }
                double frac = (t + 1.0) / webTicks;
                Vector pos = eye.toVector().clone().add(dir.clone().multiply(distEye * frac));
                Location l = pos.toLocation(p.getWorld());
                l.getWorld().spawnParticle(Particle.BLOCK, l, 4, 0.05, 0.05, 0.05, 0.01, Material.COBWEB.createBlockData());
                l.getWorld().spawnParticle(Particle.END_ROD, l, 2, 0.02, 0.02, 0.02, 0.001);
            }
        }.runTaskTimer(s.plugin(), 0L, 1L);
        p.playSound(p.getLocation(), Sound.BLOCK_COBWEB_STEP, 0.4f, 1.5f);
    }

    private void startPullAfterWeb(Player p, Location target) {
        Vector total = target.toVector().subtract(p.getLocation().toVector());
        double len = total.length();
        if (len < 0.5) return;
        int steps = Math.max(5, Math.min(14, (int) Math.ceil(len * 1.2 / 1.5)));
        Vector step = total.multiply(1.0 / steps);
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !s.isHub(p)) {
                    cancel();
                    return;
                }
                if (i++ >= steps) {
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 20, 0.25, 0.25, 0.25, 0.08);
                    p.playSound(p.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, 0.5f, 1.4f);
                    cancel();
                    return;
                }
                p.setVelocity(step.clone().multiply(0.9));
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 2, 0.12, 0.12, 0.12, 0.01);
            }
        }.runTaskTimer(s.plugin(), 0L, 1L);
    }
}
