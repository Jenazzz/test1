package dot.Rect.SMPCore.Modules.Hub;

import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

/** Ось-выровненный AABB зоны арены в мире хаба (координаты из config). */
public final class HubPvpBounds {
    /** Если в старом config.yml нет углов — те же значения, что в ресурсном config. */
    private static final double DEF_X1 = -7, DEF_Y1 = 68, DEF_Z1 = -26;
    private static final double DEF_X2 = -20, DEF_Y2 = 76, DEF_Z2 = -43;

    private HubPvpBounds() {}

    /**
     * По умолчанию {@code true}: иначе у существующего {@code plugins/.../config.yml} без секции
     * {@code hub.pvp-arena} модуль вообще не загружался. Явно задайте {@code enabled: false}, чтобы выключить.
     */
    public static boolean enabled(JavaPlugin plugin) {
        var c = plugin.getConfig();
        if (c.isSet("hub.pvp-arena.enabled")) {
            return c.getBoolean("hub.pvp-arena.enabled");
        }
        return true;
    }

    public static String hubWorldName(JavaPlugin plugin) {
        String w = plugin.getConfig().getString("hub.immortal.world");
        if (w == null || w.isBlank()) {
            w = plugin.getConfig().getString("spawn.world", "hub1");
        }
        return w;
    }

    public static boolean contains(JavaPlugin plugin, Location loc) {
        if (!enabled(plugin) || loc == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().getName().equalsIgnoreCase(hubWorldName(plugin))) return false;

        var c = plugin.getConfig();
        double x1 = c.getDouble("hub.pvp-arena.corner1.x", DEF_X1);
        double y1 = c.getDouble("hub.pvp-arena.corner1.y", DEF_Y1);
        double z1 = c.getDouble("hub.pvp-arena.corner1.z", DEF_Z1);
        double x2 = c.getDouble("hub.pvp-arena.corner2.x", DEF_X2);
        double y2 = c.getDouble("hub.pvp-arena.corner2.y", DEF_Y2);
        double z2 = c.getDouble("hub.pvp-arena.corner2.z", DEF_Z2);
        double minX = Math.min(x1, x2);
        double maxX = Math.max(x1, x2);
        double minY = Math.min(y1, y2);
        double maxY = Math.max(y1, y2);
        double minZ = Math.min(z1, z2);
        double maxZ = Math.max(z1, z2);
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }
}
