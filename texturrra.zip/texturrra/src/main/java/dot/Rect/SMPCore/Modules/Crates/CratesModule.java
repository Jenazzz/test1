package dot.Rect.SMPCore.Modules.Crates;

/**
 * Placeholder for crates module.
 * Planned: GUI, keys, rewards, pity, logging, and integration with economy.
 */
public final class CratesModule {
}

