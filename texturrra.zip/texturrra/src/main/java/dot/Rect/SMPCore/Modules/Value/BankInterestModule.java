package dot.Rect.SMPCore.Modules.Value;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.UUID;

public final class BankInterestModule implements Listener {
    private final JavaPlugin plugin;
    private final Economy economy;
    private final File stateFile;
    private final YamlConfiguration state;

    public BankInterestModule(JavaPlugin plugin, Economy economy) {
        this.plugin = plugin;
        this.economy = economy;
        this.stateFile = new File(plugin.getDataFolder(), "bank-interest.yml");
        this.state = YamlConfiguration.loadConfiguration(stateFile);
    }

    public void load() {
        saveStateQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        // grant when player joins (no server-wide spike at 12:00)
        Bukkit.getScheduler().runTaskLater(plugin, () -> tryGrant(e.getPlayer()), 20L);
    }

    public void tryGrant(Player p) {
        if (p == null || !p.isOnline()) return;
        if (!plugin.getConfig().getBoolean("bank-interest.enabled", true)) return;

        LocalTime target = parseTarget();
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();
        if (now.isBefore(target)) return; // not yet time today

        UUID uuid = p.getUniqueId();
        String last = state.getString("players." + uuid + ".last-date", "");
        if (today.toString().equalsIgnoreCase(last)) return; // already got today

        long bank = economy.getBank(uuid);
        if (bank <= 0) {
            state.set("players." + uuid + ".last-date", today.toString());
            saveStateQuietly();
            return;
        }

        double pct = percentFor(bank);
        long add = Math.max(0, Math.round(bank * (pct / 100.0)));
        economy.bankDeposit(uuid, add);

        // Mark claimed for TODAY only (even if missed multiple days)
        state.set("players." + uuid + ".last-date", today.toString());
        saveStateQuietly();

        Text.msg(p, "&b🪙 &7Инвестиции начислены: &f+" + add + "$ &8(&f" + pct + "%&8)");
    }

    private double percentFor(long bank) {
        // tiers are in config.yml, but defaults to your requested values
        var tiers = plugin.getConfig().getMapList("bank-interest.tiers");
        for (var t : tiers) {
            long min = toLong(t.get("min"), 0);
            long max = toLong(t.get("max"), -1);
            double pct = toDouble(t.get("percent"), 1.0);
            if (bank < min) continue;
            if (max != -1 && bank >= max) continue;
            return pct;
        }
        return 1.0;
    }

    private LocalTime parseTarget() {
        String at = plugin.getConfig().getString("bank-interest.time", "12:00");
        try {
            return LocalTime.parse(at);
        } catch (Exception ignored) {
            return LocalTime.of(12, 0);
        }
    }

    private static long toLong(Object o, long def) {
        if (o instanceof Number n) return n.longValue();
        if (o instanceof String s) {
            try { return Long.parseLong(s.trim()); } catch (Exception ignored) {}
        }
        return def;
    }

    private static double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) {
            try { return Double.parseDouble(s.trim()); } catch (Exception ignored) {}
        }
        return def;
    }

    private void saveStateQuietly() {
        try {
            if (!stateFile.exists()) {
                stateFile.getParentFile().mkdirs();
                stateFile.createNewFile();
            }
            state.save(stateFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save bank-interest.yml: " + e.getMessage());
        }
    }
}

