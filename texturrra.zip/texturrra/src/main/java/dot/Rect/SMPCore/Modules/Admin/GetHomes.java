package dot.Rect.SMPCore.Modules.Admin;

import dot.Rect.SMPCore.Modules.Homes;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.UUID;

public final class GetHomes implements CommandExecutor {
    private final JavaPlugin plugin;
    private final Homes homes;
    private final PlayerIndex index;

    public GetHomes(JavaPlugin plugin, Homes homes, PlayerIndex index) {
        this.plugin = plugin;
        this.homes = homes;
        this.index = index;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("smpcore.admin.gethomes")) {
            Text.msg(sender, "&cНет прав.");
            return true;
        }
        if (args.length != 1) {
            Text.msg(sender, "&cИспользование: /gethomes <player>");
            return true;
        }

        UUID uuid = index.resolveUuidByName(args[0]);
        if (uuid == null) {
            Text.msg(sender, "&cНе удалось найти игрока: &f" + args[0]);
            return true;
        }

        var names = new ArrayList<>(homes.listHomes(uuid));
        names.sort(String::compareToIgnoreCase);

        Text.msg(sender, "&bHomes &f" + args[0] + " &7(" + names.size() + ")");
        if (names.isEmpty()) {
            Text.msg(sender, "&7(пусто)");
            return true;
        }
        for (var n : names) {
            var loc = homes.getHome(uuid, n);
            if (loc == null) {
                Text.msg(sender, "&7- &f" + n + " &c(bad world)");
                continue;
            }
            Text.msg(sender,
                    "&7- &f" + n + " &8=> &7" +
                            loc.getWorld().getName() + " " +
                            Math.floor(loc.getX()) + " " + Math.floor(loc.getY()) + " " + Math.floor(loc.getZ())
            );
        }
        return true;
    }
}

