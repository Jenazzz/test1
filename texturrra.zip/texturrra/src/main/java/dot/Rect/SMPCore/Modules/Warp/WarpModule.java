package dot.Rect.SMPCore.Modules.Warp;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.TeleportService;
import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class WarpModule implements Listener, CommandExecutor {
    private static final String LIST_TITLE = "Варпы";
    private final JavaPlugin plugin;
    private final SessionConfirmation confirmation;
    private final TeleportService tp;
    private final File file;
    private final YamlConfiguration store;

    public WarpModule(JavaPlugin plugin, SessionConfirmation confirmation, TeleportService tp) {
        this.plugin = plugin;
        this.confirmation = confirmation;
        this.tp = tp;
        this.file = new File(plugin.getDataFolder(), "warps.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
    }

    public void load() {
        saveQuietly();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }

        if (args.length == 0 || (args.length == 1 && args[0].equalsIgnoreCase("list"))) {
            openList(p);
            return true;
        }
        if (args.length == 1) {
            String name = normalize(args[0]);
            var loc = getWarp(name);
            if (loc == null) {
                Text.msg(p, "&cВарп не найден: &f" + args[0]);
                return true;
            }
            tp.teleportWithCountdown(p, loc, "SOSIDRILLA SMP", "");
            return true;
        }

        Text.msg(p, "&cИспользование: &f/warp <name> &7или &f/warp list");
        return true;
    }

    public boolean setWarp(Player p, String rawName) {
        String name = normalize(rawName);
        if (name == null) return false;
        Location loc = p.getLocation();
        String base = "warps." + name;
        store.set(base + ".world", loc.getWorld().getName());
        store.set(base + ".x", loc.getX());
        store.set(base + ".y", loc.getY());
        store.set(base + ".z", loc.getZ());
        store.set(base + ".yaw", loc.getYaw());
        store.set(base + ".pitch", loc.getPitch());
        // icon can be customized later
        if (!store.contains(base + ".icon")) store.set(base + ".icon", Material.ENDER_PEARL.name());
        saveQuietly();
        return true;
    }

    public boolean delWarp(String rawName) {
        String name = normalize(rawName);
        if (name == null) return false;
        String base = "warps." + name;
        if (!store.contains(base + ".world")) return false;
        store.set(base, null);
        saveQuietly();
        return true;
    }

    private void openList(Player p) {
        List<String> names = listWarps();
        int size = 54;
        Inventory inv = Bukkit.createInventory(p, size, LIST_TITLE);

        int slot = 0;
        for (String name : names) {
            if (slot >= size) break;
            var iconName = store.getString("warps." + name + ".icon", Material.ENDER_PEARL.name());
            Material mat = Material.matchMaterial(iconName);
            if (mat == null) mat = Material.ENDER_PEARL;

            ItemStack it = new ItemStack(mat);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(Text.c("&b✦ &f" + name));
            meta.setLore(List.of(
                    Text.c("&7Клик — телепорт"),
                    Text.c("&8/warp " + name)
            ));
            it.setItemMeta(meta);
            inv.setItem(slot++, it);
        }

        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!LIST_TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        e.setCancelled(true);
        var item = e.getCurrentItem();
        if (item == null || item.getType().isAir()) return;
        var meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;

        String display = org.bukkit.ChatColor.stripColor(meta.getDisplayName());
        if (display == null) return;
        // display is like "✦ name"
        String name = display.replace("✦", "").trim();
        if (name.isEmpty()) return;

        var loc = getWarp(normalize(name));
        if (loc == null) {
            Text.msg(p, "&cВарп не найден.");
            p.closeInventory();
            return;
        }
        p.closeInventory();
        tp.teleportWithCountdown(p, loc, "SOSIDRILLA SMP", "");
    }

    private Location getWarp(String name) {
        if (name == null) return null;
        String base = "warps." + name;
        String world = store.getString(base + ".world");
        if (world == null) return null;
        var w = Bukkit.getWorld(world);
        if (w == null) return null;
        double x = store.getDouble(base + ".x");
        double y = store.getDouble(base + ".y");
        double z = store.getDouble(base + ".z");
        float yaw = (float) store.getDouble(base + ".yaw");
        float pitch = (float) store.getDouble(base + ".pitch");
        return new Location(w, x, y, z, yaw, pitch);
    }

    private List<String> listWarps() {
        var sec = store.getConfigurationSection("warps");
        if (sec == null) return List.of();
        var out = new ArrayList<>(sec.getKeys(false));
        out.sort(String::compareToIgnoreCase);
        return out;
    }

    private static String normalize(String raw) {
        if (raw == null) return null;
        String s = raw.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return null;
        if (!s.matches("[a-z0-9_\\-]{1,16}")) return null;
        return s;
    }

    private void saveQuietly() {
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            store.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Failed to save warps.yml: " + ex.getMessage());
        }
    }
}

