package dot.Rect.SMPCore.Modules.Admin;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Убирает стандартные серверные сообщения в чат: вход, выход, смерть, объявление достижений.
 * Всплывающий тост ачивки у игрока клиент всё ещё может показывать — только широкая рассылка в чат глушится.
 */
public final class VanillaBroadcastSuppressModule implements Listener {
    private final JavaPlugin plugin;
    private final boolean join;
    private final boolean quit;
    private final boolean death;
    private final boolean advancements;

    public VanillaBroadcastSuppressModule(JavaPlugin plugin) {
        this.plugin = plugin;
        var c = plugin.getConfig();
        this.join = c.getBoolean("vanilla-broadcast.join", true);
        this.quit = c.getBoolean("vanilla-broadcast.quit", true);
        this.death = c.getBoolean("vanilla-broadcast.death", true);
        this.advancements = c.getBoolean("vanilla-broadcast.advancements", true);
    }

    public void load() {
        if (!plugin.getConfig().getBoolean("vanilla-broadcast.enabled", true)) return;
        if (!join && !quit && !death && !advancements) return;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent e) {
        if (join) {
            e.joinMessage(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onQuit(PlayerQuitEvent e) {
        if (quit) {
            e.quitMessage(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        if (death) {
            e.deathMessage(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAdvancement(PlayerAdvancementDoneEvent e) {
        if (advancements) {
            e.message(null);
        }
    }
}
