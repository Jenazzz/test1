package dot.Rect.SMPCore.Modules.Value;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

/**
 * Adds price/category lore to items in inventories (client-side display).
 * We only touch sellable items and only manage our own lore line.
 */
public final class ValueLoreModule implements Listener {
    private final JavaPlugin plugin;
    private final ValueItems values;
    private final NamespacedKey keyLore;

    public ValueLoreModule(JavaPlugin plugin, ValueItems values) {
        this.plugin = plugin;
        this.values = values;
        this.keyLore = new NamespacedKey(plugin, "value_lore");
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> refreshPlayer(e.getPlayer()), 20L);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        // Apply lore to the picked item BEFORE it enters inventory, so it stacks instantly.
        try {
            var ent = e.getItem();
            var st = ent.getItemStack();
            applyLoreToStack(st);
            ent.setItemStack(st);
        } catch (Throwable ignored) {
        }
        // then refresh to fix any edge cases
        Bukkit.getScheduler().runTask(plugin, () -> refreshPlayer(p));
    }

    @EventHandler
    public void onBlockDrop(BlockDropItemEvent e) {
        // items dropped from blocks (may go straight into hopper/chest)
        for (var it : e.getItems()) {
            try {
                var st = it.getItemStack();
                applyLoreToStack(st);
                it.setItemStack(st);
            } catch (Throwable ignored) {}
        }
    }

    @EventHandler
    public void onItemSpawn(ItemSpawnEvent e) {
        // safety net for any item entering the world
        try {
            var st = e.getEntity().getItemStack();
            applyLoreToStack(st);
            e.getEntity().setItemStack(st);
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onHopperPickup(InventoryPickupItemEvent e) {
        // apply lore before hopper takes it (so stacks stay consistent in containers)
        try {
            var st = e.getItem().getItemStack();
            applyLoreToStack(st);
            e.getItem().setItemStack(st);
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onMove(InventoryMoveItemEvent e) {
        // apply lore to moved stack so destination stacks properly
        try {
            var st = e.getItem();
            applyLoreToStack(st);
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onInvOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            refreshInventory(p, e.getInventory());
            refreshPlayer(p);
        });
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            refreshInventory(p, e.getView().getTopInventory());
            refreshPlayer(p);
        });
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            refreshInventory(p, e.getView().getTopInventory());
            refreshPlayer(p);
        });
    }

    private void refreshPlayer(Player p) {
        if (p == null || !p.isOnline()) return;
        refreshInventory(p, p.getInventory());
    }

    private void refreshInventory(Player p, Inventory inv) {
        if (p == null || inv == null) return;
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType().isAir()) continue;
            applyLoreToStack(item);
        }
    }

    private void applyLoreToStack(ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        Material mat = item.getType();
        long price = values.getPrice(mat);
        if (price <= 0) {
            stripOurLore(item);
            return;
        }

        Category cat = Category.of(mat);
        // IMPORTANT: must be identical regardless of stack amount and player,
        // otherwise items won't stack in chests/hoppers.
        long perOne = Math.max(0, price);

        var meta = item.getItemMeta();
        if (meta == null) return;
        meta.getPersistentDataContainer().set(keyLore, PersistentDataType.INTEGER, 1);

        List<String> lore = meta.getLore();
        if (lore == null) lore = new ArrayList<>();
        else lore = new ArrayList<>(lore);

        String line = Text.c("&6$: &f" + perOne + " &8| &7" + catDisplay(cat));

        lore.removeIf(s -> s != null && Text.c(s).contains("$:"));
        lore.add(line);
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    private void stripOurLore(ItemStack item) {
        var meta = item.getItemMeta();
        if (meta == null) return;
        Integer mark = meta.getPersistentDataContainer().get(keyLore, PersistentDataType.INTEGER);
        if (mark == null) return;
        List<String> lore = meta.getLore();
        if (lore == null) return;
        lore = new ArrayList<>(lore);
        lore.removeIf(s -> s != null && Text.c(s).contains("$:"));
        meta.setLore(lore);
        meta.getPersistentDataContainer().remove(keyLore);
        item.setItemMeta(meta);
    }

    private static String catDisplay(Category c) {
        return switch (c) {
            case ORES -> "Руда";
            case GEAR -> "Броня/Оружие";
            case BLOCKS -> "Блоки";
            case FOOD -> "Еда/Растения";
        };
    }

    private enum Category {
        ORES("ores"),
        GEAR("gear"),
        BLOCKS("blocks"),
        FOOD("food");

        private final String key;
        Category(String key) { this.key = key; }

        static Category of(Material m) {
            String k = m.name().toLowerCase(Locale.ROOT);

            if (k.contains("seed") || k.contains("sapling") || k.contains("wheat") || k.contains("carrot") || k.contains("potato") ||
                    k.contains("beetroot") || k.contains("melon") || k.contains("pumpkin") || k.contains("sugar_cane") ||
                    k.contains("cocoa") || k.contains("bamboo") || k.contains("kelp") || k.contains("mushroom") || m.isEdible()) {
                return FOOD;
            }

            if (k.endsWith("_sword") || k.endsWith("_axe") || k.endsWith("_pickaxe") || k.endsWith("_shovel") || k.endsWith("_hoe") ||
                    k.endsWith("_helmet") || k.endsWith("_chestplate") || k.endsWith("_leggings") || k.endsWith("_boots") ||
                    k.contains("bow") || k.contains("crossbow") || k.contains("trident") || k.contains("mace") || k.contains("shield")) {
                return GEAR;
            }

            if (k.endsWith("_ore") || k.startsWith("deepslate_") && k.endsWith("_ore") ||
                    k.startsWith("raw_") || k.endsWith("_ingot") || k.contains("diamond") || k.contains("emerald") ||
                    k.contains("netherite") || k.contains("redstone") || k.contains("lapis") || k.contains("coal") || k.contains("copper")) {
                return ORES;
            }

            return BLOCKS;
        }
    }
}

