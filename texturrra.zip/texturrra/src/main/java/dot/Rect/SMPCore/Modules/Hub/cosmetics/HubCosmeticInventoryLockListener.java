package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * Один косметический сундук в фиксированном слоте хотбара: нельзя перекладывать и выбрасывать.
 * Косметика из хаба не выбрасывается; второй такой же предмет с земли не поднимается.
 */
public final class HubCosmeticInventoryLockListener implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public HubCosmeticInventoryLockListener(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent e) {
        if (!s.enabled() || !(e.getWhoClicked() instanceof Player p) || !s.isHub(p)) return;
        if (s.guiTitleRaw().equals(e.getView().getTitle())) return;

        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();
        Inventory clicked = e.getClickedInventory();
        int chestSlot = s.hotbarSlot();

        if (clicked == p.getInventory()) {
            if (chestClickBlocked(e.getSlot(), clicked, cursor, current, chestSlot)) {
                e.setCancelled(true);
                scheduleNormalizeChest(p);
                return;
            }
        }

        if (e.getClick() == ClickType.NUMBER_KEY) {
            int hb = e.getHotbarButton();
            ItemStack atChestSlot = p.getInventory().getItem(chestSlot);
            if (hb == chestSlot && items.isChestToken(atChestSlot)) {
                e.setCancelled(true);
                scheduleNormalizeChest(p);
                return;
            }
        }

        if (items.isChestToken(cursor) || items.isChestToken(current)) {
            if (e.getClick() == ClickType.SHIFT_LEFT || e.getClick() == ClickType.SHIFT_RIGHT) {
                if (items.isChestToken(current)) {
                    e.setCancelled(true);
                    scheduleNormalizeChest(p);
                    return;
                }
            }
            if (e.getAction() == InventoryAction.DROP_ALL_SLOT || e.getAction() == InventoryAction.DROP_ONE_SLOT) {
                e.setCancelled(true);
                scheduleNormalizeChest(p);
            }
        }

        scheduleNormalizeChest(p);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        if (!s.enabled() || !s.isHub(p)) return;
        if (!s.guiTitleRaw().equals(e.getView().getTitle())) return;
        scheduleNormalizeChest(p);
    }

    private boolean chestClickBlocked(int slot, Inventory clicked, ItemStack cursor, ItemStack current, int chestSlot) {
        if (!(clicked instanceof PlayerInventory)) return false;
        if (items.isChestToken(cursor) && slot != chestSlot) {
            return true;
        }
        if (slot == chestSlot && items.isChestToken(current)) {
            return true;
        }
        if (slot != chestSlot && items.isChestToken(current)) {
            return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!s.enabled() || !(e.getWhoClicked() instanceof Player p) || !s.isHub(p)) return;
        if (s.guiTitleRaw().equals(e.getView().getTitle())) {
            return;
        }

        ItemStack old = e.getOldCursor();
        if (items.isChestToken(old)) {
            e.setCancelled(true);
            scheduleNormalizeChest(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (!s.enabled() || !s.isHub(e.getPlayer())) return;
        ItemStack stack = e.getItemDrop().getItemStack();
        if (items.isChestToken(stack) || items.isAnyCosmetic(stack)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        if (!s.enabled() || !s.isHub(e.getPlayer())) return;
        Player p = e.getPlayer();
        int held = p.getInventory().getHeldItemSlot();
        int chestSlot = s.hotbarSlot();
        if (held == chestSlot && items.isChestToken(p.getInventory().getItem(held))) {
            e.setCancelled(true);
            return;
        }
        if (items.isChestToken(p.getInventory().getItemInOffHand())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!s.enabled() || !s.isHub(p)) return;
        ItemStack stack = e.getItem().getItemStack();
        if (items.isChestToken(stack)) {
            if (playerHasAnyChestToken(p)) {
                e.setCancelled(true);
            }
            return;
        }
        String cid = items.getCosmeticId(stack);
        if (cid != null && items.playerHasCosmetic(p, cid)) {
            e.setCancelled(true);
        }
    }

    private boolean playerHasAnyChestToken(Player p) {
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            if (items.isChestToken(p.getInventory().getItem(i))) return true;
        }
        return false;
    }

    private void scheduleNormalizeChest(Player p) {
        Bukkit.getScheduler().runTask(s.plugin(), () -> normalizeChestTokens(p));
    }

    /** Оставляет не больше одного сундука — в настроенном слоте хотбара. */
    void normalizeChestTokens(Player p) {
        if (!p.isOnline() || !s.isHub(p) || !s.enabled()) return;
        int h = s.hotbarSlot();
        boolean had = false;
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (items.isChestToken(st)) {
                had = true;
                p.getInventory().setItem(i, null);
            }
        }
        if (had) {
            p.getInventory().setItem(h, items.chestToken());
        }
    }
}
