package dot.Rect.SMPCore.API;

/**
 * Placeholder for web API layer (admin panel / stats / auth).
 */
public final class WEB {
    private WEB() {}
}

