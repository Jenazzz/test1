package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class HulkBootsCosmetic implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;
    private final Map<UUID, Long> hulkLastPulse = new ConcurrentHashMap<>();

    public HulkBootsCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;

        ItemStack boots = p.getInventory().getBoots();
        if (!items.isCosmetic(boots, HubCosmeticIds.HULK_BOOTS)) return;

        if (e.getFrom().distanceSquared(e.getTo()) < 0.0025) return;
        long now = System.currentTimeMillis();
        if (now - hulkLastPulse.getOrDefault(p.getUniqueId(), 0L) < 280) return;
        hulkLastPulse.put(p.getUniqueId(), now);
        Location feet = p.getLocation();
        List<Player> victims = new ArrayList<>();
        Player closest = null;
        double best = Double.MAX_VALUE;
        for (Entity ent : feet.getWorld().getNearbyEntities(feet, 3, 3, 3)) {
            if (ent.equals(p)) continue;
            if (s.isSmpcNpcEntity(ent)) continue;
            if (ent instanceof Player t) {
                if (s.isJokerInvolved(t) || s.isJokerInvolved(p)) continue;
                victims.add(t);
                double d = t.getLocation().distanceSquared(feet);
                if (d < best) {
                    best = d;
                    closest = t;
                }
            }
        }
        for (Player t : victims) {
            // ~высота подброса порядка 8 блоков (сильная вертикальная скорость)
            t.setVelocity(t.getVelocity().add(new Vector(0, 1.2, 0)));
            Location under = t.getLocation().subtract(0, 0.05, 0);
            t.getWorld().spawnParticle(Particle.CRIT, under, 6, 0.25, 0.05, 0.25, 0.08);
            t.getWorld().spawnParticle(Particle.SMOKE, under, 4, 0.25, 0.05, 0.25, 0.02);
        }
        if (!victims.isEmpty()) {
            feet.getWorld().playSound(feet, Sound.ENTITY_RAVAGER_ROAR, 0.12f, 1.5f);
        }
        if (closest != null) {
            Location under = closest.getLocation().subtract(0, 0.05, 0);
            try {
                closest.getWorld().spawnEntity(under, EntityType.EVOKER_FANGS);
            } catch (Throwable ignored) {}
        }
    }
}
