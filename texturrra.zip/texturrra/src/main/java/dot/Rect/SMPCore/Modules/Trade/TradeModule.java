package dot.Rect.SMPCore.Modules.Trade;

import dot.Rect.SMPCore.API.SessionConfirmation;
import dot.Rect.SMPCore.Util.Text;
import dot.Rect.SMPCore.Util.TeleportService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

public final class TradeModule implements Listener, org.bukkit.command.CommandExecutor {
    private static final String TITLE = "Обмен";
    private static final int SIZE = 54;
    private static final int[] SEPARATOR = {4, 13, 22, 31, 40, 49};

    private final JavaPlugin plugin;
    private final SessionConfirmation confirmation;
    private final TeleportService tp; // not used yet, but kept for future (warp-to-player trades etc.)
    private final Predicate<ItemStack> blockedFromTrade;

    private final Map<UUID, UUID> pendingRequest = new ConcurrentHashMap<>(); // target -> requester
    private final Map<UUID, TradeSession> sessions = new ConcurrentHashMap<>(); // player -> session

    public TradeModule(JavaPlugin plugin, SessionConfirmation confirmation, TeleportService tp,
                       Predicate<ItemStack> blockedFromTrade) {
        this.plugin = plugin;
        this.confirmation = confirmation;
        this.tp = tp;
        this.blockedFromTrade = blockedFromTrade != null ? blockedFromTrade : s -> false;
    }

    public void load() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!confirmation.isConfirmed(p.getUniqueId())) {
            Text.msg(p, "&cСначала подтверди сессию: &f/confirm");
            return true;
        }

        if (args.length == 0) {
            Text.msg(p, "&8&m----------------------------------------");
            Text.msg(p, "&bОбмен &8• &7Использование");
            Text.msg(p, "&f/trade <Ник> &7— Отправить запрос на обмен");
            Text.msg(p, "&f/trade accept <Ник> &7— Принять запрос на обмен от игрока");
            Text.msg(p, "&f/trade decline <Ник> &7— Отклонить запрос на обмен от игрока");
            Text.msg(p, "&7Так же можешь принять/отклонить в чате: &a[Accept] &7и &c[Decline]");
            Text.msg(p, "&8&m----------------------------------------");
            return true;
        }

        if (args.length == 1) {
            var target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                Text.msg(p, "&cИгрок не найден онлайн: &f" + args[0]);
                return true;
            }
            if (target.getUniqueId().equals(p.getUniqueId())) {
                Text.msg(p, "&cНельзя обмениваться с самим собой.");
                return true;
            }
            sendRequest(p, target);
            return true;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("accept")) {
            var target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                Text.msg(p, "&cИгрок не найден онлайн: &f" + args[1]);
                return true;
            }
            accept(p, target);
            return true;
        }

        if (args.length == 2 && (args[0].equalsIgnoreCase("decline") || args[0].equalsIgnoreCase("deny"))) {
            var target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                Text.msg(p, "&cИгрок не найден онлайн: &f" + args[1]);
                return true;
            }
            decline(p, target);
            return true;
        }

        Text.msg(p, "&cИспользование: &f/trade <player> &7или &f/trade accept <player> &7или &f/trade decline <player>");
        return true;
    }

    private void sendRequest(Player from, Player to) {
        pendingRequest.put(to.getUniqueId(), from.getUniqueId());

        Text.msg(from, "&aЗапрос на обмен отправлен: &f" + to.getName());

        var msg = Component.text("К вам пришёл запрос на обмен", NamedTextColor.AQUA)
                .append(Component.text("\nИгрок: ", NamedTextColor.GRAY))
                .append(Component.text(from.getName(), NamedTextColor.WHITE))
                .append(Component.text("\n", NamedTextColor.GRAY))
                .append(btn(" [Принять] ", "/trade accept " + from.getName(), NamedTextColor.GREEN))
                .append(Component.text(" ", NamedTextColor.GRAY))
                .append(btn(" [Отклонить] ", "/trade decline " + from.getName(), NamedTextColor.RED));
        to.sendMessage(msg);
    }

    private void accept(Player target, Player from) {
        UUID last = pendingRequest.get(target.getUniqueId());
        if (last == null || !last.equals(from.getUniqueId())) {
            Text.msg(target, "&cНет запроса на обмен от этого игрока.");
            return;
        }
        pendingRequest.remove(target.getUniqueId());

        startSession(from, target);
    }

    private void decline(Player target, Player from) {
        UUID last = pendingRequest.get(target.getUniqueId());
        if (last == null || !last.equals(from.getUniqueId())) {
            Text.msg(target, "&cНет запроса на обмен от этого игрока.");
            return;
        }
        pendingRequest.remove(target.getUniqueId());
        Text.msg(target, "&7Запрос отклонён.");
        Text.msg(from, "&c" + target.getName() + " &7отклонил обмен.");
    }

    private void startSession(Player a, Player b) {
        // close old if any
        closeSession(a);
        closeSession(b);

        TradeSession s = new TradeSession(a, b);
        sessions.put(a.getUniqueId(), s);
        sessions.put(b.getUniqueId(), s);
        s.open();
    }

    private void closeSession(Player p) {
        TradeSession s = sessions.remove(p.getUniqueId());
        if (s == null) return;
        sessions.remove(s.a.getUniqueId());
        sessions.remove(s.b.getUniqueId());
        s.cancelAndReturn();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        TradeSession s = sessions.get(p.getUniqueId());
        if (s == null) return;

        int raw = e.getRawSlot();
        // player inventory interactions
        if (raw >= SIZE) {
            if (e.isShiftClick()) {
                // Prevent Bukkit from moving into "other view" area
                e.setCancelled(true);
                ItemStack cur = e.getCurrentItem();
                if (cur == null || cur.getType().isAir()) return;
                if (blockedFromTrade.test(cur)) {
                    Text.msg(p, "&cКосметику нельзя выставить на обмен.");
                    return;
                }
                if (!s.putIntoMyArea(p, cur.clone())) return;
                cur.setAmount(0);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    s.resetReady();
                    s.syncMirror();
                });
            }
            return;
        }

        // block separator and control slots
        if (s.isSeparator(raw) || s.isControl(raw)) {
            e.setCancelled(true);
            if (raw == s.readySlot(p)) {
                s.toggleReady(p);
            }
            return;
        }

        // restrict: you can only edit your side (left area). Right area is view-only.
        if (!s.canEdit(p, raw, e.getView().getTopInventory())) {
            e.setCancelled(true);
            return;
        }

        ItemStack cursor = e.getCursor();
        if (cursor != null && !cursor.getType().isAir() && blockedFromTrade.test(cursor)) {
            e.setCancelled(true);
            Text.msg(p, "&cКосметику нельзя выставить на обмен.");
            return;
        }

        // if player changed items -> reset readiness
        Bukkit.getScheduler().runTask(plugin, () -> {
            s.resetReady();
            s.syncMirror();
        });
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        TradeSession s = sessions.get(p.getUniqueId());
        if (s == null) return;
        if (blockedFromTrade.test(e.getOldCursor())) {
            e.setCancelled(true);
            Text.msg(p, "&cКосметику нельзя выставить на обмен.");
            return;
        }
        for (int slot : e.getRawSlots()) {
            if (slot < SIZE && !s.canEdit(p, slot, e.getView().getTopInventory())) {
                e.setCancelled(true);
                return;
            }
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            s.resetReady();
            s.syncMirror();
        });
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        TradeSession s = sessions.get(p.getUniqueId());
        if (s == null) return;
        // if either closes, cancel trade and return items
        Bukkit.getScheduler().runTask(plugin, () -> closeSession(p));
    }

    private static Component btn(String text, String command, NamedTextColor color) {
        return Component.text(text, color).clickEvent(ClickEvent.runCommand(command));
    }

    private final class TradeSession {
        private final Player a;
        private final Player b;
        private final Inventory invA;
        private final Inventory invB;
        private boolean readyA = false;
        private boolean readyB = false;
        private int countdownTask = -1;

        private TradeSession(Player a, Player b) {
            this.a = a;
            this.b = b;
            this.invA = Bukkit.createInventory(a, SIZE, TITLE);
            this.invB = Bukkit.createInventory(b, SIZE, TITLE);
            setup(invA, a, b);
            setup(invB, b, a);
            syncMirror();
        }

        private void setup(Inventory inv, Player self, Player other) {
            for (int s : SEPARATOR) {
                inv.setItem(s, pane(Material.RED_STAINED_GLASS_PANE, "&c"));
            }
            inv.setItem(45, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(46, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(47, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(48, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(49, pane(Material.RED_STAINED_GLASS_PANE, "&c"));
            inv.setItem(50, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(51, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(52, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));
            inv.setItem(53, pane(Material.BLACK_STAINED_GLASS_PANE, "&8"));

            inv.setItem(46, info("&bОбмен", List.of(
                    "&7Ты: &f" + self.getName(),
                    "&7Он: &f" + other.getName(),
                    "",
                    "&7Положи предметы слева.",
                    "&7Нажми &aГотов&7 когда закончил."
            )));

            inv.setItem(48, readyItem(false));
            inv.setItem(50, otherReadyItem(false, other.getName()));
        }

        private boolean isSeparator(int slot) {
            for (int s : SEPARATOR) if (s == slot) return true;
            return false;
        }

        private boolean isControl(int slot) {
            return slot >= 45; // bottom row controls
        }

        private int readySlot(Player p) {
            return 48;
        }

        private boolean canEdit(Player p, int rawSlot, Inventory top) {
            // editable only in YOUR left area (cols 0-3), and not separator, and not control row
            if (rawSlot >= 45) return false;
            if (isSeparator(rawSlot)) return false;
            if (!isMyTop(p, top)) return false;
            return isMyArea(rawSlot);
        }

        private boolean isMyTop(Player p, Inventory top) {
            if (p.getUniqueId().equals(a.getUniqueId())) return top == invA;
            if (p.getUniqueId().equals(b.getUniqueId())) return top == invB;
            return false;
        }

        private boolean isMyArea(int slot) {
            // cols 0-3, rows 0-4 (0..44)
            int col = slot % 9;
            return col <= 3;
        }

        private boolean isOtherViewArea(int slot) {
            int col = slot % 9;
            return col >= 5 && slot < 45;
        }

        private void open() {
            a.openInventory(invA);
            b.openInventory(invB);
            Text.msg(a, "&bОткрыт обмен с &f" + b.getName());
            Text.msg(b, "&bОткрыт обмен с &f" + a.getName());
        }

        private void toggleReady(Player p) {
            if (p.getUniqueId().equals(a.getUniqueId())) {
                readyA = !readyA;
            } else if (p.getUniqueId().equals(b.getUniqueId())) {
                readyB = !readyB;
            }
            syncReady();
            if (readyA && readyB) startCountdown();
            else stopCountdown();
        }

        private void resetReady() {
            if (readyA || readyB) {
                readyA = false;
                readyB = false;
                syncReady();
                stopCountdown();
            }
        }

        private void syncMirror() {
            // mirror A's items into B's right view, and B's items into A's right view
            mirror(invA, invB);
            mirror(invB, invA);
        }

        private void mirror(Inventory from, Inventory to) {
            // clear target other-view area first
            for (int slot = 0; slot < 45; slot++) {
                if (isSeparator(slot)) continue;
                if (isOtherViewArea(slot)) {
                    to.setItem(slot, null);
                }
            }
            // copy my-area items (cols 0-3) into other-view area (cols 5-8)
            for (int slot = 0; slot < 45; slot++) {
                if (isSeparator(slot)) continue;
                if (!isMyArea(slot)) continue;
                ItemStack it = from.getItem(slot);
                if (it == null || it.getType().isAir()) continue;
                int row = slot / 9;
                int col = slot % 9;
                int targetCol = col + 5;
                int targetSlot = row * 9 + targetCol;
                if (targetSlot >= 0 && targetSlot < 45) {
                    to.setItem(targetSlot, it.clone());
                }
            }
        }

        private boolean putIntoMyArea(Player p, ItemStack stack) {
            Inventory top = p.getOpenInventory().getTopInventory();
            Inventory inv = p.getUniqueId().equals(a.getUniqueId()) ? invA : invB;
            if (top != inv) return false;
            // find first empty in my area
            for (int slot = 0; slot < 45; slot++) {
                if (isSeparator(slot)) continue;
                if (!isMyArea(slot)) continue;
                ItemStack cur = inv.getItem(slot);
                if (cur == null || cur.getType().isAir()) {
                    inv.setItem(slot, stack);
                    return true;
                }
            }
            return false;
        }

        private void syncReady() {
            invA.setItem(48, readyItem(readyA));
            invB.setItem(48, readyItem(readyB));

            invA.setItem(50, otherReadyItem(readyB, b.getName()));
            invB.setItem(50, otherReadyItem(readyA, a.getName()));
        }

        private void startCountdown() {
            stopCountdown();
            final int[] s = {3};
            countdownTask = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
                if (!a.isOnline() || !b.isOnline()) {
                    cancelAndReturn();
                    return;
                }
                if (!readyA || !readyB) {
                    stopCountdown();
                    return;
                }
                int left = s[0];
                if (left <= 0) {
                    stopCountdown();
                    complete();
                    return;
                }
                a.sendActionBar(Component.text("Обмен через " + left + "…", NamedTextColor.YELLOW));
                b.sendActionBar(Component.text("Обмен через " + left + "…", NamedTextColor.YELLOW));
                s[0] = left - 1;
            }, 0L, 20L);
        }

        private void stopCountdown() {
            if (countdownTask != -1) {
                Bukkit.getScheduler().cancelTask(countdownTask);
                countdownTask = -1;
            }
        }

        private void complete() {
            // take left-side items from each inventory and swap
            var itemsA = collectMyItems(invA);
            var itemsB = collectMyItems(invB);
            clearMyItems(invA);
            clearMyItems(invB);

            giveOrDrop(a, itemsB);
            giveOrDrop(b, itemsA);

            Text.msg(a, "&aОбмен завершён.");
            Text.msg(b, "&aОбмен завершён.");

            // close both and cleanup
            a.closeInventory();
            b.closeInventory();
            sessions.remove(a.getUniqueId());
            sessions.remove(b.getUniqueId());
        }

        private void cancelAndReturn() {
            stopCountdown();
            // return items to owners (their own left side)
            var itemsA = collectMyItems(invA);
            var itemsB = collectMyItems(invB);
            clearMyItems(invA);
            clearMyItems(invB);
            giveOrDrop(a, itemsA);
            giveOrDrop(b, itemsB);
            try { a.closeInventory(); } catch (Throwable ignored) {}
            try { b.closeInventory(); } catch (Throwable ignored) {}
            Text.msg(a, "&cОбмен отменён.");
            Text.msg(b, "&cОбмен отменён.");
        }

        private List<ItemStack> collectMyItems(Inventory inv) {
            List<ItemStack> out = new ArrayList<>();
            for (int slot = 0; slot < 45; slot++) {
                if (isSeparator(slot)) continue;
                if (!isMyArea(slot)) continue;
                ItemStack it = inv.getItem(slot);
                if (it == null || it.getType().isAir()) continue;
                out.add(it.clone());
            }
            return out;
        }

        private void clearMyItems(Inventory inv) {
            for (int slot = 0; slot < 45; slot++) {
                if (isSeparator(slot)) continue;
                if (!isMyArea(slot)) continue;
                inv.setItem(slot, null);
            }
        }

        private void giveOrDrop(Player p, List<ItemStack> items) {
            for (ItemStack it : items) {
                var left = p.getInventory().addItem(it);
                if (!left.isEmpty()) {
                    left.values().forEach(st -> p.getWorld().dropItemNaturally(p.getLocation(), st));
                }
            }
        }

        private ItemStack pane(Material mat, String name) {
            ItemStack it = new ItemStack(mat);
            var meta = it.getItemMeta();
            meta.setDisplayName(Text.c(name));
            it.setItemMeta(meta);
            return it;
        }

        private ItemStack info(String name, List<String> lore) {
            ItemStack it = new ItemStack(Material.PAPER);
            var meta = it.getItemMeta();
            meta.setDisplayName(Text.c(name));
            meta.setLore(lore.stream().map(Text::c).toList());
            it.setItemMeta(meta);
            return it;
        }

        private ItemStack readyItem(boolean ready) {
            Material mat = ready ? Material.GREEN_TERRACOTTA : Material.YELLOW_TERRACOTTA;
            ItemStack it = new ItemStack(mat);
            var meta = it.getItemMeta();
            meta.setDisplayName(Text.c(ready ? "&aГотов" : "&eНажми чтобы готов"));
            meta.setLore(List.of(Text.c("&7Если ты меняешь предметы — готовность сбросится.")));
            it.setItemMeta(meta);
            return it;
        }

        private ItemStack otherReadyItem(boolean ready, String name) {
            Material mat = ready ? Material.LIME_DYE : Material.GRAY_DYE;
            ItemStack it = new ItemStack(mat);
            var meta = it.getItemMeta();
            meta.setDisplayName(Text.c("&7" + name + ": " + (ready ? "&aГотов" : "&cНе готов")));
            it.setItemMeta(meta);
            return it;
        }
    }
}

