package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class HubCosmeticLifecycleListener implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;
    private final SlimeBootsCosmetic slime;
    private final SwinoplaneCosmetic swinoplane;

    public HubCosmeticLifecycleListener(HubCosmeticsSupport s, CosmeticItems items, SlimeBootsCosmetic slime,
                                        SwinoplaneCosmetic swinoplane) {
        this.s = s;
        this.items = items;
        this.slime = slime;
        this.swinoplane = swinoplane;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        Bukkit.getScheduler().runTaskLater(s.plugin(), () -> giveChestSlot(p), 5L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (s.isHub(p)) {
            Bukkit.getScheduler().runTaskLater(s.plugin(), () -> giveChestSlot(p), 2L);
        } else {
            clearChestSlot(p);
            s.stopJoker(p.getUniqueId());
            HubSaunaRegistry.endAllForOwner(p.getUniqueId());
            swinoplane.removeFor(p.getUniqueId());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        s.stopJoker(p.getUniqueId());
        slime.clearPlayer(p.getUniqueId());
        HubSaunaRegistry.endAllForOwner(p.getUniqueId());
        swinoplane.removeFor(p.getUniqueId());
    }

    private void giveChestSlot(Player p) {
        if (!s.isHub(p)) return;
        items.removeAllChestTokens(p);
        p.getInventory().setItem(s.hotbarSlot(), items.chestToken());
    }

    private void clearChestSlot(Player p) {
        items.removeAllChestTokens(p);
    }
}
