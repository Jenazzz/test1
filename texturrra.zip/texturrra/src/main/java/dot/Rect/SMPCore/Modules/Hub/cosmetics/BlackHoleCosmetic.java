package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class BlackHoleCosmetic implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;

    public BlackHoleCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isCosmetic(hand, HubCosmeticIds.BLACK_HOLE)) return;
        if (!e.getAction().name().contains("RIGHT_CLICK")) return;
        if (e.getAction().name().contains("BLOCK") && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        e.setCancelled(true);
        if (s.onCooldown(p, 3500)) return;
        blackHole(p);
    }

    private void blackHole(Player p) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), 15, FluidCollisionMode.NEVER, true);
        Block b = r != null ? r.getHitBlock() : null;
        if (b == null) {
            Text.msg(p, "&cНаведись на блок.");
            return;
        }
        Location center = b.getLocation().add(0.5, 0.5, 0.5);
        World w = center.getWorld();
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t++ > 50) {
                    for (Entity ent : w.getNearbyEntities(center, 6, 6, 6)) {
                        if (s.isSmpcNpcEntity(ent)) continue;
                        if (ent instanceof Player pl && s.isHub(pl)) {
                            Vector out = pl.getLocation().toVector().subtract(center.toVector()).normalize().setY(0.35).multiply(1.15);
                            pl.setVelocity(out);
                        }
                    }
                    w.spawnParticle(Particle.EXPLOSION, center, 3, 1, 1, 1, 0);
                    w.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.85f);
                    cancel();
                    return;
                }
                w.spawnParticle(Particle.PORTAL, center, 120, 3.5, 3.5, 3.5, 0.12);
                w.spawnParticle(Particle.SQUID_INK, center, 25, 2, 2, 2, 0.02);
                w.spawnParticle(Particle.SMOKE, center, 40, 2.5, 2.5, 2.5, 0.02);
                for (Entity ent : w.getNearbyEntities(center, 5, 5, 5)) {
                    if (s.isSmpcNpcEntity(ent)) continue;
                    if (ent instanceof Player pl && s.isHub(pl)) {
                        Vector in = center.toVector().subtract(pl.getLocation().toVector()).normalize().multiply(0.12);
                        pl.setVelocity(pl.getVelocity().add(in));
                    }
                }
            }
        }.runTaskTimer(s.plugin(), 0L, 1L);
    }
}
