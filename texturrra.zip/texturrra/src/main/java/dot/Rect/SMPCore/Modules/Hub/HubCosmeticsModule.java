package dot.Rect.SMPCore.Modules.Hub;

import dot.Rect.SMPCore.Modules.Hub.cosmetics.BlackHoleCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.CosmeticItems;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.CosmeticStorageGuard;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HomunculusHookCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubCosmeticChestGuiListener;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubCosmeticInventoryLockListener;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubCosmeticLifecycleListener;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HulkBootsCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubCosmeticsSupport;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.HubSaunaRegistry;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.JokerWebCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.MaleSaunaCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.SlimeBootsCosmetic;
import dot.Rect.SMPCore.Modules.Hub.cosmetics.SwinoplaneCosmetic;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Косметика только в хабе: сундук в хотбаре + предметы с эффектами.
 * Логика по предметам — в {@code Modules.Hub.cosmetics}.
 */
public final class HubCosmeticsModule {
    private final HubCosmeticsSupport support;
    private final CosmeticItems items;
    private final SlimeBootsCosmetic slime;
    private final HulkBootsCosmetic hulk;
    private final HomunculusHookCosmetic hook;
    private final BlackHoleCosmetic hole;
    private final JokerWebCosmetic joker;
    private final MaleSaunaCosmetic maleSauna;
    private final SwinoplaneCosmetic swinoplane;
    private final HubCosmeticChestGuiListener chestGui;
    private final HubCosmeticInventoryLockListener invLock;
    private final HubCosmeticLifecycleListener lifecycle;

    public HubCosmeticsModule(JavaPlugin plugin) {
        this.support = new HubCosmeticsSupport(plugin);
        this.items = new CosmeticItems(support);
        this.slime = new SlimeBootsCosmetic(support, items);
        this.hulk = new HulkBootsCosmetic(support, items);
        this.hook = new HomunculusHookCosmetic(support, items);
        this.hole = new BlackHoleCosmetic(support, items);
        this.joker = new JokerWebCosmetic(support, items);
        this.maleSauna = new MaleSaunaCosmetic(support, items);
        this.swinoplane = new SwinoplaneCosmetic(support, items);
        this.chestGui = new HubCosmeticChestGuiListener(support, items);
        this.invLock = new HubCosmeticInventoryLockListener(support, items);
        this.lifecycle = new HubCosmeticLifecycleListener(support, items, slime, swinoplane);
    }

    /** Сундук косметики и предметы с {@code hub_cosmetic_id} — нельзя в трейд / эндер-сундук. */
    public boolean blockedFromExternalStorage(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return false;
        return items.isChestToken(stack) || items.isAnyCosmetic(stack);
    }

    /** Вход в PvP-арену хаба: снять косметику, сбросить джокер/слизь. */
    public void pvpArenaEnter(Player p) {
        if (!support.enabled()) return;
        support.stopJoker(p.getUniqueId());
        slime.clearPlayer(p.getUniqueId());
        HubSaunaRegistry.endAllForOwner(p.getUniqueId());
        swinoplane.removeFor(p.getUniqueId());
        items.stripAllHubCosmetics(p);
    }

    /** Выход из арены, игрок всё ещё в хабе — вернуть сундук косметики в слот хотбара. */
    public void pvpArenaExitRestoreChest(Player p) {
        if (!support.enabled() || !support.isHub(p)) return;
        items.removeAllChestTokens(p);
        p.getInventory().setItem(support.hotbarSlot(), items.chestToken());
    }

    public void load() {
        var pm = Bukkit.getPluginManager();
        var pl = support.plugin();
        pm.registerEvents(new CosmeticStorageGuard(items), pl);
        if (!support.enabled()) return;
        pm.registerEvents(slime, pl);
        pm.registerEvents(hulk, pl);
        pm.registerEvents(hook, pl);
        pm.registerEvents(hole, pl);
        pm.registerEvents(joker, pl);
        pm.registerEvents(maleSauna, pl);
        pm.registerEvents(swinoplane, pl);
        pm.registerEvents(chestGui, pl);
        pm.registerEvents(invLock, pl);
        pm.registerEvents(lifecycle, pl);
        Bukkit.getScheduler().runTaskTimer(pl, slime::tickJumpBoost, 20L, 20L);
    }
}
