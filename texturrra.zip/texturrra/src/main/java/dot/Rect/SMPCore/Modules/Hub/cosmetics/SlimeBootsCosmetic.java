package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SlimeBootsCosmetic implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;
    private final Map<UUID, Boolean> slimeWasAir = new ConcurrentHashMap<>();

    public SlimeBootsCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    public void clearPlayer(UUID u) {
        slimeWasAir.remove(u);
    }

    public void tickJumpBoost() {
        if (!s.enabled()) return;
        for (Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
            if (!s.isHub(p)) {
                slimeWasAir.remove(p.getUniqueId());
                continue;
            }
            ItemStack boots = p.getInventory().getBoots();
            if (items.isCosmetic(boots, HubCosmeticIds.SLIME_BOOTS)) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 80, 4, false, false, false));
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;

        ItemStack boots = p.getInventory().getBoots();
        if (!items.isCosmetic(boots, HubCosmeticIds.SLIME_BOOTS)) return;

        boolean now = p.isOnGround();
        Boolean prev = slimeWasAir.put(p.getUniqueId(), now);
        if (Boolean.FALSE.equals(prev) && now) {
            var l = p.getLocation().add(0, 0.05, 0);
            p.getWorld().spawnParticle(Particle.ITEM, l, 35, 0.45, 0.05, 0.45, 0.08, new ItemStack(Material.SLIME_BLOCK));
            p.getWorld().spawnParticle(Particle.ITEM_SLIME, l, 25, 0.4, 0.1, 0.4, 0.02);
            p.playSound(l, Sound.BLOCK_SLIME_BLOCK_FALL, 0.7f, 0.85f);
            for (Entity ent : p.getNearbyEntities(2.8, 2.2, 2.8)) {
                if (s.isSmpcNpcEntity(ent)) continue;
                if (ent instanceof Player t && !t.equals(p)) {
                    if (s.isJokerInvolved(t) || s.isJokerInvolved(p)) continue;
                    Vector away = t.getLocation().toVector().subtract(p.getLocation().toVector());
                    if (away.lengthSquared() < 0.01) away = new Vector(0, 0, 0.2);
                    else away.normalize().multiply(0.18).setY(0.06);
                    t.setVelocity(t.getVelocity().add(away));
                }
            }
        }
    }
}
