package dot.Rect.SMPCore.Modules.Hub.cosmetics;

import dot.Rect.SMPCore.Util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Седло «Свинолет» — летучая мышь со взрослой свиньёй и седлом (можно сесть на свинью); повторный ПКМ убирает без дропа седла.
 */
public final class SwinoplaneCosmetic implements Listener {
    private final HubCosmeticsSupport s;
    private final CosmeticItems items;
    /** Владелец → [bat uuid, pig uuid] */
    private final Map<UUID, UUID[]> mounts = new ConcurrentHashMap<>();

    public SwinoplaneCosmetic(HubCosmeticsSupport s, CosmeticItems items) {
        this.s = s;
        this.items = items;
    }

    public void removeFor(UUID owner) {
        UUID[] ids = mounts.remove(owner);
        if (ids == null || ids.length < 2) return;
        Entity bat = Bukkit.getEntity(ids[0]);
        Entity pigEnt = Bukkit.getEntity(ids[1]);
        if (bat != null && !bat.isDead()) {
            bat.eject();
            bat.remove();
        }
        if (pigEnt instanceof Pig pig && !pigEnt.isDead()) {
            pig.setSaddle(false);
            pig.remove();
        } else if (pigEnt != null && !pigEnt.isDead()) {
            pigEnt.remove();
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!s.enabled()) return;
        Player p = e.getPlayer();
        if (!s.isHub(p)) return;
        ItemStack hand = e.getItem();
        if (hand == null || !items.isCosmetic(hand, HubCosmeticIds.SWINOPLANE)) return;
        if (!e.getAction().name().contains("RIGHT_CLICK")) return;
        if (e.getAction().name().contains("BLOCK") && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        e.setCancelled(true);
        if (mounts.containsKey(p.getUniqueId())) {
            removeFor(p.getUniqueId());
            Text.msg(p, "&7Свинолет благополучно снят с рейса.");
            return;
        }
        if (s.onCooldown(p, 400)) return;
        spawnMount(p);
    }

    private void spawnMount(Player p) {
        org.bukkit.World w = p.getWorld();
        Location base = p.getLocation();
        Location loc = base.clone().add(base.getDirection().setY(0).normalize().multiply(1.8));
        loc.setY(Math.floor(base.getY()) + 0.05);
        Block at = w.getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        if (!at.isPassable()) {
            loc.add(0, 1, 0);
        }

        Bat bat = w.spawn(loc, Bat.class, CreatureSpawnEvent.SpawnReason.CUSTOM);
        bat.setPersistent(false);
        bat.setRemoveWhenFarAway(false);
        bat.setInvulnerable(true);
        s.tagHubCosmeticMount(bat, p.getUniqueId());

        Pig pig = w.spawn(loc.clone().add(0, 0.12, 0), Pig.class, CreatureSpawnEvent.SpawnReason.CUSTOM);
        pig.setAdult();
        pig.setAgeLock(true);
        pig.setPersistent(false);
        pig.setRemoveWhenFarAway(false);
        pig.setInvulnerable(true);
        pig.setSaddle(true);
        s.tagHubCosmeticMount(pig, p.getUniqueId());

        bat.addPassenger(pig);
        mounts.put(p.getUniqueId(), new UUID[]{bat.getUniqueId(), pig.getUniqueId()});
        Text.msg(p, "&dСвинолет взлетел! &7ПКМ снова — посадка.");
    }
}
