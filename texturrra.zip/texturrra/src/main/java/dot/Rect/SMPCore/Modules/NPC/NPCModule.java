package dot.Rect.SMPCore.Modules.NPC;

import dot.Rect.SMPCore.Util.Text;
import dot.Rect.SMPCore.Util.TeleportService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.UUID;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Minimal NPC module.
 * - /npc create <name> : spawns a Villager NPC and marks it as SMPCore NPC
 * - On right click: opens GUI with world teleports (config-driven)
 */
public final class NPCModule implements Listener, CommandExecutor {
    private final JavaPlugin plugin;
    private final TeleportService tp;
    private final File file;
    private final YamlConfiguration store;

    private final String npcKey;
    private final String uiTitle;
    private final String uiKey;
    private final String npcTypeKey;
    private final String npcSkinKey;
    private final String npcNameKey;
    private final String npcTagKey;

    /** Mannequin UUIDs for velocity freeze (no pushing / fishing). */
    private final Set<UUID> trackedMannequins = ConcurrentHashMap.newKeySet();

    public NPCModule(JavaPlugin plugin, TeleportService tp) {
        this.plugin = plugin;
        this.tp = tp;
        this.file = new File(plugin.getDataFolder(), "npcs.yml");
        this.store = YamlConfiguration.loadConfiguration(file);
        this.npcKey = "smpcore_npc";
        this.uiKey = "smpcore_ui_key";
        this.uiTitle = "Телепорты";
        this.npcTypeKey = "smpcore_npc_type";
        this.npcSkinKey = "smpcore_npc_skin";
        this.npcNameKey = "smpcore_npc_name";
        this.npcTagKey = "smpcore_npc_tag";
    }

    public void load() {
        saveQuietly();
        reloadTrackedMannequinsFromStore();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (UUID id : trackedMannequins) {
                Entity e = Bukkit.getEntity(id);
                if (e == null || !e.isValid()) {
                    trackedMannequins.remove(id);
                    continue;
                }
                if (!isOurNpc(e)) {
                    trackedMannequins.remove(id);
                    continue;
                }
                try { e.setGravity(false); } catch (Throwable ignored) {}
                e.setVelocity(new Vector(0, 0, 0));
            }
        }, 1L, 1L);
    }

    private void reloadTrackedMannequinsFromStore() {
        trackedMannequins.clear();
        try {
            var sec = store.getConfigurationSection("npcs");
            if (sec == null) return;
            for (String k : sec.getKeys(false)) {
                try {
                    trackedMannequins.add(UUID.fromString(k));
                } catch (IllegalArgumentException ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Text.msg(sender, "&cТолько для игроков.");
            return true;
        }
        if (!p.hasPermission("smpcore.npc.admin")) {
            Text.msg(p, "&cНет прав.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("remove")) {
            Entity ent = findNpcTarget(p, 6.0);
            if (ent == null || !isOurNpc(ent)) {
                Text.msg(p, "&cТаргет не найден. Посмотри на NPC и напиши &f/npc remove");
                return true;
            }
            // remove hologram name tag if present
            try {
                String tid = ent.getPersistentDataContainer().get(new org.bukkit.NamespacedKey(plugin, npcTagKey), PersistentDataType.STRING);
                if (tid != null && !tid.isBlank()) {
                    try {
                        UUID u = UUID.fromString(tid.trim());
                        Entity tag = Bukkit.getEntity(u);
                        if (tag != null) tag.remove();
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}
            store.set("npcs." + ent.getUniqueId(), null);
            saveQuietly();
            trackedMannequins.remove(ent.getUniqueId());
            ent.remove();
            Text.msg(p, "&aNPC удалён.");
            return true;
        }

        // единственный формат:
        // /npc create <type> <skinNick> <name...>
        if (args.length >= 4 && args[0].equalsIgnoreCase("create")) {
            String type = args[1].trim();
            String skin = args[2].trim();
            String name = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length)).trim();
            if (type.isEmpty() || skin.isEmpty() || name.isEmpty()) {
                Text.msg(p, "&cИспользование: &f/npc create <type> <skinNick> <name...>");
                return true;
            }
            createNpc(p, type, skin, name);
            return true;
        }

        Text.msg(p, "&cИспользование: &f/npc create <type> <skinNick> <name...> &7| &f/npc remove");
        return true;
    }

    private void createNpc(Player p, String type, String skinNick, String name) {
        if (!createPurpurMannequin(p, type, skinNick, name)) {
            Text.msg(p, "&cНа этом ядре нет сущности &fMANNEQUIN&c.");
            Text.msg(p, "&7Проверь: &f/summon minecraft:mannequin");
            return;
        }
        Text.msg(p, "&aNPC создан: &f" + name + " &7(&f" + type + "&7)");
    }

    private boolean createPurpurMannequin(Player p, String type, String skinNick, String name) {
        // Spawns Purpur's custom entity if present in this server build
        EntityType mannequinType;
        try {
            mannequinType = EntityType.valueOf("MANNEQUIN");
        } catch (IllegalArgumentException ex) {
            return false;
        }

        Entity ent = p.getWorld().spawnEntity(p.getLocation(), mannequinType);
        if (ent == null) return false;

        // Hide mannequin's own nameplate (it may show an extra default line like "NPC")
        try { ent.setCustomNameVisible(false); } catch (Throwable ignored) {}
        try { ent.setCustomName(null); } catch (Throwable ignored) {}

        try { ent.setInvulnerable(true); } catch (Throwable ignored) {}
        try { ent.setSilent(true); } catch (Throwable ignored) {}
        // Try to remove any built-in extra tags like "NPC" if the entity supports it
        tryInvoke(ent, "setShowName", boolean.class, false);
        tryInvoke(ent, "setShowNameTag", boolean.class, false);
        tryInvoke(ent, "setShowNameplate", boolean.class, false);
        tryInvoke(ent, "setShowTag", boolean.class, false);
        try {
            var m = ent.getClass().getMethod("setCollidable", boolean.class);
            m.invoke(ent, false);
        } catch (Throwable ignored) {}

        applySkin(ent, skinNick);

        UUID tagId = spawnNameTag(ent, name);
        tagNpc(ent, type, skinNick, name, tagId);
        trackedMannequins.add(ent.getUniqueId());
        store.set("npcs." + ent.getUniqueId() + ".backend", "mannequin");
        saveQuietly();
        return true;
    }

    @EventHandler
    public void onFish(PlayerFishEvent e) {
        var hook = e.getHook();
        if (hook == null) return;
        var hooked = hook.getHookedEntity();
        if (hooked != null && isOurNpc(hooked)) {
            e.setCancelled(true);
        }
    }

    private void tagNpc(Entity entity, String type, String skinNick, String name, UUID tagId) {
        var pdc = entity.getPersistentDataContainer();
        pdc.set(pluginKey(), PersistentDataType.BYTE, (byte) 1);
        pdc.set(new org.bukkit.NamespacedKey(plugin, npcTypeKey), PersistentDataType.STRING, type.toLowerCase(Locale.ROOT));
        pdc.set(new org.bukkit.NamespacedKey(plugin, npcSkinKey), PersistentDataType.STRING, skinNick);
        pdc.set(new org.bukkit.NamespacedKey(plugin, npcNameKey), PersistentDataType.STRING, name);
        if (tagId != null) {
            pdc.set(new org.bukkit.NamespacedKey(plugin, npcTagKey), PersistentDataType.STRING, tagId.toString());
        }

        store.set("npcs." + entity.getUniqueId() + ".type", type.toLowerCase(Locale.ROOT));
        store.set("npcs." + entity.getUniqueId() + ".skin", skinNick);
        store.set("npcs." + entity.getUniqueId() + ".name", name);
        if (tagId != null) store.set("npcs." + entity.getUniqueId() + ".tag", tagId.toString());
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        var player = e.getPlayer();
        var entity = e.getRightClicked();
        if (!isOurNpc(entity)) return;

        e.setCancelled(true);
        String type = "worldselector";
        try {
            var t = entity.getPersistentDataContainer().get(new org.bukkit.NamespacedKey(plugin, npcTypeKey), PersistentDataType.STRING);
            if (t != null && !t.isBlank()) type = t.toLowerCase(Locale.ROOT);
        } catch (Throwable ignored) {}

        if (type.equals("worldselector") || type.equals("world_selector")) {
            openWorldSelector(player);
        } else if (type.equals("guider") || type.equals("guide")) {
            openGuider(player);
        } else {
            openWorldSelector(player);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (isOurNpc(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getView() == null) return;
        String title = e.getView().getTitle();
        boolean isWorldSelector = title.equals(uiTitle);
        boolean isGuider = title.equals("Гайд");
        if (!isWorldSelector && !isGuider) return;

        e.setCancelled(true);

        var item = e.getCurrentItem();
        if (item == null || item.getType().isAir()) return;
        var meta = item.getItemMeta();
        if (meta == null) return;

        if (isGuider) return; // info-only GUI

        var key = meta.getPersistentDataContainer().get(pluginUiKey(), PersistentDataType.STRING);
        if (key == null || key.isEmpty()) return;

        var worldName = plugin.getConfig().getString("npc.teleports." + key + ".world", "");
        if (worldName.isEmpty()) return;
        var world = Bukkit.getWorld(worldName);
        if (world == null) {
            Text.msg(p, "&cМир не найден: &f" + worldName);
            return;
        }

        p.closeInventory();
        tp.teleportWithCountdown(p, world.getSpawnLocation(), "SOSIDRILLA SMP", "");
    }

    private void openWorldSelector(Player player) {
        int size = 27;
        var inv = Bukkit.createInventory(null, size, uiTitle);

        // Purple "void" frame
        var pane = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        var pm = pane.getItemMeta();
        pm.setDisplayName(" ");
        pane.setItemMeta(pm);
        for (int i = 0; i < size; i++) inv.setItem(i, pane);

        // Slot above (top center): title item
        inv.setItem(4, info(Material.GRASS_BLOCK, "&a&lВыбор мира", List.of(
                "&7Нажми на мир снизу",
                "&7чтобы телепортироваться."
        )));

        // Онлайн мира StreamerWorld (пока всегда 0; позже — из реального мира из конфига)
        int streamCount = 0;
        String sw = plugin.getConfig().getString("npc.streamer-world", "");
        if (sw != null && !sw.isBlank()) {
            var w = Bukkit.getWorld(sw.trim());
            if (w != null) streamCount = w.getPlayers().size();
        }
        int streamCap = plugin.getConfig().getInt("npc.streamer-cap", 200);
        inv.setItem(13, info(Material.EMERALD_BLOCK, "&b&lStreamerWorld &8[&7" + streamCount + "/" + streamCap + "&8]", List.of(
                "&7Скоро открытие — следи за новостями!"
        )));
        inv.setItem(15, info(Material.BEDROCK, "&5&lUnknown world..", List.of(
                "&7Мистика даже есть в майнкрафте..",
                "&8Closed!"
        )));

        // Only survival (skip hub)
        var section = plugin.getConfig().getConfigurationSection("npc.teleports");
        if (section != null) {
            Map<String, Integer> slots = new HashMap<>();
            slots.put("survival", 11);
            for (String key : section.getKeys(false)) {
                if (key.equalsIgnoreCase("hub")) continue;
                if (!key.equalsIgnoreCase("survival")) continue; // per request: only survival

                int slot = slots.getOrDefault(key.toLowerCase(Locale.ROOT), 11);
                var name = plugin.getConfig().getString("npc.teleports." + key + ".name", key);
                var matName = plugin.getConfig().getString("npc.teleports." + key + ".icon", "GRASS_BLOCK");
                Material mat;
                try {
                    mat = Material.valueOf(matName.toUpperCase(Locale.ROOT));
                } catch (Exception ex) {
                    mat = Material.GRASS_BLOCK;
                }

                ItemStack it = named(mat, "&b&l" + name, key);
                var meta = it.getItemMeta();
                meta.setLore(Arrays.asList(
                        Text.c("&7Нажми, чтобы перейти"),
                        Text.c("&7в мир &f" + name)
                ));
                it.setItemMeta(meta);
                inv.setItem(slot, it);
            }
        }

        player.openInventory(inv);
    }

    private void openGuider(Player player) {
        int size = 27;
        var inv = Bukkit.createInventory(null, size, "Гайд");

        var pane = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        var pm = pane.getItemMeta();
        pm.setDisplayName(" ");
        pane.setItemMeta(pm);
        for (int i = 0; i < size; i++) inv.setItem(i, pane);

        inv.setItem(4, info(Material.WRITABLE_BOOK, "&d&lПутеводитель", List.of(
                "&7Выбирай раздел и читай",
                "&7основные команды сервера."
        )));

        inv.setItem(11, info(Material.DIAMOND, "&b&lЭкономика", economyLore()));
        inv.setItem(12, info(Material.OAK_SIGN, "&a&lКоммуникация", commLore()));
        inv.setItem(13, info(Material.CHEST, "&6&lКейсы", List.of("&7Soon... <3")));
        inv.setItem(14, info(Material.IRON_SWORD, "&c&lБоевка!", pvpLore()));
        inv.setItem(15, info(Material.BARRIER, "&f&lПолезности", miscLore()));

        player.openInventory(inv);
    }

    private ItemStack info(Material mat, String display, List<String> loreLines) {
        var item = new ItemStack(mat);
        var meta = item.getItemMeta();
        meta.setDisplayName(Text.c(display));
        if (loreLines != null) {
            List<String> out = new ArrayList<>();
            for (String s : loreLines) out.add(Text.c(s));
            meta.setLore(out);
        }
        item.setItemMeta(meta);
        return item;
    }

    private List<String> economyLore() {
        return List.of(
                "&7/pay &8/ &7/bank &8— &fпереводы и банк",
                "&7/trade &8— &fобмен между игроками",
                "&7/balance &8— &fтвой баланс",
                "",
                "&bИнвестиции банка:",
                "&7Каждый день получай &f%&7 от вклада",
                "",
                "&7/shop &8— &fмагазин сервера",
                "&7/ah &8— &fаукцион игроков",
                "&7/sell &8— &fпродай предметы с ценой",
                "&7/multi &8— &fмножитель заработка"
        );
    }

    private List<String> commLore() {
        return List.of(
                "&7/m &8/ &7/msg &8— &fЛС игрокам",
                "&7/clan &8— &fкланы (скоро)",
                "",
                "&7/home &8— &fдома и точки",
                "&8[ &f/sethome <название> &8]",
                "&8[ &f/home <название> &8]",
                "&8[ &f/delhome <название> &8]",
                "&8[ &f/home list &8]",
                "",
                "&7/tpa &8— &fзапрос на ТП",
                "&7/tpahere &8— &fТП к тебе"
        );
    }

    private List<String> pvpLore() {
        return List.of(
                "&7/duel &8— &f1x1 со случайным набором",
                "&7/arena &8— &fбитва с несколькими игроками"
        );
    }

    private List<String> miscLore() {
        return List.of(
                "&7/info &8— &fсоц сети владельцев",
                "&7/kit &8— &fстартовый набор (скоро)",
                "&7/playtime &8— &fсколько ты играешь",
                "&7/stats &8— &fстатистика",
                "&7/warp &8— &fсерверные локации",
                "&7/help &8— &fбазовая инфа",
                "&7/hub &8— &fв хаб",
                "&7/spawn &8— &fв выживание"
        );
    }

    private void applySkin(Entity ent, String skinNick) {
        if (skinNick == null || skinNick.isBlank()) return;
        String nick = skinNick.trim();

        // 1) Direct Purpur-ish methods
        if (tryInvoke(ent, "setSkin", String.class, nick)) return;
        if (tryInvoke(ent, "setSkinName", String.class, nick)) return;

        // 2) Paper profile method (async complete, then set)
        try {
            PlayerProfile profile = Bukkit.createPlayerProfile(nick);
            new BukkitRunnable() {
                @Override
                public void run() {
                    // Try to fill textures (method name differs across APIs)
                    try {
                        // Paper (some versions): complete()
                        var m = profile.getClass().getMethod("complete");
                        m.invoke(profile);
                    } catch (Throwable ignored) {
                        try {
                            // Other variants: update() -> CompletableFuture
                            var m2 = profile.getClass().getMethod("update");
                            Object fut = m2.invoke(profile);
                            if (fut instanceof java.util.concurrent.CompletableFuture<?> cf) {
                                try { cf.get(); } catch (Throwable ignored2) {}
                            }
                        } catch (Throwable ignored2) {}
                    }
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        tryInvoke(ent, "setPlayerProfile", PlayerProfile.class, profile);
                        tryInvoke(ent, "setProfile", PlayerProfile.class, profile);
                        tryInvoke(ent, "setSkin", PlayerProfile.class, profile);
                    });
                }
            }.runTaskAsynchronously(plugin);
        } catch (Throwable ignored) {}

        // 3) Legacy Paper profile (com.destroystokyo.paper.profile.PlayerProfile) via reflection
        try {
            Object legacyProfile = null;
            try {
                var m = Bukkit.class.getMethod("createProfile", String.class);
                legacyProfile = m.invoke(null, nick);
            } catch (Throwable ignored) {
                try {
                    var m2 = Bukkit.class.getMethod("createProfile", java.util.UUID.class, String.class);
                    legacyProfile = m2.invoke(null, java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:" + nick).getBytes()), nick);
                } catch (Throwable ignored2) {}
            }
            Object prof = legacyProfile;
            if (prof != null) {
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        try {
                            var cm = prof.getClass().getMethod("complete");
                            cm.invoke(prof);
                        } catch (Throwable ignored) {}

                        Object finalProf = prof;
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            tryInvokeAny(ent, "setPlayerProfile", finalProf);
                            tryInvokeAny(ent, "setProfile", finalProf);
                            tryInvokeAny(ent, "setSkin", finalProf);
                        });
                    }
                }.runTaskAsynchronously(plugin);
            }
        } catch (Throwable ignored) {}
    }

    private boolean tryInvoke(Object target, String name, Class<?> argType, Object arg) {
        try {
            var m = target.getClass().getMethod(name, argType);
            m.invoke(target, arg);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean tryInvokeAny(Object target, String name, Object arg) {
        if (arg == null) return false;
        try {
            for (var m : target.getClass().getMethods()) {
                if (!m.getName().equals(name)) continue;
                var pts = m.getParameterTypes();
                if (pts.length != 1) continue;
                if (!pts[0].isAssignableFrom(arg.getClass())) continue;
                m.invoke(target, arg);
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private UUID spawnNameTag(Entity base, String name) {
        try {
            var loc = base.getLocation().clone();
            double y = Math.max(1.9, base.getHeight() + 0.35);
            loc.add(0, y, 0);
            ArmorStand as = base.getWorld().spawn(loc, ArmorStand.class, stand -> {
                stand.setVisible(false);
                stand.setMarker(true);
                stand.setSmall(true);
                stand.setGravity(false);
                stand.setInvulnerable(true);
                stand.setSilent(true);
                stand.setCustomNameVisible(true);
                stand.setCustomName(Text.c("&b&l" + name));
            });
            return as.getUniqueId();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Entity findNpcTarget(Player p, double range) {
        // 1) Paper API: target entity (works well even if entity is non-collidable)
        try {
            Entity t = p.getTargetEntity((int) Math.ceil(range));
            if (t != null && isOurNpc(t)) return t;
        } catch (Throwable ignored) {}

        // 2) Ray trace fallback
        try {
            var rt = p.rayTraceEntities((int) Math.ceil(range));
            if (rt != null && rt.getHitEntity() != null && isOurNpc(rt.getHitEntity())) return rt.getHitEntity();
        } catch (Throwable ignored) {}

        // 3) View-cone fallback: closest NPC in front of player
        try {
            var eye = p.getEyeLocation();
            var dir = eye.getDirection().normalize();
            Entity best = null;
            double bestDist = Double.MAX_VALUE;
            for (Entity e : p.getWorld().getNearbyEntities(eye, range, range, range)) {
                if (e == null) continue;
                if (!isOurNpc(e)) continue;

                var to = e.getLocation().add(0, Math.max(0.2, e.getHeight() * 0.5), 0).toVector().subtract(eye.toVector());
                double dist = to.length();
                if (dist <= 0.0001 || dist > range) continue;
                var n = to.clone().multiply(1.0 / dist);
                double dot = n.dot(dir); // 1 = exactly center of view
                if (dot < 0.97) continue; // tight cone
                if (dist < bestDist) {
                    bestDist = dist;
                    best = e;
                }
            }
            return best;
        } catch (Throwable ignored) {}

        return null;
    }

    private ItemStack named(Material mat, String display, String key) {
        var item = new ItemStack(mat);
        var meta = item.getItemMeta();
        meta.setDisplayName(Text.c(display));
        meta.getPersistentDataContainer().set(pluginUiKey(), PersistentDataType.STRING, key);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isOurNpc(Entity entity) {
        var container = entity.getPersistentDataContainer();
        return container.has(pluginKey(), PersistentDataType.BYTE);
    }

    private org.bukkit.NamespacedKey pluginKey() {
        return new org.bukkit.NamespacedKey(plugin, npcKey);
    }

    private org.bukkit.NamespacedKey pluginUiKey() {
        return new org.bukkit.NamespacedKey(plugin, uiKey);
    }

    private void saveQuietly() {
        try {
            store.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save npcs.yml: " + e.getMessage());
        }
    }
}

