"""
Optional: crop logos and write PNGs to textures/custom/ui/smp_rebrand/ only.

The pack font uses custom/ui/hugosmp.png (and _1, _2) directly — this script does
not change default.json / uniform.json, so running it will not switch fonts.

Run from this folder (close Minecraft if textures are locked):
  python apply_smp_logos.py
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent
UI = ROOT / "assets/minecraft/textures/custom/ui"
OUT = UI / "smp_rebrand"


def crop_hugosmp_main(im: Image.Image) -> Image.Image:
    im = im.convert("RGBA")
    cropped = im.crop((0, 57, im.width, im.height))
    bbox = cropped.getbbox()
    return cropped.crop(bbox) if bbox else cropped


def crop_hugosmp_tall(im: Image.Image) -> Image.Image:
    im = im.convert("RGBA")
    cropped = im.crop((0, 148, im.width, im.height))
    bbox = cropped.getbbox()
    return cropped.crop(bbox) if bbox else cropped


def crop_hugosmp_2_white(im: Image.Image) -> Image.Image:
    im = crop_hugosmp_tall(im)
    px = im.load()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if r > 245 and g > 245 and b > 245 and a > 200:
                px[x, y] = (0, 0, 0, 0)
    bbox = im.getbbox()
    return im.crop(bbox) if bbox else im


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    new_im = crop_hugosmp_main(Image.open(UI / "hugosmp.png"))
    new_im.save(OUT / "hugosmp.png")

    crop_hugosmp_tall(Image.open(UI / "hugosmp_1.png")).save(OUT / "hugosmp_1.png")
    crop_hugosmp_2_white(Image.open(UI / "hugosmp_2.png")).save(OUT / "hugosmp_2.png")

    print("OK: wrote", OUT / "hugosmp.png", new_im.size, "(font still points at custom/ui/)")


if __name__ == "__main__":
    main()
